"""Authenticated RPC gateway shared by all feature services."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..config import EitaaCoreConfig
from ..domain.enums import EndpointRole
from ..domain.session import Session
from ..errors import EitaaCoreError, RpcError, TokenRefreshError
from ..infrastructure.codec import EitaaObjectCodec, normalize_response
from ..infrastructure.codec.response import ResponseEnvelope
from ..infrastructure.codec.tl import hex_constructor
from ..infrastructure.diagnostics import DiagnosticManager
from ..infrastructure.session.constructors import TOKEN_REFRESH_SIGNALS
from ..infrastructure.transport import EndpointRouter
from ..ports.transport import BinaryTransport, TransportRequest, TransportResponse

if TYPE_CHECKING:
    from .session_lifecycle import SessionLifecycleService


@dataclass(slots=True, frozen=True)
class RpcResult:
    """Normalized result returned to method-specific parsers."""

    envelope: ResponseEnvelope
    transport: TransportResponse
    operation: str
    endpoint_role: EndpointRole

    @property
    def body(self) -> bytes:
        """Return the decompressed, RPC-error-checked response body."""
        return self.envelope.body


class RpcGateway:
    """Wrap, route, send, normalize, refresh, and replay RPC methods.

    Feature repositories serialize only their own TL method. Token expiry is a
    cross-cutting concern handled here, so History, Contacts, Media, and future
    Send services do not need duplicated refresh code.
    """

    def __init__(
        self,
        *,
        config: EitaaCoreConfig,
        session: Session,
        transport: BinaryTransport,
        endpoint_router: EndpointRouter,
        session_lifecycle: SessionLifecycleService | None = None,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.config = config
        self.session = session
        self.transport = transport
        self.endpoint_router = endpoint_router
        self.session_lifecycle = session_lifecycle
        self.diagnostics = diagnostics

    def invoke(
        self,
        packed_method: bytes,
        *,
        operation: str,
        endpoint_role: EndpointRole = EndpointRole.API,
        fallback_index: int = 0,
        _after_token_refresh: bool = False,
    ) -> RpcResult:
        """Invoke one serialized method through the Eitaa web wrapper.

        When the server returns ``eitaa_updates_expire_token`` or
        ``eitaa_token_updating``, the gateway refreshes the token and replays
        this original RPC exactly once. The private ``_after_token_refresh``
        flag prevents recursive refresh loops.
        """
        if len(packed_method) < 4:
            debug_file = self._emit(
                "packed_method_too_short",
                level="error",
                fields={"operation": operation, "packed_length": len(packed_method)},
            )
            from ..errors import TLEncodeError

            raise TLEncodeError(
                "A packed method must contain at least a constructor.",
                safe_context={"operation": operation, "packed_length": len(packed_method)},
                debug_file=debug_file,
            )

        method_constructor = int.from_bytes(packed_method[:4], "little", signed=False)
        selection = self.endpoint_router.resolve(
            endpoint_role,
            fallback_index=fallback_index,
        )
        token_used = self.session.token
        wrapped = EitaaObjectCodec.encode(
            self.session,
            packed_method,
            layer=self.config.layer,
            flags=self.config.wrapper_flags,
        )
        self._emit(
            "rpc_started",
            fields={
                "operation": operation,
                "endpoint_role": endpoint_role.value,
                "endpoint": selection.url,
                "method_constructor": hex_constructor(method_constructor),
                "packed_length": len(packed_method),
                "wrapped_length": len(wrapped),
                "after_token_refresh": _after_token_refresh,
            },
        )
        try:
            response = self.transport.send(
                TransportRequest(
                    endpoint=selection.url,
                    body=wrapped,
                    operation=operation,
                )
            )
            envelope = normalize_response(response.body)
        except EitaaCoreError as exc:
            # Eitaa may report an expired web token as an ordinary RPC 401
            # instead of one of the dedicated refresh constructors. Treat it
            # as a bounded refresh signal and replay the original request once.
            if (
                isinstance(exc, RpcError)
                and exc.code == 401
                and not _after_token_refresh
                and self.session_lifecycle is not None
            ):
                self._emit(
                    "rpc_token_refresh_401",
                    level="warning",
                    fields={
                        "operation": operation,
                        "endpoint_role": endpoint_role.value,
                        "method_constructor": hex_constructor(method_constructor),
                    },
                )
                refresh_result = self.session_lifecycle.refresh(
                    expected_token=token_used,
                    trigger_constructor=None,
                )
                self._emit(
                    "rpc_replaying_after_token_refresh",
                    fields={
                        "operation": operation,
                        "refreshed": refresh_result.refreshed,
                        "reused_concurrent_refresh": refresh_result.reused_concurrent_refresh,
                        "refresh_attempts": refresh_result.attempts,
                        "trigger": "rpc_401",
                    },
                )
                return self.invoke(
                    packed_method,
                    operation=operation,
                    endpoint_role=endpoint_role,
                    fallback_index=fallback_index,
                    _after_token_refresh=True,
                )
            error_fields = {
                "operation": operation,
                "endpoint_role": endpoint_role.value,
                "endpoint": selection.url,
                "method_constructor": hex_constructor(method_constructor),
                "error_type": type(exc).__name__,
                "rpc_code": exc.code if isinstance(exc, RpcError) else None,
                "safe_context": exc.safe_context,
                "after_token_refresh": _after_token_refresh,
            }
            debug_file = self._emit(
                "rpc_failed",
                level="error",
                fields=error_fields,
            )
            if exc.component == "tl_codec" and self.diagnostics:
                debug_file = self.diagnostics.emit(
                    "tl_codec",
                    "codec_failed_during_rpc",
                    level="error",
                    fields=error_fields,
                )
            if not exc.debug_file:
                exc.debug_file = debug_file
            raise

        if envelope.constructor in TOKEN_REFRESH_SIGNALS:
            self._emit(
                "rpc_token_refresh_signal",
                level="warning",
                fields={
                    "operation": operation,
                    "endpoint_role": endpoint_role.value,
                    "endpoint": selection.url,
                    "method_constructor": hex_constructor(method_constructor),
                    "response_constructor": hex_constructor(envelope.constructor),
                    "after_token_refresh": _after_token_refresh,
                },
            )
            if _after_token_refresh:
                debug_file = self._emit(
                    "rpc_token_refresh_replay_failed",
                    level="error",
                    fields={
                        "operation": operation,
                        "response_constructor": hex_constructor(
                            envelope.constructor
                        ),
                        "response_length": len(envelope.body),
                    },
                )
                raise TokenRefreshError(
                    "The original RPC still requested token refresh after one replay.",
                    safe_context={
                        "operation": operation,
                        "response_constructor": hex_constructor(
                            envelope.constructor
                        ),
                        "response_length": len(envelope.body),
                    },
                    debug_file=debug_file,
                )
            if self.session_lifecycle is None:
                debug_file = self._emit(
                    "rpc_token_refresh_unavailable",
                    level="error",
                    fields={"operation": operation},
                )
                raise TokenRefreshError(
                    "The server requested token refresh, but no lifecycle service is configured.",
                    safe_context={"operation": operation},
                    debug_file=debug_file,
                )

            refresh_result = self.session_lifecycle.refresh(
                expected_token=token_used,
                trigger_constructor=envelope.constructor,
            )
            self._emit(
                "rpc_replaying_after_token_refresh",
                fields={
                    "operation": operation,
                    "refreshed": refresh_result.refreshed,
                    "reused_concurrent_refresh": (
                        refresh_result.reused_concurrent_refresh
                    ),
                    "refresh_attempts": refresh_result.attempts,
                },
            )
            return self.invoke(
                packed_method,
                operation=operation,
                endpoint_role=endpoint_role,
                fallback_index=fallback_index,
                _after_token_refresh=True,
            )

        self._emit(
            "rpc_completed",
            fields={
                "operation": operation,
                "endpoint_role": endpoint_role.value,
                "endpoint": selection.url,
                "method_constructor": hex_constructor(method_constructor),
                "response_constructor": (
                    hex_constructor(envelope.constructor)
                    if envelope.constructor is not None
                    else None
                ),
                "response_constructor_name": envelope.constructor_name,
                "response_length": len(envelope.body),
                "was_gzip_packed": envelope.was_gzip_packed,
                "elapsed_seconds": round(response.elapsed_seconds, 6),
                "after_token_refresh": _after_token_refresh,
            },
        )
        return RpcResult(
            envelope=envelope,
            transport=response,
            operation=operation,
            endpoint_role=endpoint_role,
        )

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("rpc", event, level=level, fields=fields)

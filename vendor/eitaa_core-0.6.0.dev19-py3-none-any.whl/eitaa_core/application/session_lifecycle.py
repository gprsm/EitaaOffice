"""Session lifecycle and bounded automatic token refresh.

This service is deliberately independent from feature services. History,
Contacts, Media, and future Send services all benefit from the same refresh
behavior through :class:`RpcGateway`.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone

from ..config import EitaaCoreConfig
from ..domain.enums import EndpointRole
from ..domain.session import Session
from ..errors import EitaaCoreError, TokenRefreshDisabledError, TokenRefreshError
from ..infrastructure.codec import EitaaObjectCodec, normalize_response
from ..infrastructure.codec.tl import hex_constructor
from ..infrastructure.diagnostics import DiagnosticManager
from ..infrastructure.session.constructors import (
    EITAA_TOKEN_UPDATING,
    EITAA_UPDATES_EXPIRE_TOKEN,
    EITAA_UPDATES_TOKEN,
)
from ..infrastructure.session.token_codec import (
    build_refresh_token_request,
    parse_refreshed_token,
)
from ..infrastructure.transport import EndpointRouter
from ..ports.session_repository import SessionRepository
from ..ports.transport import BinaryTransport, TransportRequest

_REFRESH_LOCKS_GUARD = threading.Lock()
_REFRESH_LOCKS: dict[str, threading.RLock] = {}


def _shared_refresh_lock(session_path: object) -> threading.RLock:
    key = str(session_path)
    with _REFRESH_LOCKS_GUARD:
        lock = _REFRESH_LOCKS.get(key)
        if lock is None:
            lock = threading.RLock()
            _REFRESH_LOCKS[key] = lock
        return lock


@dataclass(slots=True, frozen=True)
class TokenRefreshResult:
    """Safe result of a manual or automatic refresh operation."""

    refreshed: bool
    reused_concurrent_refresh: bool
    attempts: int
    expire: int | None
    date: int | None


class SessionLifecycleService:
    """Refresh an expired token, persist it atomically, and update memory.

    A process-local lock prevents multiple simultaneous feature requests from
    refreshing the same token independently. The ``expected_token`` parameter
    lets a waiter detect that another request already completed the refresh.
    Token values are never written to diagnostics.
    """

    def __init__(
        self,
        *,
        config: EitaaCoreConfig,
        session: Session,
        session_repository: SessionRepository,
        transport: BinaryTransport,
        endpoint_router: EndpointRouter,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.config = config
        self.session = session
        self.session_repository = session_repository
        self.transport = transport
        self.endpoint_router = endpoint_router
        self.diagnostics = diagnostics
        self._refresh_lock = _shared_refresh_lock(config.session_file)

    def refresh(
        self,
        *,
        expected_token: str | None = None,
        trigger_constructor: int | None = None,
        force: bool = False,
    ) -> TokenRefreshResult:
        """Refresh the current token with bounded retry behavior.

        Args:
            expected_token: Token used by the request that received the expiry
                signal. If another thread already changed the session token,
                this call skips a duplicate refresh and returns immediately.
            trigger_constructor: Constructor that initiated automatic refresh.
                It is logged only as a non-secret hexadecimal identifier.
            force: Permit an explicit manual refresh even when automatic refresh
                is disabled in configuration.
        """
        if not self.config.auto_refresh_token and not force:
            debug_file = self._emit(
                "token_refresh_disabled",
                level="error",
                fields={
                    "trigger_constructor": self._safe_constructor(trigger_constructor),
                },
            )
            raise TokenRefreshDisabledError(
                "The server requested a token refresh, but automatic refresh is disabled.",
                safe_context={
                    "trigger_constructor": self._safe_constructor(trigger_constructor),
                },
                debug_file=debug_file,
            )

        with self._refresh_lock:
            # Another Core instance in this process may have refreshed and persisted
            # the shared session while this instance was waiting. Reload once before
            # deciding whether another refresh is necessary.
            if expected_token is not None and self.session.token == expected_token:
                try:
                    latest = self.session_repository.load()
                except Exception:
                    latest = None
                if latest is not None and latest.token != expected_token:
                    self.session.token = latest.token
                    self.session.metadata = latest.metadata
            if expected_token is not None and self.session.token != expected_token:
                self._emit(
                    "token_refresh_reused",
                    fields={
                        "reason": "session_token_changed_while_waiting",
                        "trigger_constructor": self._safe_constructor(
                            trigger_constructor
                        ),
                    },
                )
                return TokenRefreshResult(
                    refreshed=False,
                    reused_concurrent_refresh=True,
                    attempts=0,
                    expire=self._metadata_int("token_refresh_expire"),
                    date=self._metadata_int("token_refresh_date"),
                )

            packed_method = build_refresh_token_request(self.config.refresh_app_info)
            selection = self.endpoint_router.resolve(EndpointRole.API)
            max_attempts = self.config.token_refresh_max_attempts
            self._emit(
                "token_refresh_started",
                fields={
                    "trigger_constructor": self._safe_constructor(trigger_constructor),
                    "endpoint": selection.url,
                    "max_attempts": max_attempts,
                    "app_info": self.config.refresh_app_info.safe_summary(),
                },
            )

            for attempt in range(1, max_attempts + 1):
                try:
                    wrapped = EitaaObjectCodec.encode(
                        self.session,
                        packed_method,
                        layer=self.config.layer,
                        flags=self.config.wrapper_flags,
                    )
                    response = self.transport.send(
                        TransportRequest(
                            endpoint=selection.url,
                            body=wrapped,
                            operation="session.refresh_token",
                        )
                    )
                    envelope = normalize_response(response.body)
                except EitaaCoreError as exc:
                    debug_file = self._emit(
                        "token_refresh_request_failed",
                        level="error",
                        fields={
                            "attempt": attempt,
                            "max_attempts": max_attempts,
                            "error_type": type(exc).__name__,
                            "safe_context": exc.safe_context,
                        },
                    )
                    if not exc.debug_file:
                        exc.debug_file = debug_file
                    raise

                constructor = envelope.constructor
                if constructor == EITAA_UPDATES_TOKEN:
                    try:
                        parsed = parse_refreshed_token(envelope.body)
                    except EitaaCoreError as exc:
                        debug_file = self._emit(
                            "token_refresh_parse_failed",
                            level="error",
                            fields={
                                "attempt": attempt,
                                "error_type": type(exc).__name__,
                                "safe_context": exc.safe_context,
                            },
                        )
                        if not exc.debug_file:
                            exc.debug_file = debug_file
                        raise
                    refreshed_at = datetime.now(timezone.utc).isoformat()
                    metadata = dict(self.session.metadata)
                    metadata.update(
                        {
                            "token_refresh_expire": parsed.expire,
                            "token_refresh_date": parsed.date,
                            "token_refreshed_at": refreshed_at,
                            "token_refresh_source": (
                                "manual_core4_1"
                                if force and expected_token is None
                                else "automatic_core4_1"
                            ),
                        }
                    )
                    replacement = Session(
                        token=parsed.token,
                        imei=self.session.imei,
                        dc=self.session.dc,
                        created_at=self.session.created_at,
                        metadata=metadata,
                    )
                    replacement.validate()
                    self.session_repository.save(replacement)

                    # Preserve object identity because all repositories and the
                    # outer wrapper reference this Session instance.
                    self.session.token = replacement.token
                    self.session.metadata = replacement.metadata
                    self._emit(
                        "token_refresh_completed",
                        fields={
                            "attempt": attempt,
                            "expire": parsed.expire,
                            "date": parsed.date,
                            "token_length": len(parsed.token),
                            "session_persisted": True,
                        },
                    )
                    return TokenRefreshResult(
                        refreshed=True,
                        reused_concurrent_refresh=False,
                        attempts=attempt,
                        expire=parsed.expire,
                        date=parsed.date,
                    )

                if constructor in {EITAA_TOKEN_UPDATING, EITAA_UPDATES_EXPIRE_TOKEN}:
                    self._emit(
                        "token_refresh_pending",
                        level="warning",
                        fields={
                            "attempt": attempt,
                            "max_attempts": max_attempts,
                            "response_constructor": self._safe_constructor(constructor),
                        },
                    )
                    if attempt < max_attempts:
                        time.sleep(self.config.token_refresh_retry_delay_seconds)
                        continue

                debug_file = self._emit(
                    "token_refresh_rejected",
                    level="error",
                    fields={
                        "attempt": attempt,
                        "max_attempts": max_attempts,
                        "response_constructor": self._safe_constructor(constructor),
                        "response_length": len(envelope.body),
                    },
                )
                raise TokenRefreshError(
                    "Eitaa did not return a refreshed token.",
                    safe_context={
                        "attempts": attempt,
                        "response_constructor": self._safe_constructor(constructor),
                        "response_length": len(envelope.body),
                    },
                    debug_file=debug_file,
                )

            raise AssertionError("unreachable")

    def _metadata_int(self, key: str) -> int | None:
        value = self.session.metadata.get(key)
        return value if isinstance(value, int) else None

    @staticmethod
    def _safe_constructor(value: int | None) -> str | None:
        return hex_constructor(value) if value is not None else None

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit(
            "session_refresh", event, level=level, fields=fields
        )

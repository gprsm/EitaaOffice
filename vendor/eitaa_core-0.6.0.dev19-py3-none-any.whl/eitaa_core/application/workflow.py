"""Application services for cursor retrieval and external publication state."""

from __future__ import annotations

from datetime import datetime, timezone

from ..domain.enums import PublicationStatus
from ..domain.message import HistoryPage, HistoryQuery, Message, MessageWriteStats
from ..domain.peer import Peer
from ..domain.workflow import CursorFetchResult, HistoryCursor, PublicationRecord
from ..errors import PublicationError, RetrievalCursorError
from ..infrastructure.diagnostics import DiagnosticManager
from ..ports.cursor_repository import CursorRepository
from ..ports.publication_repository import PublicationRepository
from .history import HistoryService, MessageStoreService


class RetrievalService:
    """Provide repeatable page-by-page remote retrieval with named cursors."""

    def __init__(
        self,
        history: HistoryService,
        messages: MessageStoreService,
        cursors: CursorRepository,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.history = history
        self.messages = messages
        self.cursors = cursors
        self.diagnostics = diagnostics

    def get_cursor(self, peer: Peer, key: str = "default") -> HistoryCursor | None:
        """Return the saved position for ``peer + key`` without network access."""
        peer.validate()
        return self.cursors.get_cursor(peer, key)

    def reset_cursor(self, peer: Peer, key: str = "default") -> bool:
        """Delete a saved cursor so the next page starts from newest messages."""
        peer.validate()
        deleted = self.cursors.delete_cursor(peer, key)
        self._emit(
            "cursor_reset",
            fields={"peer": peer.safe_summary(), "key": key, "deleted": deleted},
        )
        return deleted

    def fetch_next(
        self,
        peer: Peer,
        *,
        key: str = "default",
        page_size: int = 10,
        store: bool = True,
        restart_completed: bool = False,
    ) -> CursorFetchResult:
        """Fetch the next oldest page and atomically advance its named cursor.

        The first call starts with ``offset_id=0``.  Later calls use the oldest
        message id returned by the previous page.  A completed cursor does not
        make another network call unless ``restart_completed`` is true.
        """
        peer.validate()
        if not 1 <= page_size <= 100:
            raise RetrievalCursorError("page_size must be between 1 and 100.")
        if not key.strip() or len(key) > 128:
            raise RetrievalCursorError("Cursor key must contain 1 to 128 characters.")

        previous = self.cursors.get_cursor(peer, key)
        if previous and previous.completed and not restart_completed:
            empty = HistoryPage(
                peer=peer,
                messages=(),
                response_type="cursor.completed",
            )
            return CursorFetchResult(page=empty, cursor=previous)
        if previous is None or restart_completed:
            previous = HistoryCursor(peer=peer, key=key, page_size=page_size)

        page = self.history.fetch(
            peer,
            HistoryQuery(limit=page_size, offset_id=previous.next_offset_id),
        )
        write = self.messages.save(page.messages) if store else MessageWriteStats()
        next_offset = page.next_offset_id or previous.next_offset_id
        completed = (
            not page.messages
            or len(page.messages) < page_size
            or page.next_offset_id is None
            or (
                previous.next_offset_id != 0
                and page.next_offset_id == previous.next_offset_id
            )
        )
        current = HistoryCursor(
            peer=peer,
            key=key,
            next_offset_id=next_offset,
            page_size=page_size,
            pages_fetched=previous.pages_fetched + 1,
            messages_fetched=previous.messages_fetched + len(page.messages),
            completed=completed,
            updated_at=datetime.now(timezone.utc),
        )
        self.cursors.save_cursor(current)
        result = CursorFetchResult(page=page, cursor=current, stored=write)
        self._emit("cursor_page_fetched", fields=result.safe_summary())
        return result

    def fetch_slice(
        self,
        peer: Peer,
        *,
        skip: int,
        take: int,
        offset_id: int = 0,
        store: bool = False,
    ) -> CursorFetchResult:
        """Skip ``N`` remote messages and return the following ``M`` messages.

        Eitaa does not consistently honor ``add_offset`` when ``offset_id`` is
        zero, especially for channel history.  This implementation therefore
        performs deterministic cursor-based pagination and applies ``skip`` in
        Core memory.  It works both within one page and across multiple pages.

        Only the returned messages are persisted when ``store`` is true; skipped
        messages are not written as a side effect.  Use :meth:`fetch_next` for a
        durable named cursor and repeated page-by-page workflows.
        """
        peer.validate()
        if skip < 0:
            raise RetrievalCursorError("skip cannot be negative.")
        if not 1 <= take <= 100:
            raise RetrievalCursorError("take must be between 1 and 100.")
        if offset_id < 0:
            raise RetrievalCursorError("offset_id cannot be negative.")

        remaining_skip = skip
        selected: list[Message] = []
        current_offset = offset_id
        seen_offsets: set[int] = set()
        page_count = 0
        fetched_count = 0
        total_count: int | None = None
        pts: int | None = None
        inexact = False
        offset_id_offset: int | None = None
        parse_errors: list[str] = []
        last_response_type = "messages.Messages"
        last_next_offset: int | None = None
        stopped_reason = "take_satisfied"

        while len(selected) < take:
            if current_offset in seen_offsets:
                stopped_reason = "repeated_offset"
                break
            seen_offsets.add(current_offset)

            # Fetch no more than the protocol maximum while requesting enough
            # data to consume the remaining skip and fill the requested slice.
            request_limit = min(100, max(1, remaining_skip + (take - len(selected))))
            page = self.history.fetch(
                peer,
                HistoryQuery(limit=request_limit, offset_id=current_offset),
            )
            page_count += 1
            fetched_count += len(page.messages)
            if total_count is None:
                total_count = page.total_count
            pts = page.pts if page.pts is not None else pts
            inexact = inexact or page.inexact
            if offset_id_offset is None:
                offset_id_offset = page.offset_id_offset
            parse_errors.extend(page.parse_errors)
            last_response_type = page.response_type
            last_next_offset = page.next_offset_id

            if not page.messages:
                stopped_reason = "empty_page"
                break

            consume = min(remaining_skip, len(page.messages))
            remaining_skip -= consume
            candidates = page.messages[consume:]
            needed = take - len(selected)
            selected.extend(candidates[:needed])

            if len(selected) >= take:
                stopped_reason = "take_satisfied"
                break
            if len(page.messages) < request_limit:
                stopped_reason = "short_page"
                break
            if page.next_offset_id is None or page.next_offset_id == current_offset:
                stopped_reason = "no_next_offset"
                break
            current_offset = page.next_offset_id

        combined_page = HistoryPage(
            peer=peer,
            messages=tuple(selected),
            total_count=total_count,
            pts=pts,
            inexact=inexact,
            offset_id_offset=offset_id_offset,
            response_type=f"core.historySlice<{last_response_type}>",
            parse_errors=tuple(parse_errors),
        )
        write = self.messages.save(combined_page.messages) if store else MessageWriteStats()
        next_offset = combined_page.next_offset_id or last_next_offset or offset_id
        transient = HistoryCursor(
            peer=peer,
            key="transient-slice",
            next_offset_id=next_offset,
            page_size=take,
            pages_fetched=page_count,
            messages_fetched=fetched_count,
            completed=len(combined_page.messages) < take,
        )
        result = CursorFetchResult(page=combined_page, cursor=transient, stored=write)
        self._emit(
            "history_slice_fetched",
            fields={
                **result.safe_summary(),
                "skip": skip,
                "take": take,
                "remote_messages_fetched": fetched_count,
                "stopped_reason": stopped_reason,
                "server_add_offset_used": False,
            },
        )
        return result

    def _emit(self, event: str, *, fields: dict[str, object]) -> None:
        if self.diagnostics:
            self.diagnostics.emit("cursor", event, fields=fields)


class PublicationService:
    """Track publication of local messages to WordPress or other destinations."""

    def __init__(
        self,
        repository: PublicationRepository,
        messages: MessageStoreService,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.repository = repository
        self.messages = messages
        self.diagnostics = diagnostics

    def get(
        self,
        peer: Peer,
        message_id: int,
        *,
        target_type: str = "wordpress",
        target_key: str = "default",
    ) -> PublicationRecord | None:
        return self.repository.get_publication(
            peer, message_id, target_type, target_key
        )

    def mark_pending(
        self,
        peer: Peer,
        message_id: int,
        *,
        target_type: str = "wordpress",
        target_key: str = "default",
    ) -> PublicationRecord:
        return self._set(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
            status=PublicationStatus.PENDING,
        )

    def mark_processing(
        self,
        peer: Peer,
        message_id: int,
        *,
        target_type: str = "wordpress",
        target_key: str = "default",
    ) -> PublicationRecord:
        """Record the start of one external publication attempt."""
        existing = self.get(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
        )
        now = datetime.now(timezone.utc)
        return self._set(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
            status=PublicationStatus.PROCESSING,
            attempts=(existing.attempts if existing else 0) + 1,
            last_attempt_at=now,
        )

    def mark_published(
        self,
        peer: Peer,
        message_id: int,
        *,
        external_post_id: str,
        external_url: str | None = None,
        target_type: str = "wordpress",
        target_key: str = "default",
    ) -> PublicationRecord:
        """Mark a destination as published using the current message hash."""
        if not external_post_id.strip():
            raise PublicationError("external_post_id cannot be blank.")
        content_hash = self.messages.content_hash(peer, message_id)
        if content_hash is None:
            raise PublicationError(
                "Message must be stored locally before publication is recorded.",
                safe_context={"peer": peer.safe_summary(), "message_id": message_id},
            )
        existing = self.get(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
        )
        now = datetime.now(timezone.utc)
        return self._set(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
            status=PublicationStatus.PUBLISHED,
            external_post_id=external_post_id,
            external_url=external_url,
            published_content_hash=content_hash,
            attempts=existing.attempts if existing else 0,
            last_attempt_at=existing.last_attempt_at if existing else None,
            published_at=now,
            error_code=None,
        )

    def mark_failed(
        self,
        peer: Peer,
        message_id: int,
        *,
        error_code: str,
        target_type: str = "wordpress",
        target_key: str = "default",
    ) -> PublicationRecord:
        if not error_code.strip():
            raise PublicationError("error_code cannot be blank.")
        existing = self.get(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
        )
        now = datetime.now(timezone.utc)
        attempts = existing.attempts if existing else 0
        if not existing or existing.status is not PublicationStatus.PROCESSING:
            attempts += 1
        return self._set(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
            status=PublicationStatus.FAILED,
            attempts=attempts,
            last_attempt_at=now,
            error_code=error_code,
        )

    def mark_skipped(
        self,
        peer: Peer,
        message_id: int,
        *,
        target_type: str = "wordpress",
        target_key: str = "default",
    ) -> PublicationRecord:
        return self._set(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
            status=PublicationStatus.SKIPPED,
        )

    def list(
        self,
        *,
        peer: Peer | None = None,
        target_type: str | None = None,
        target_key: str | None = None,
        status: PublicationStatus | None = None,
        limit: int = 100,
    ) -> tuple[PublicationRecord, ...]:
        return self.repository.list_publications(
            peer=peer,
            target_type=target_type,
            target_key=target_key,
            status=status,
            limit=limit,
        )

    def _set(
        self,
        peer: Peer,
        message_id: int,
        *,
        target_type: str,
        target_key: str,
        status: PublicationStatus,
        external_post_id: str | None = None,
        external_url: str | None = None,
        published_content_hash: str | None = None,
        attempts: int | None = None,
        last_attempt_at: datetime | None = None,
        published_at: datetime | None = None,
        error_code: str | None = None,
    ) -> PublicationRecord:
        if self.messages.get(peer, message_id) is None:
            raise PublicationError(
                "Message must be stored locally before workflow state is recorded.",
                safe_context={"peer": peer.safe_summary(), "message_id": message_id},
            )
        existing = self.get(
            peer,
            message_id,
            target_type=target_type,
            target_key=target_key,
        )
        record = PublicationRecord(
            peer=peer,
            message_id=message_id,
            target_type=target_type,
            target_key=target_key,
            status=status,
            external_post_id=(
                external_post_id
                if external_post_id is not None
                else existing.external_post_id if existing else None
            ),
            external_url=(
                external_url
                if external_url is not None
                else existing.external_url if existing else None
            ),
            published_content_hash=(
                published_content_hash
                if published_content_hash is not None
                else existing.published_content_hash if existing else None
            ),
            attempts=attempts if attempts is not None else existing.attempts if existing else 0,
            last_attempt_at=(
                last_attempt_at
                if last_attempt_at is not None
                else existing.last_attempt_at if existing else None
            ),
            published_at=(
                published_at
                if published_at is not None
                else existing.published_at if existing else None
            ),
            error_code=error_code,
            created_at=existing.created_at if existing else datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        saved = self.repository.save_publication(record)
        if self.diagnostics:
            self.diagnostics.emit(
                "publications", "publication_state_changed", fields=saved.safe_summary()
            )
        return saved

"""Application service for exporting locally stored messages."""

from __future__ import annotations

from dataclasses import replace

from ..domain.export import ExportOptions, ExportResult
from ..domain.workflow import MessageSearchQuery
from ..errors import ExportError
from ..infrastructure.diagnostics import DiagnosticManager
from ..infrastructure.export import MessageExportWriter
from .history import MessageStoreService


class ExportService:
    """Stream local SQLite search results into portable files."""

    def __init__(
        self,
        messages: MessageStoreService,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.messages = messages
        self.diagnostics = diagnostics

    def export(
        self,
        query: MessageSearchQuery,
        options: ExportOptions,
    ) -> ExportResult:
        """Export all matching local messages using keyset pagination."""
        query.validate()
        options.validate()
        cursor = query.cursor
        total = 0
        pages = 0
        complete = True
        self._emit(
            "export_started",
            fields={
                "query": _safe_query(query),
                "options": options.safe_summary(),
            },
        )
        writer = MessageExportWriter(options.output_file, options.format, self.diagnostics)
        try:
            with writer:
                while True:
                    remaining = (
                        options.max_messages - total
                        if options.max_messages is not None
                        else options.page_size
                    )
                    if remaining <= 0:
                        complete = False
                        break
                    limit = min(options.page_size, remaining)
                    page = self.messages.search(
                        replace(query, limit=limit, cursor=cursor)
                    )
                    pages += 1
                    total += writer.write_many(page.messages)
                    cursor = page.next_cursor
                    if not page.messages or cursor is None:
                        break
                path = writer.finalize()
        except Exception as exc:
            writer.abort()
            debug_file = self._emit(
                "export_failed",
                level="error",
                fields={
                    "error_type": type(exc).__name__,
                    "messages_written": total,
                    "pages": pages,
                },
            )
            if isinstance(exc, ExportError):
                if not exc.debug_file:
                    exc.debug_file = debug_file
                raise
            raise ExportError(
                "Local message export failed.",
                safe_context={
                    "error_type": type(exc).__name__,
                    "messages_written": total,
                    "pages": pages,
                },
                debug_file=debug_file,
            ) from exc
        result = ExportResult(path, options.format, total, pages, complete)
        self._emit("export_completed", fields=result.safe_summary())
        return result

    def _emit(self, event: str, *, level: str = "info", fields=None) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("export", event, level=level, fields=fields)


def _safe_query(query: MessageSearchQuery) -> dict[str, object]:
    return {
        "peer": query.peer.safe_summary() if query.peer else None,
        "date_from": query.date_from.isoformat() if query.date_from else None,
        "date_to": query.date_to.isoformat() if query.date_to else None,
        "before_id": query.before_id,
        "after_id": query.after_id,
        "media_types": [item.value for item in query.media_types],
        "publication_status": query.publication_status.value if query.publication_status else None,
        "unpublished": query.unpublished,
        "target_type": query.target_type,
        "target_key": query.target_key,
        "text_filter_present": bool(query.text),
        "cursor_present": bool(query.cursor),
    }

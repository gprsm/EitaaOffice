"""Local health checks that do not send Eitaa API requests."""

from __future__ import annotations

import platform
import sys
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

from ..config import EitaaCoreConfig
from ..domain.enums import MediaDownloadMethod, MediaType, MemberRemoteFilter, PeerType
from ..domain.send import UploadedFile
from ..domain.message import HistoryQuery
from ..domain.media import MediaReference
from ..domain.peer import Peer
from ..domain.phone import PhoneNumber
from ..domain.session import Session
from ..infrastructure.codec import EitaaObjectCodec, PeerCodec, TLReader, TLWriter
from ..infrastructure.auth import AuthCodec
from ..infrastructure.contacts import ContactsCodec
from ..infrastructure.community import CommunityCodec
from ..infrastructure.membership import MembershipCodec
from ..infrastructure.discovery import DiscoveryCodec
from ..infrastructure.community import constructors as community_c
from ..infrastructure.membership import constructors as membership_c
from ..infrastructure.diagnostics import DiagnosticManager
from ..infrastructure.history import HistoryRequestCodec
from ..infrastructure.media import MediaRequestCodec, MediaResponseCodec
from ..infrastructure.media import constructors as media_c
from ..infrastructure.send import SendCodec
from ..infrastructure.persistence import SCHEMA_VERSION
from ..infrastructure.session import (
    EITAA_APP_INFO,
    EITAA_REFRESH_TOKEN,
    EITAA_UPDATES_TOKEN,
    build_refresh_token_request,
    parse_refreshed_token,
)
from ..version import __version__


@dataclass(slots=True, frozen=True)
class HealthCheck:
    """One deterministic health-check result."""

    name: str
    ok: bool
    detail: str


@dataclass(slots=True)
class HealthReport:
    """Collection of health checks and a safe session summary."""

    version: str
    checks: list[HealthCheck] = field(default_factory=list)
    session: dict[str, object] | None = None

    @property
    def ok(self) -> bool:
        """Return true only when all checks pass."""
        return all(item.ok for item in self.checks)

    def as_dict(self) -> dict[str, object]:
        """Convert to a JSON-serializable, secret-free mapping."""
        return {
            "version": self.version,
            "ok": self.ok,
            "checks": [
                {"name": item.name, "ok": item.ok, "detail": item.detail}
                for item in self.checks
            ],
            "session": self.session,
            "environment": {
                "python": sys.version.split()[0],
                "platform": platform.platform(),
            },
        }


def run_local_health_checks(
    *,
    config: EitaaCoreConfig,
    session: Session,
    diagnostics: DiagnosticManager | None = None,
) -> HealthReport:
    """Run all local codec, lifecycle, database, endpoint, and session checks offline."""
    report = HealthReport(version=__version__, session=session.safe_summary())

    try:
        config.validate()
        report.checks.append(HealthCheck("configuration", True, "valid"))
    except Exception as exc:
        report.checks.append(HealthCheck("configuration", False, type(exc).__name__))

    try:
        session.validate()
        report.checks.append(HealthCheck("session", True, "required fields present"))
    except Exception as exc:
        report.checks.append(HealthCheck("session", False, type(exc).__name__))

    try:
        sample = (
            TLWriter()
            .write_i32(0x11223344)
            .write_i64(-123456789)
            .write_string("سلام")
            .write_bytes(b"abc")
            .to_bytes()
        )
        reader = TLReader(sample)
        codec_ok = (
            reader.read_u32() == 0x11223344
            and reader.read_i64() == -123456789
            and reader.read_string() == "سلام"
            and reader.read_bytes() == b"abc"
            and reader.remaining() == 0
        )
        report.checks.append(
            HealthCheck("tl_codec", codec_ok, "round-trip" if codec_ok else "mismatch")
        )
    except Exception as exc:
        report.checks.append(HealthCheck("tl_codec", False, type(exc).__name__))

    try:
        packed = TLWriter().write_i32(0x01020304).to_bytes()
        wrapped = EitaaObjectCodec.encode(
            session,
            packed,
            layer=config.layer,
            flags=config.wrapper_flags,
        )
        decoded = EitaaObjectCodec.decode(wrapped)
        wrapper_ok = (
            decoded.token == session.token
            and decoded.imei == session.imei
            and decoded.packed_data == packed
            and decoded.layer == config.layer
            and decoded.flags == config.wrapper_flags
        )
        report.checks.append(
            HealthCheck(
                "eitaa_wrapper",
                wrapper_ok,
                "round-trip" if wrapper_ok else "mismatch",
            )
        )
    except Exception as exc:
        report.checks.append(HealthCheck("eitaa_wrapper", False, type(exc).__name__))

    try:
        refresh_request = build_refresh_token_request(config.refresh_app_info)
        refresh_reader = TLReader(refresh_request)
        refresh_request_ok = (
            refresh_reader.read_u32() == EITAA_REFRESH_TOKEN
            and refresh_reader.read_u32() == EITAA_APP_INFO
        )
        refresh_response = (
            TLWriter()
            .write_i32(EITAA_UPDATES_TOKEN)
            .write_string("synthetic-token")
            .write_i32(123)
            .write_i32(456)
            .to_bytes()
        )
        parsed_refresh = parse_refreshed_token(refresh_response)
        refresh_ok = (
            refresh_request_ok
            and parsed_refresh.expire == 123
            and parsed_refresh.date == 456
        )
        report.checks.append(
            HealthCheck(
                "token_refresh_codec",
                refresh_ok,
                "eitaaRefreshToken request/response valid"
                if refresh_ok
                else "mismatch",
            )
        )
    except Exception as exc:
        report.checks.append(
            HealthCheck("token_refresh_codec", False, type(exc).__name__)
        )

    try:
        peer = Peer(id=123, type=PeerType.USER, access_hash=456)
        encoded = PeerCodec.encode_input_peer(peer)
        peer_ok = len(encoded) == 20
        report.checks.append(
            HealthCheck("peer_codec", peer_ok, "inputPeerUser encoded")
        )
    except Exception as exc:
        report.checks.append(HealthCheck("peer_codec", False, type(exc).__name__))


    try:
        auth_phone = PhoneNumber.parse("+989361234567")
        auth_request = AuthCodec.build_send_code(
            auth_phone,
            api_id=config.login_api_id,
            api_hash=config.login_api_hash,
        )
        auth_reader = TLReader(auth_request)
        auth_ok = (
            auth_reader.read_u32() == 0xA677244F
            and auth_reader.read_string() == "989361234567"
            and auth_reader.read_i32() == config.login_api_id
            and auth_reader.read_string() == config.login_api_hash
            and auth_reader.read_u32() == 0xDEBEBE83
            and auth_reader.read_i32() == 0
            and auth_reader.remaining() == 0
        )
        report.checks.append(
            HealthCheck(
                "auth_codec",
                auth_ok,
                "auth.sendCode request encoded" if auth_ok else "mismatch",
            )
        )
    except Exception as exc:
        report.checks.append(HealthCheck("auth_codec", False, type(exc).__name__))

    try:
        dialogs_request = DiscoveryCodec.build_get_dialogs(limit=50)
        dialogs_reader = TLReader(dialogs_request)
        discovery_ok = (
            dialogs_reader.read_u32() == 0xA0F4CB4F
            and dialogs_reader.read_i32() == 0
            and dialogs_reader.read_i32() == 0
            and dialogs_reader.read_i32() == 0
            and dialogs_reader.read_u32() == 0x7F3B18EA
            and dialogs_reader.read_i32() == 50
            and dialogs_reader.read_i64() == 0
            and dialogs_reader.remaining() == 0
        )
        report.checks.append(
            HealthCheck(
                "discovery_codec",
                discovery_ok,
                "messages.getDialogs request encoded" if discovery_ok else "mismatch",
            )
        )
    except Exception as exc:
        report.checks.append(HealthCheck("discovery_codec", False, type(exc).__name__))

    try:
        phone = PhoneNumber.parse("09361234567")
        get_request = ContactsCodec.build_get_contacts()
        import_request, client_id = ContactsCodec.build_import_contact(
            phone,
            first_name="Test",
            client_id=123456,
        )
        contacts_ok = (
            len(get_request) == 12
            and len(import_request) > 20
            and client_id == 123456
            and phone.masked.endswith("4567")
        )
        report.checks.append(
            HealthCheck("contacts_codec", contacts_ok, "request builders valid")
        )
    except Exception as exc:
        report.checks.append(HealthCheck("contacts_codec", False, type(exc).__name__))

    try:
        history_peer = Peer(id=321, type=PeerType.CHANNEL, access_hash=654)
        history_request = HistoryRequestCodec.build_get_history(
            history_peer, HistoryQuery(limit=20, offset_id=0)
        )
        history_ok = len(history_request) == 56
        report.checks.append(
            HealthCheck(
                "history_codec",
                history_ok,
                "messages.getHistory request encoded" if history_ok else "unexpected length",
            )
        )
    except Exception as exc:
        report.checks.append(HealthCheck("history_codec", False, type(exc).__name__))


    try:
        community_peer = Peer(id=123, type=PeerType.CHANNEL, access_hash=456)
        members_request = CommunityCodec.build_get_participants(
            community_peer,
            filter=MemberRemoteFilter.RECENT,
            offset=0,
            limit=100,
        )
        members_reader = TLReader(members_request)
        members_ok = (
            members_reader.read_u32() == community_c.CHANNELS_GET_PARTICIPANTS
            and members_reader.read_u32() == community_c.INPUT_CHANNEL
            and members_reader.read_i64() == 123
            and members_reader.read_i64() == 456
            and members_reader.read_u32() == community_c.CHANNEL_PARTICIPANTS_RECENT
            and members_reader.read_i32() == 0
            and members_reader.read_i32() == 100
            and members_reader.read_i64() == 0
            and members_reader.remaining() == 0
        )
        report.checks.append(
            HealthCheck(
                "members_codec",
                members_ok,
                "channels.getParticipants request encoded" if members_ok else "mismatch",
            )
        )
    except Exception as exc:
        report.checks.append(HealthCheck("members_codec", False, type(exc).__name__))

    try:
        send_peer = Peer(id=1, type=PeerType.USER, access_hash=2)
        uploaded = UploadedFile(
            file_id=3, parts=1, size=10, big=False,
            remote_name="photo.jpeg", chunk_size=32 * 1024,
        )
        send_request = SendCodec.build_send_photo(
            send_peer, uploaded, "", random_id=4
        )
        send_ok = (
            len(send_request) == 88
            and int.from_bytes(send_request[4:8], "little", signed=True) == 136
            and send_request[-8:] == bytes.fromhex("15c4b51c00000000")
        )
        report.checks.append(
            HealthCheck(
                "send_codec",
                send_ok,
                "web-compatible photo request encoded" if send_ok else "mismatch",
            )
        )
    except Exception as exc:
        report.checks.append(HealthCheck("send_codec", False, type(exc).__name__))

    try:
        media_ref = MediaReference(
            type=MediaType.DOCUMENT,
            remote_id=10,
            access_hash=20,
            file_reference=b"ref",
            size=3,
            mime_type="application/pdf",
        )
        plan = MediaRequestCodec.build(
            media_ref, offset=0, limit=512 * 1024,
            method=MediaDownloadMethod.GET_FILE,
        )
        response = (
            TLWriter().write_i32(media_c.UPLOAD_FILE)
            .write_i32(0xAE1E508D).write_i32(0).write_bytes(b"pdf").to_bytes()
        )
        chunk = MediaResponseCodec.parse(response, offset=0, requested_limit=512 * 1024)
        media_ok = len(plan.payload) > 20 and chunk.data == b"pdf" and chunk.extension == "pdf"
        report.checks.append(HealthCheck("media_codec", media_ok, "download request/response valid"))
    except Exception as exc:
        report.checks.append(HealthCheck("media_codec", False, type(exc).__name__))


    try:
        membership_target = Peer(id=123, type=PeerType.CHANNEL, access_hash=456)
        membership_user = Peer(id=789, type=PeerType.USER, access_hash=987)
        invite_request = MembershipCodec.build_add_member(
            membership_target, membership_user
        )
        invite_reader = TLReader(invite_request)
        membership_ok = (
            invite_reader.read_u32() == membership_c.CHANNELS_INVITE_TO_CHANNEL
            and invite_reader.read_u32() == membership_c.INPUT_CHANNEL
            and invite_reader.read_i64() == 123
            and invite_reader.read_i64() == 456
        )
        report.checks.append(
            HealthCheck(
                "membership_codec",
                membership_ok,
                "channels.inviteToChannel request encoded"
                if membership_ok
                else "mismatch",
            )
        )
    except Exception as exc:
        report.checks.append(
            HealthCheck("membership_codec", False, type(exc).__name__)
        )

    database_ok = isinstance(config.database_file, Path) and SCHEMA_VERSION == 9
    report.checks.append(
        HealthCheck(
            "database_schema",
            database_ok,
            f"schema_version={SCHEMA_VERSION}; path={config.database_file}",
        )
    )

    endpoints = [config.api_endpoint, config.media_endpoint, *config.download_endpoints]
    endpoint_ok = all(
        urlparse(value).scheme == "https" and bool(urlparse(value).netloc)
        for value in endpoints
    )
    report.checks.append(
        HealthCheck("endpoints", endpoint_ok, f"configured={len(endpoints)}")
    )

    path_ok = isinstance(config.session_file, Path)
    report.checks.append(HealthCheck("session_path", path_ok, str(config.session_file)))
    database_path_ok = isinstance(config.database_file, Path)
    report.checks.append(HealthCheck("database_path", database_path_ok, str(config.database_file)))

    if diagnostics:
        diagnostics.write_report("doctor", report.as_dict())
        diagnostics.emit(
            "doctor",
            "local_health_completed",
            level="info" if report.ok else "error",
            fields=report.as_dict(),
        )
    return report

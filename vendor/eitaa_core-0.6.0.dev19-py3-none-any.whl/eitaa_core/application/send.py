"""Application service for outbound text, photo, and file operations."""

from __future__ import annotations

import mimetypes
import secrets
import time
from dataclasses import replace
from pathlib import Path

from ..domain.enums import SendKind
from ..domain.peer import Peer
from ..domain.phone import PhoneNumber
from ..domain.send import (
    MessageDeleteResult,
    SendResult,
    UploadedFile,
    UploadOptions,
    UploadProgress,
    UploadProgressCallback,
    validate_local_upload,
)
from ..errors import (
    DomainValidationError,
    EitaaCoreError,
    HttpStatusError,
    NetworkError,
    RpcError,
    SendValidationError,
    UploadFileError,
    UploadPartError,
)
from ..infrastructure.diagnostics import DiagnosticManager
from ..ports.send_repository import SendRepository
from .contacts import ContactService


class MessageSendService:
    """UI-independent outbound use cases.

    Local file I/O, bounded retries, and progress events live here.  TL
    serialization and HTTP calls remain in the repository adapter.  The same
    methods are therefore suitable for CLI, desktop UI, FastAPI, or tests.
    """

    def __init__(
        self,
        repository: SendRepository,
        contacts: ContactService,
        diagnostics: DiagnosticManager | None = None,
        *,
        max_text_length: int = 4096,
        max_caption_length: int = 1024,
        big_file_threshold: int = 10 * 1024 * 1024,
    ) -> None:
        self.repository = repository
        self.contacts = contacts
        self.diagnostics = diagnostics
        self.max_text_length = max_text_length
        self.max_caption_length = max_caption_length
        self.big_file_threshold = big_file_threshold

    def send_text(self, peer: Peer, text: str, *, random_id: int | None = None) -> SendResult:
        """Send one non-empty text message to a normalized peer."""
        peer.validate()
        self._validate_text(text)
        self._emit(
            "send_started",
            fields={"kind": SendKind.TEXT.value, "peer": peer.safe_summary(), "text_length": len(text)},
        )
        try:
            result = self.repository.send_text(
                peer, text, random_id=self._resolve_random_id(random_id)
            )
        except EitaaCoreError as exc:
            self._attach_error(exc, "send_text_failed", {"peer": peer.safe_summary(), "text_length": len(text)})
            raise
        self._emit("send_completed", fields=result.safe_summary())
        return result

    def send_photo(
        self,
        peer: Peer,
        path: Path | str,
        *,
        caption: str = "",
        upload_options: UploadOptions | None = None,
        progress: UploadProgressCallback | None = None,
        random_id: int | None = None,
    ) -> SendResult:
        """Upload and send one local image using the web-matched photo flow."""
        self._validate_caption(caption)
        resolved, size = self._prepare_file(path, upload_options)
        big = size >= self.big_file_threshold
        # This exact name was present in the successful web capture for normal
        # photos.  Big-file behavior retains the original name, as alpha15.4 did.
        remote_name = resolved.name if big else "photo.jpeg"
        uploaded = self._upload(
            peer,
            resolved,
            size=size,
            remote_name=remote_name,
            options=upload_options or UploadOptions(),
            progress=progress,
        )
        try:
            result = self.repository.send_photo(
                peer,
                uploaded,
                caption,
                random_id=self._resolve_random_id(random_id),
            )
        except EitaaCoreError as exc:
            self._attach_error(
                exc,
                "send_photo_failed",
                {"peer": peer.safe_summary(), "caption_length": len(caption), "uploaded": uploaded.safe_summary()},
            )
            raise
        self._emit("send_completed", fields=result.safe_summary())
        return result

    def send_file(
        self,
        peer: Peer,
        path: Path | str,
        *,
        caption: str = "",
        mime_type: str | None = None,
        upload_options: UploadOptions | None = None,
        progress: UploadProgressCallback | None = None,
        random_id: int | None = None,
    ) -> SendResult:
        """Upload and send one document using ``force_file`` semantics."""
        self._validate_caption(caption)
        resolved, size = self._prepare_file(path, upload_options)
        uploaded = self._upload(
            peer,
            resolved,
            size=size,
            remote_name=resolved.name,
            options=upload_options or UploadOptions(),
            progress=progress,
        )
        selected_mime = mime_type or mimetypes.guess_type(resolved.name)[0] or "application/octet-stream"
        try:
            result = self.repository.send_file(
                peer,
                uploaded,
                caption,
                mime_type=selected_mime,
                original_name=resolved.name,
                random_id=self._resolve_random_id(random_id),
            )
        except EitaaCoreError as exc:
            self._attach_error(
                exc,
                "send_file_failed",
                {
                    "peer": peer.safe_summary(),
                    "caption_length": len(caption),
                    "mime_type_present": bool(selected_mime),
                    "uploaded": uploaded.safe_summary(),
                },
            )
            raise
        self._emit("send_completed", fields=result.safe_summary())
        return result

    def delete_messages(
        self,
        message_ids: tuple[int, ...] | list[int],
        *,
        revoke: bool = True,
    ) -> MessageDeleteResult:
        """Delete previously sent private-message ids, optionally for both sides."""
        normalized = tuple(int(item) for item in message_ids)
        if not normalized or any(item <= 0 for item in normalized):
            raise SendValidationError("Message ids for deletion must be positive.")
        if len(normalized) > 100:
            raise SendValidationError("At most 100 message ids may be deleted per request.")
        self._emit(
            "delete_messages_started",
            fields={"message_count": len(normalized), "revoke": revoke},
        )
        try:
            result = self.repository.delete_messages(normalized, revoke=revoke)
        except EitaaCoreError as exc:
            self._attach_error(
                exc,
                "delete_messages_failed",
                {"message_count": len(normalized), "revoke": revoke},
            )
            raise
        self._emit("delete_messages_completed", fields=result.safe_summary())
        return result

    def send_text_to_phone(
        self,
        phone: PhoneNumber | str,
        text: str,
        *,
        first_name: str = "Eitaa",
        last_name: str = "",
        import_if_missing: bool = True,
    ) -> SendResult:
        """Resolve or import a phone contact, then send text."""
        resolution = self.contacts.resolve(
            phone,
            first_name=first_name,
            last_name=last_name,
            import_if_missing=import_if_missing,
        )
        return replace(
            self.send_text(resolution.contact.user.peer, text),
            resolution_source=resolution.source,
            contact_added=resolution.contact_added,
        )

    def send_photo_to_phone(
        self,
        phone: PhoneNumber | str,
        path: Path | str,
        *,
        caption: str = "",
        first_name: str = "Eitaa",
        last_name: str = "",
        import_if_missing: bool = True,
        upload_options: UploadOptions | None = None,
        progress: UploadProgressCallback | None = None,
    ) -> SendResult:
        """Resolve or import a phone contact, then upload and send a photo."""
        resolution = self.contacts.resolve(
            phone,
            first_name=first_name,
            last_name=last_name,
            import_if_missing=import_if_missing,
        )
        return replace(
            self.send_photo(
                resolution.contact.user.peer,
                path,
                caption=caption,
                upload_options=upload_options,
                progress=progress,
            ),
            resolution_source=resolution.source,
            contact_added=resolution.contact_added,
        )

    def send_file_to_phone(
        self,
        phone: PhoneNumber | str,
        path: Path | str,
        *,
        caption: str = "",
        mime_type: str | None = None,
        first_name: str = "Eitaa",
        last_name: str = "",
        import_if_missing: bool = True,
        upload_options: UploadOptions | None = None,
        progress: UploadProgressCallback | None = None,
    ) -> SendResult:
        """Resolve or import a phone contact, then upload and send a file."""
        resolution = self.contacts.resolve(
            phone,
            first_name=first_name,
            last_name=last_name,
            import_if_missing=import_if_missing,
        )
        return replace(
            self.send_file(
                resolution.contact.user.peer,
                path,
                caption=caption,
                mime_type=mime_type,
                upload_options=upload_options,
                progress=progress,
            ),
            resolution_source=resolution.source,
            contact_added=resolution.contact_added,
        )

    def _upload(
        self,
        peer: Peer,
        path: Path,
        *,
        size: int,
        remote_name: str,
        options: UploadOptions,
        progress: UploadProgressCallback | None,
    ) -> UploadedFile:
        peer.validate()
        options.validate()
        chunk_size = self.choose_chunk_size(size, options.chunk_size)
        total_parts = (size + chunk_size - 1) // chunk_size
        big = size >= self.big_file_threshold
        file_id = self._random_id()
        bytes_sent = 0
        self._emit_upload(
            "upload_started",
            fields={
                "peer": peer.safe_summary(),
                "size": size,
                "parts": total_parts,
                "big": big,
                "chunk_size": chunk_size,
                "options": options.safe_summary(),
            },
        )
        self._notify(progress, UploadProgress("started", 0, size, 0, total_parts))
        try:
            with path.open("rb") as handle:
                for part_index in range(total_parts):
                    chunk = handle.read(chunk_size)
                    if not chunk:
                        raise UploadFileError(
                            "Local file ended before all expected upload parts were read.",
                            safe_context={
                                "part_index": part_index,
                                "total_parts": total_parts,
                                "bytes_read": bytes_sent,
                                "expected_size": size,
                            },
                        )
                    ok = False
                    last_error: EitaaCoreError | None = None
                    for attempt in range(1, options.part_max_attempts + 1):
                        self._notify(
                            progress,
                            UploadProgress(
                                "part_started",
                                bytes_sent,
                                size,
                                part_index,
                                total_parts,
                                current_part=part_index,
                                attempt=attempt,
                            ),
                        )
                        try:
                            ok = self.repository.upload_part(
                                peer,
                                file_id=file_id,
                                part_index=part_index,
                                total_parts=total_parts,
                                total_size=size,
                                chunk=chunk,
                                big=big,
                            )
                            if ok:
                                break
                        except EitaaCoreError as exc:
                            last_error = exc
                            if not self._is_retryable_upload_error(exc):
                                self._attach_upload_error(
                                    exc, "upload_part_non_retryable_failure"
                                )
                                raise
                        self._emit_upload(
                            "upload_part_retry",
                            level="warning",
                            fields={
                                "part_index": part_index,
                                "total_parts": total_parts,
                                "attempt": attempt,
                                "max_attempts": options.part_max_attempts,
                                "error_type": type(last_error).__name__ if last_error else None,
                            },
                        )
                        if attempt < options.part_max_attempts and options.retry_delay_seconds:
                            time.sleep(options.retry_delay_seconds)
                    if not ok:
                        error = UploadPartError(
                            "Upload part failed after bounded retry attempts.",
                            safe_context={
                                "part_index": part_index,
                                "total_parts": total_parts,
                                "attempts": options.part_max_attempts,
                                "last_error_type": type(last_error).__name__ if last_error else None,
                            },
                            debug_file=(last_error.debug_file if last_error else None),
                        )
                        self._attach_upload_error(error, "upload_part_exhausted")
                        raise error
                    bytes_sent += len(chunk)
                    self._notify(
                        progress,
                        UploadProgress(
                            "part_completed",
                            bytes_sent,
                            size,
                            part_index + 1,
                            total_parts,
                            current_part=part_index,
                        ),
                    )
                    if part_index + 1 < total_parts and options.request_delay_seconds:
                        time.sleep(options.request_delay_seconds)
        except OSError as exc:
            error = UploadFileError(
                "Local upload file could not be read.",
                safe_context={"error_type": type(exc).__name__, "bytes_read": bytes_sent},
            )
            self._attach_upload_error(error, "upload_file_read_failed")
            raise error from exc

        uploaded = UploadedFile(
            file_id=file_id,
            parts=total_parts,
            size=size,
            big=big,
            remote_name=remote_name,
            chunk_size=chunk_size,
            md5_checksum="",
        )
        self._notify(
            progress,
            UploadProgress("completed", size, size, total_parts, total_parts),
        )
        self._emit_upload("upload_completed", fields=uploaded.safe_summary())
        return uploaded

    def _prepare_file(
        self, path: Path | str, options: UploadOptions | None
    ) -> tuple[Path, int]:
        try:
            return validate_local_upload(Path(path), options or UploadOptions())
        except DomainValidationError as exc:
            error = UploadFileError(
                exc.message,
                safe_context=exc.safe_context,
            )
            self._attach_upload_error(error, "upload_file_validation_failed")
            raise error from exc

    def _validate_text(self, text: str) -> None:
        if not isinstance(text, str) or not text:
            raise SendValidationError("Message text cannot be empty.")
        if len(text) > self.max_text_length:
            raise SendValidationError(
                "Message text exceeds the configured maximum length.",
                safe_context={"text_length": len(text), "max_text_length": self.max_text_length},
            )

    def _validate_caption(self, caption: str) -> None:
        if not isinstance(caption, str):
            raise SendValidationError("Caption must be a string.")
        if len(caption) > self.max_caption_length:
            raise SendValidationError(
                "Caption exceeds the configured maximum length.",
                safe_context={"caption_length": len(caption), "max_caption_length": self.max_caption_length},
            )

    @staticmethod
    def choose_chunk_size(size: int, requested: int = 0) -> int:
        """Choose the same size bands used by the proven alpha15 uploader."""
        if requested > 0:
            return requested
        if size < 100 * 1024:
            return 32 * 1024
        if size > 64 * 1024 * 1024:
            return 512 * 1024
        return 256 * 1024

    @staticmethod
    def _is_retryable_upload_error(error: EitaaCoreError) -> bool:
        """Return whether retrying the same upload part may reasonably help."""
        if isinstance(error, (NetworkError, HttpStatusError)):
            return True
        if isinstance(error, RpcError):
            return error.code >= 500
        return False

    @staticmethod
    def _resolve_random_id(value: int | None) -> int:
        """Return a stable signed int64 id, generating one when absent."""
        if value is None:
            return MessageSendService._random_id()
        if not isinstance(value, int) or not -(2**63) <= value <= 2**63 - 1 or value == 0:
            raise SendValidationError(
                "random_id must be a non-zero signed int64.",
                safe_context={"random_id_type": type(value).__name__},
            )
        return value

    @staticmethod
    def _random_id() -> int:
        return secrets.randbits(63) or 1

    def _notify(
        self,
        callback: UploadProgressCallback | None,
        event: UploadProgress,
    ) -> None:
        if callback is None:
            return
        try:
            callback(event)
        except Exception as exc:  # frontend callback must not corrupt the upload
            self._emit_upload(
                "progress_callback_failed",
                level="warning",
                fields={"error_type": type(exc).__name__, "phase": event.phase},
            )

    def _attach_error(
        self, error: EitaaCoreError, event: str, fields: dict[str, object]
    ) -> None:
        debug = self._emit(event, level="error", fields={**fields, "error_type": type(error).__name__})
        if not error.debug_file:
            error.debug_file = debug

    def _attach_upload_error(self, error: EitaaCoreError, event: str) -> None:
        debug = self._emit_upload(
            event,
            level="error",
            fields={"error_type": type(error).__name__, "safe_context": error.safe_context},
        )
        if not error.debug_file:
            error.debug_file = debug

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("send", event, level=level, fields=fields)

    def _emit_upload(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("upload", event, level=level, fields=fields)

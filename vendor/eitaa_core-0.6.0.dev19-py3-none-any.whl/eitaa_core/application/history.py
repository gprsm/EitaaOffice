"""History fetching, local message access, and synchronization services."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Sequence

from ..domain.message import (
    HistoryPage,
    HistoryQuery,
    Message,
    MessageWriteStats,
    ReadHistoryResult,
    SyncResult,
)
from ..domain.peer import Peer
from ..domain.workflow import DateRangeSyncResult, MessageSearchPage, MessageSearchQuery
from ..errors import DomainValidationError
from ..infrastructure.diagnostics import DiagnosticManager
from ..ports.history_repository import HistoryRepository
from ..ports.message_repository import MessageRepository
from ..ports.dialog_store_repository import DialogStoreRepository


class HistoryService:
    """Read remote history without coupling callers to TL or HTTP."""

    def __init__(
        self,
        repository: HistoryRepository,
        diagnostics: DiagnosticManager | None = None,
        dialog_store: DialogStoreRepository | None = None,
    ) -> None:
        self.repository = repository
        self.diagnostics = diagnostics
        self.dialog_store = dialog_store

    def fetch(self, peer: Peer, query: HistoryQuery | None = None) -> HistoryPage:
        """Fetch one page from Eitaa."""
        peer.validate()
        page = self.repository.get_history(peer, query or HistoryQuery())
        if self.diagnostics:
            self.diagnostics.emit(
                "history", "history_service_fetch", fields=page.safe_summary()
            )
        return page

    def mark_read(
        self, peer: Peer, max_id: int, *, remaining_unread_count: int | None = None
    ) -> ReadHistoryResult:
        """Mark messages through ``max_id`` read and align the local snapshot."""
        peer.validate()
        if not isinstance(max_id, int) or max_id <= 0:
            raise DomainValidationError("max_id must be a positive integer.")
        if remaining_unread_count is not None and remaining_unread_count < 0:
            raise DomainValidationError("remaining_unread_count cannot be negative.")
        result = self.repository.mark_read(peer, max_id)
        if result.accepted and self.dialog_store is not None:
            self.dialog_store.mark_read(
                peer, max_id=max_id, remaining_unread_count=remaining_unread_count
            )
        if self.diagnostics:
            self.diagnostics.emit("history", "history_service_mark_read", fields=result.safe_summary())
        return result


class MessageStoreService:
    """Safe application interface over the local message repository."""

    def __init__(self, repository: MessageRepository) -> None:
        self.repository = repository

    def save(self, messages: Sequence[Message]) -> MessageWriteStats:
        return self.repository.upsert_many(messages)

    def get(self, peer: Peer, message_id: int) -> Message | None:
        return self.repository.get(peer, message_id)

    def list(
        self,
        peer: Peer,
        *,
        limit: int = 100,
        before_id: int | None = None,
    ) -> tuple[Message, ...]:
        return self.repository.list_by_peer(peer, limit=limit, before_id=before_id)

    def list_album(self, peer: Peer, grouped_id: int) -> tuple[Message, ...]:
        """Return all locally stored members of one server-declared media album."""
        if not isinstance(grouped_id, int) or isinstance(grouped_id, bool) or grouped_id == 0:
            raise DomainValidationError("grouped_id must be a non-zero integer.")
        return self.repository.list_by_grouped_id(peer, grouped_id)

    def search(self, query: MessageSearchQuery) -> MessageSearchPage:
        """Search locally stored messages with stable keyset pagination."""
        return self.repository.search(query)

    def content_hash(self, peer: Peer, message_id: int) -> str | None:
        """Return the current deterministic hash used by publication workflows."""
        return self.repository.content_hash(peer, message_id)

    def count(self, peer: Peer | None = None) -> int:
        return self.repository.count(peer)

    def oldest_id(self, peer: Peer) -> int | None:
        return self.repository.oldest_message_id(peer)

    def newest_id(self, peer: Peer) -> int | None:
        return self.repository.newest_message_id(peer)


class SyncService:
    """Coordinate remote history pages and local deduplicating storage."""

    def __init__(
        self,
        history: HistoryService,
        store: MessageStoreService,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.history = history
        self.store = store
        self.diagnostics = diagnostics

    def sync(
        self,
        peer: Peer,
        *,
        pages: int = 1,
        page_size: int = 20,
        offset_id: int = 0,
        stop_when_unchanged: bool = False,
    ) -> SyncResult:
        """Fetch and store up to ``pages`` pages.

        ``offset_id=0`` starts from the newest server page. To continue an old
        backfill, pass the previous result's ``next_offset_id``. The service
        guards against repeated offsets and short/empty pages.
        """
        self._validate_page_args(pages, page_size)
        current_offset = offset_id
        seen_offsets: set[int] = set()
        fetched = page_count = 0
        inserted = updated = unchanged = 0
        next_offset: int | None = None
        stopped_reason = "page_limit"

        self._emit(
            "sync",
            "sync_started",
            fields={
                "peer": peer.safe_summary(),
                "pages": pages,
                "page_size": page_size,
                "offset_id": offset_id,
                "stop_when_unchanged": stop_when_unchanged,
            },
        )
        for _ in range(pages):
            if current_offset in seen_offsets:
                stopped_reason = "repeated_offset"
                break
            seen_offsets.add(current_offset)
            page = self.history.fetch(
                peer,
                HistoryQuery(limit=page_size, offset_id=current_offset),
            )
            page_count += 1
            fetched += len(page.messages)
            stats = self.store.save(page.messages)
            inserted += stats.inserted
            updated += stats.updated
            unchanged += stats.unchanged
            next_offset = page.next_offset_id
            self._emit(
                "sync",
                "sync_page_completed",
                fields={
                    "page_number": page_count,
                    "page": page.safe_summary(),
                    "write": stats.safe_summary(),
                },
            )
            if not page.messages:
                stopped_reason = "empty_page"
                break
            if stop_when_unchanged and stats.inserted == 0 and stats.updated == 0:
                stopped_reason = "unchanged_page"
                break
            if next_offset is None or next_offset == current_offset:
                stopped_reason = "no_next_offset"
                break
            if len(page.messages) < page_size:
                stopped_reason = "short_page"
                break
            current_offset = next_offset
        result = SyncResult(
            peer=peer,
            pages=page_count,
            fetched=fetched,
            stored=MessageWriteStats(inserted, updated, unchanged),
            next_offset_id=next_offset,
            stopped_reason=stopped_reason,
        )
        self._emit("sync", "sync_completed", fields=result.safe_summary())
        return result

    def sync_date_range(
        self,
        peer: Peer,
        *,
        date_from: datetime,
        date_to: datetime,
        pages: int = 100,
        page_size: int = 100,
        store: bool = True,
    ) -> DateRangeSyncResult:
        """Retrieve messages inside an inclusive UTC date/time range.

        Eitaa history is cursor-based rather than a direct SQL-like date query.
        The first page uses ``offset_date=date_to``; subsequent pages continue
        with ``offset_id`` until the oldest returned message is earlier than
        ``date_from`` or another safe stop condition is reached.  Only messages
        inside the requested range are persisted.
        """
        self._validate_page_args(pages, page_size)
        if date_from.tzinfo is None or date_to.tzinfo is None:
            raise DomainValidationError("date_from and date_to must be timezone-aware.")
        date_from = date_from.astimezone(timezone.utc)
        date_to = date_to.astimezone(timezone.utc)
        if date_from > date_to:
            raise DomainValidationError("date_from cannot be after date_to.")

        current_offset = 0
        first_offset_date = int(date_to.timestamp())
        seen_offsets: set[int] = set()
        page_count = fetched = matched = 0
        inserted = updated = unchanged = 0
        next_offset: int | None = None
        stopped_reason = "page_limit"

        self._emit(
            "date_sync",
            "date_range_sync_started",
            fields={
                "peer": peer.safe_summary(),
                "date_from": date_from.isoformat(),
                "date_to": date_to.isoformat(),
                "pages": pages,
                "page_size": page_size,
                "store": store,
            },
        )

        for index in range(pages):
            if current_offset in seen_offsets:
                stopped_reason = "repeated_offset"
                break
            seen_offsets.add(current_offset)
            page = self.history.fetch(
                peer,
                HistoryQuery(
                    limit=page_size,
                    offset_id=current_offset,
                    offset_date=first_offset_date if index == 0 else 0,
                ),
            )
            page_count += 1
            fetched += len(page.messages)
            in_range = tuple(
                message
                for message in page.messages
                if date_from <= message.date.astimezone(timezone.utc) <= date_to
            )
            matched += len(in_range)
            stats = self.store.save(in_range) if store else MessageWriteStats()
            inserted += stats.inserted
            updated += stats.updated
            unchanged += stats.unchanged
            next_offset = page.next_offset_id

            dates = [item.date.astimezone(timezone.utc) for item in page.messages]
            passed_lower_bound = bool(dates and min(dates) < date_from)
            self._emit(
                "date_sync",
                "date_range_page_completed",
                fields={
                    "page_number": page_count,
                    "page": page.safe_summary(),
                    "matched": len(in_range),
                    "write": stats.safe_summary(),
                    "passed_lower_bound": passed_lower_bound,
                },
            )

            if not page.messages:
                stopped_reason = "empty_page"
                break
            if passed_lower_bound:
                stopped_reason = "passed_start_date"
                break
            if next_offset is None or next_offset == current_offset:
                stopped_reason = "no_next_offset"
                break
            if len(page.messages) < page_size:
                stopped_reason = "short_page"
                break
            current_offset = next_offset

        result = DateRangeSyncResult(
            peer=peer,
            date_from=date_from,
            date_to=date_to,
            pages=page_count,
            fetched=fetched,
            matched=matched,
            stored=MessageWriteStats(inserted, updated, unchanged),
            next_offset_id=next_offset,
            stopped_reason=stopped_reason,
        )
        self._emit("date_sync", "date_range_sync_completed", fields=result.safe_summary())
        return result

    @staticmethod
    def _validate_page_args(pages: int, page_size: int) -> None:
        if not 1 <= pages <= 10_000:
            raise DomainValidationError("pages must be between 1 and 10000.")
        if not 1 <= page_size <= 100:
            raise DomainValidationError("page_size must be between 1 and 100.")

    def _emit(
        self,
        component: str,
        event: str,
        *,
        fields: dict[str, object],
    ) -> None:
        if self.diagnostics:
            self.diagnostics.emit(component, event, fields=fields)

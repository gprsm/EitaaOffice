"""Application service for native media downloads."""

from __future__ import annotations

import mimetypes
import time
from pathlib import Path
from typing import Callable, Iterable

from ..domain.enums import MediaDownloadMethod, MediaType
from ..domain.discovery import PeerPhotoReference
from ..domain.media import (
    MediaDownloadOptions,
    MediaDownloadResult,
    MediaReference,
    RemoteMediaReference,
)
from ..errors import (
    MediaDownloadError,
    MediaIncompleteError,
    MediaTooLargeError,
    MediaValidationError,
)
from ..infrastructure.diagnostics import DiagnosticManager
from ..infrastructure.media.storage import LocalMediaStorage, sanitize_file_name
from ..ports.media_repository import MediaRepository


_MIME_EXTENSIONS = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/gif": "gif",
    "image/webp": "webp",
    "audio/mpeg": "mp3",
    "video/mp4": "mp4",
    "application/pdf": "pdf",
}


class MediaDownloadService:
    """Download photo/document/audio/video/sticker references without UI concerns."""

    def __init__(
        self,
        repository: MediaRepository,
        storage: LocalMediaStorage,
        diagnostics: DiagnosticManager | None = None,
        default_output_directory: Path = Path("data/media"),
        peer_photo_resolver: Callable[[PeerPhotoReference], MediaReference] | None = None,
    ) -> None:
        self.repository = repository
        self.storage = storage
        self.diagnostics = diagnostics
        self.default_output_directory = Path(default_output_directory)
        self.peer_photo_resolver = peer_photo_resolver

    def download(
        self,
        media: RemoteMediaReference,
        options: MediaDownloadOptions | None = None,
    ) -> MediaDownloadResult:
        """Download one media object in bounded chunks and finalize atomically."""
        options = options or MediaDownloadOptions(
            output_directory=self.default_output_directory
        )
        options.validate()
        if isinstance(media, PeerPhotoReference) and self.peer_photo_resolver is not None:
            media = self.peer_photo_resolver(media)
        self._validate_media(media)
        declared_size = getattr(media, "size", None)
        if options.max_bytes is not None and declared_size is not None and declared_size > options.max_bytes:
            raise MediaTooLargeError(
                "Declared media size exceeds the configured limit.",
                safe_context={"declared_size": declared_size, "max_bytes": options.max_bytes},
            )
        preferred_name = options.file_name or self._default_name(media)
        pending = self.storage.prepare(
            options.output_directory,
            preferred_name,
            overwrite=options.overwrite,
        )
        methods = self._method_order(media, options.method)
        offset = chunks = 0
        expected_size: int | None = declared_size
        endpoint_index: int | None = None
        endpoint: str | None = None
        selected_method: MediaDownloadMethod | None = None
        extension: str | None = self._extension_hint(media)
        used_cached = False
        self._emit(
            "download_started",
            fields={"media": media.safe_summary(), "options": options.safe_summary()},
        )
        try:
            while True:
                if expected_size is not None and offset >= expected_size:
                    break
                if options.max_bytes is not None and offset >= options.max_bytes:
                    raise MediaTooLargeError(
                        "Configured media size limit was reached.",
                        safe_context={"downloaded": offset, "max_bytes": options.max_bytes},
                    )
                limit = options.chunk_size
                if expected_size is not None:
                    limit = min(limit, expected_size - offset)
                if options.max_bytes is not None:
                    limit = min(limit, options.max_bytes - offset)
                if limit <= 0:
                    break
                if chunks and options.request_delay_seconds:
                    time.sleep(options.request_delay_seconds)
                chunk = None
                failures: list[str] = []
                for method in ([selected_method] if selected_method else methods):
                    if method is None:
                        continue
                    try:
                        chunk = self.repository.fetch_chunk(
                            media,
                            offset=offset,
                            limit=limit,
                            method=method,
                            thumb_type=options.photo_thumb_type,
                            endpoint_index=endpoint_index,
                        )
                        selected_method = method
                        break
                    except MediaDownloadError as exc:
                        failures.append(type(exc).__name__)
                if chunk is None:
                    cached = (
                        self._best_cached_bytes(media)
                        if offset == 0 and options.allow_cached_fallback
                        else None
                    )
                    if cached:
                        self.storage.append(pending, cached)
                        offset = len(cached)
                        chunks = 1
                        used_cached = True
                        extension = extension or "jpg"
                        break
                    raise MediaDownloadError(
                        "All configured download methods failed.",
                        safe_context={"offset": offset, "methods": [item.value for item in methods], "failures": failures},
                    )
                endpoint_index = chunk.endpoint_index
                endpoint = chunk.endpoint
                expected_size = expected_size or chunk.expected_size
                extension = self._choose_extension(media, chunk.extension, extension)
                if not chunk.data:
                    break
                self.storage.append(pending, chunk.data)
                offset += len(chunk.data)
                chunks += 1
                if len(chunk.data) < limit:
                    break
            if offset <= 0:
                cached = self._best_cached_bytes(media) if options.allow_cached_fallback else None
                if cached:
                    self.storage.append(pending, cached)
                    offset = len(cached)
                    chunks = 1
                    used_cached = True
                else:
                    raise MediaDownloadError("No media bytes were downloaded.")
            if expected_size and not used_cached and offset < expected_size:
                raise MediaIncompleteError(
                    "Media download ended before the declared size.",
                    safe_context={"downloaded": offset, "expected_size": expected_size},
                )
            path = self.storage.finalize(pending, extension=extension)
            result = MediaDownloadResult(
                media=media,
                path=path,
                bytes_written=offset,
                chunks=chunks,
                method=selected_method,
                endpoint=endpoint,
                complete=(expected_size is None or offset >= expected_size) and not used_cached,
                used_cached_bytes=used_cached,
            )
            self._emit("download_completed", fields=result.safe_summary())
            return result
        except Exception as exc:
            partial = self.storage.abort(pending, keep_nonempty=options.keep_partial_on_error)
            debug = self._emit(
                "download_failed",
                level="error",
                fields={
                    "media": media.safe_summary(),
                    "error_type": type(exc).__name__,
                    "downloaded_bytes": offset,
                    "chunks": chunks,
                    "partial_file_present": partial is not None,
                },
            )
            if isinstance(exc, MediaDownloadError):
                if not exc.debug_file:
                    exc.debug_file = debug
                raise
            raise MediaDownloadError(
                "Unexpected failure while downloading media.",
                safe_context={"error_type": type(exc).__name__, "downloaded_bytes": offset},
                debug_file=debug,
            ) from exc

    def download_many(
        self,
        media_items: Iterable[RemoteMediaReference],
        options: MediaDownloadOptions | None = None,
    ) -> tuple[MediaDownloadResult, ...]:
        """Download multiple references sequentially to respect server rate limits."""
        return tuple(self.download(item, options) for item in media_items)

    @staticmethod
    def _validate_media(media: RemoteMediaReference) -> None:
        if isinstance(media, PeerPhotoReference):
            media.peer.validate()
            return
        if media.type in {MediaType.NONE, MediaType.UNKNOWN}:
            raise MediaValidationError(
                "This media type is not downloadable by Core 4.2.",
                safe_context={"media_type": media.type.value},
            )

    @staticmethod
    def _method_order(media: RemoteMediaReference, requested: MediaDownloadMethod) -> tuple[MediaDownloadMethod, ...]:
        if requested is not MediaDownloadMethod.AUTO:
            return (requested,)
        if isinstance(media, PeerPhotoReference):
            return (MediaDownloadMethod.GET_FILE, MediaDownloadMethod.GET_FILE2)
        if media.type is MediaType.PHOTO:
            return (MediaDownloadMethod.GET_FILE2, MediaDownloadMethod.GET_FILE)
        return (MediaDownloadMethod.GET_FILE, MediaDownloadMethod.GET_FILE2)

    @staticmethod
    def _default_name(media: RemoteMediaReference) -> str:
        if isinstance(media, PeerPhotoReference):
            return f"avatar_{media.peer.type.value}_{media.peer.id}_{media.photo_id}"
        if media.file_name:
            return sanitize_file_name(media.file_name)
        prefix = "photo" if media.type is MediaType.PHOTO else media.type.value
        return f"{prefix}_{media.remote_id or 'unknown'}"

    @staticmethod
    def _extension_hint(media: RemoteMediaReference) -> str | None:
        if isinstance(media, PeerPhotoReference):
            return "jpg"
        if media.file_name and Path(media.file_name).suffix:
            return Path(media.file_name).suffix.lstrip(".").lower()
        if media.mime_type:
            return _MIME_EXTENSIONS.get(media.mime_type.lower()) or (mimetypes.guess_extension(media.mime_type) or "").lstrip(".") or None
        return None

    @staticmethod
    def _choose_extension(media: RemoteMediaReference, server: str | None, hint: str | None) -> str:
        if isinstance(media, PeerPhotoReference):
            return server if server and server not in {"bin", "part"} else "jpg"
        if media.file_name and Path(media.file_name).suffix:
            return Path(media.file_name).suffix.lstrip(".").lower()
        if server and server not in {"bin", "part"}:
            return server
        return hint or server or "bin"

    @staticmethod
    def _best_cached_bytes(media: RemoteMediaReference) -> bytes | None:
        if isinstance(media, PeerPhotoReference):
            return None
        candidates = [item for item in media.photo_sizes if item.cached_bytes]
        if not candidates:
            return None
        return max(candidates, key=lambda item: len(item.cached_bytes or b"")).cached_bytes

    def _emit(self, event: str, *, level: str = "info", fields: dict[str, object]) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("media", event, level=level, fields=fields)

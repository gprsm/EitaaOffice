"""Application service for dialogs and public peer discovery."""

from __future__ import annotations

import time
from dataclasses import replace
from pathlib import Path

from ..domain.discovery import DialogCollection, DialogPage, PeerPhotoReference, UsernameResolution
from ..domain.media import MediaReference
from ..domain.enums import DialogKind
from ..domain.peer import Peer
from ..infrastructure.diagnostics import DiagnosticManager
from ..peer_files import save_peer_file
from ..ports.discovery_repository import DiscoveryRepository
from ..ports.dialog_store_repository import DialogStoreRepository


class DiscoveryService:
    """Expose peer discovery without leaking TL or transport details."""

    def __init__(
        self,
        repository: DiscoveryRepository,
        diagnostics: DiagnosticManager | None = None,
        store: DialogStoreRepository | None = None,
    ) -> None:
        self.repository = repository
        self.diagnostics = diagnostics
        self.store = store

    def list_dialogs(
        self,
        *,
        limit: int = 50,
        offset_date: int = 0,
        offset_id: int = 0,
        offset_peer: Peer | None = None,
        exclude_pinned: bool = False,
        folder_id: int | None = None,
    ) -> DialogPage:
        return self.repository.get_dialogs(
            limit=limit,
            offset_date=offset_date,
            offset_id=offset_id,
            offset_peer=offset_peer,
            exclude_pinned=exclude_pinned,
            folder_id=folder_id,
            hash_value=0,
        )

    def list_all_dialogs(
        self,
        *,
        page_size: int = 100,
        max_pages: int = 100,
        folder_id: int | None = None,
        request_delay_seconds: float = 0.15,
        persist: bool = True,
    ) -> DialogCollection:
        """Fetch the entire keyset-paginated dialog list from one API DC.

        Eitaa may return fewer rows than ``page_size`` (commonly 25) while the
        response is still a ``dialogsSlice``.  Therefore a short page is not a
        termination condition.
        """
        if not 1 <= page_size <= 100:
            raise ValueError("page_size must be between 1 and 100")
        if max_pages < 1:
            raise ValueError("max_pages must be positive")
        if request_delay_seconds < 0:
            raise ValueError("request_delay_seconds cannot be negative")

        dialogs = []
        seen: set[tuple[str, int]] = set()
        cursor_keys: set[tuple[int, int, str, int]] = set()
        warnings: list[str] = []
        duplicates = 0
        total_count: int | None = None
        cursor = None
        complete = False
        pages_fetched = 0

        first_page_of_pass = True
        stabilization_restarts = 0
        while pages_fetched < max_pages:
            page_number = pages_fetched + 1
            if pages_fetched and request_delay_seconds:
                time.sleep(request_delay_seconds)
            page = self.list_dialogs(
                limit=page_size,
                offset_date=cursor.offset_date if cursor else 0,
                offset_id=cursor.offset_id if cursor else 0,
                offset_peer=cursor.offset_peer if cursor else None,
                # Eitaa can cap the first page at 25 even when more than 25
                # dialogs are pinned. Excluding pinned rows on page two would
                # permanently hide the remaining pinned dialogs. Keep them in
                # every page and de-duplicate locally.
                exclude_pinned=False,
                folder_id=folder_id,
            )
            pages_fetched += 1
            warnings.extend(f"page{page_number}:{item}" for item in page.parse_warnings)
            if page.total_count is not None:
                total_count = max(total_count or 0, page.total_count)
            for item in page.dialogs:
                key = (item.peer.type.value, item.peer.id)
                if key in seen:
                    duplicates += 1
                    continue
                seen.add(key)
                dialogs.append(item)

            if total_count is not None and len(dialogs) >= total_count:
                complete = True
                break
            if page.response_type != "messages.dialogsSlice":
                if total_count is None:
                    complete = True
                    break
                if stabilization_restarts < 2 and pages_fetched < max_pages:
                    stabilization_restarts += 1
                    warnings.append(
                        f"stabilization_restart:{len(dialogs)}/{total_count}"
                    )
                    cursor = None
                    cursor_keys.clear()
                    first_page_of_pass = True
                    continue
                warnings.append(
                    f"stable_end_before_total:{len(dialogs)}/{total_count}"
                )
                break
            if not page.dialogs:
                warnings.append(f"page{page_number}:empty_slice_before_total")
                break
            if page.next_cursor is None:
                warnings.append(f"page{page_number}:missing_next_cursor")
                break
            cursor_key = page.next_cursor.key()
            if cursor_key in cursor_keys:
                warnings.append(f"page{page_number}:repeated_next_cursor")
                break
            cursor_keys.add(cursor_key)
            cursor = page.next_cursor
            first_page_of_pass = False
        if pages_fetched >= max_pages and not complete:
            warnings.append("max_pages_reached")

        provisional = DialogCollection(
            dialogs=tuple(dialogs),
            total_count=total_count,
            pages_fetched=pages_fetched,
            duplicate_count=duplicates,
            complete=complete,
            parse_warnings=tuple(warnings),
        )
        stored = self.store.store_snapshot(provisional) if persist and self.store else 0
        result = replace(provisional, stored_count=stored)
        if self.diagnostics:
            self.diagnostics.emit("discovery", "all_dialogs_fetched", fields=result.safe_summary())
        return result

    def cached_dialogs(
        self,
        *,
        kind: DialogKind | None = None,
        active_only: bool = True,
        limit: int = 10_000,
    ) -> tuple:
        if not self.store:
            return ()
        return self.store.list_dialogs(kind=kind, active_only=active_only, limit=limit)

    def set_cached_photo_path(self, peer: Peer, photo_id: int, path: Path | str) -> None:
        if self.store:
            self.store.set_photo_cache(peer, photo_id, str(path))

    def store_dialog_snapshot(self, result: DialogCollection) -> int:
        """Persist a caller-assembled public dialog collection."""
        return self.store.store_snapshot(result) if self.store else 0

    def mark_cached_read(
        self, peer: Peer, *, max_id: int, remaining_unread_count: int | None = None
    ):
        """Keep the local dialog snapshot aligned after a successful read RPC."""
        if not self.store:
            return None
        return self.store.mark_read(
            peer, max_id=max_id, remaining_unread_count=remaining_unread_count
        )

    def resolve_username(self, username: str) -> UsernameResolution:
        return self.repository.resolve_username(username)

    def resolve_peer_photo(self, photo: PeerPhotoReference) -> MediaReference:
        """Resolve a lightweight dialog photo into a downloadable full Photo."""
        return self.repository.resolve_peer_photo(photo)

    def save_peer(self, peer: Peer, path: Path | str) -> Path:
        """Persist a discovered peer atomically for CLI/UI reuse."""
        destination = Path(path)
        save_peer_file(destination, peer)
        if self.diagnostics:
            self.diagnostics.emit(
                "discovery", "peer_file_saved",
                fields={"path": str(destination), "peer": peer.safe_summary()},
            )
        return destination

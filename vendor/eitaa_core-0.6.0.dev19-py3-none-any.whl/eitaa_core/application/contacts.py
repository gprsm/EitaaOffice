"""Contact application service.

This layer contains the use-case decisions shared by CLI, GUI, and future HTTP
middleware: normalize a phone number, prefer an existing contact, import only
when necessary, and never infer that a hidden status means offline.
"""

from __future__ import annotations

from ..domain.enums import ContactResolutionSource, PeerType
from ..domain.peer import Peer
from ..domain.phone import PhoneNumber
from ..domain.user import (
    Contact,
    ContactDeleteResult,
    ContactResolution,
    ContactSnapshot,
    User,
    UserStatus,
)
from ..errors import (
    ContactImportRetryError,
    ContactNotFoundError,
    ContactResolveError,
    EitaaCoreError,
)
from ..infrastructure.diagnostics import DiagnosticManager
from ..ports.contact_repository import ContactRepository


class ContactService:
    """High-level contact use cases independent of TL and HTTP details."""

    def __init__(
        self,
        repository: ContactRepository,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.repository = repository
        self.diagnostics = diagnostics
        self._snapshot: ContactSnapshot | None = None

    def list(self, *, refresh: bool = True) -> ContactSnapshot:
        """Return the current contact snapshot.

        Args:
            refresh: Fetch from Eitaa when true. When false, reuse the latest
                in-memory snapshot if available.
        """
        if refresh or self._snapshot is None:
            try:
                self._snapshot = self.repository.list_contacts(hash_value=0)
            except EitaaCoreError as exc:
                self._attach_error(exc, "contact_service_list_failed")
                raise
        self._emit(
            "contact_service_list_completed",
            fields=self._snapshot.safe_summary(),
        )
        return self._snapshot

    def find(self, phone: PhoneNumber | str, *, refresh: bool = True) -> Contact | None:
        """Find a current contact without importing a new one."""
        normalized = phone if isinstance(phone, PhoneNumber) else PhoneNumber.parse(phone)
        contact = self.list(refresh=refresh).find_by_phone(normalized)
        self._emit(
            "contact_service_find_completed",
            fields={"phone": str(normalized), "found": contact is not None},
        )
        return contact

    def get_status(
        self,
        phone: PhoneNumber | str,
        *,
        refresh: bool = True,
    ) -> UserStatus | None:
        """Return the embedded Eitaa status for an existing contact.

        A ``None`` result means no status object was exposed. The explicit
        ``UNKNOWN_OR_HIDDEN`` kind may also be returned by Eitaa and must not be
        treated as definitely offline.
        """
        normalized = phone if isinstance(phone, PhoneNumber) else PhoneNumber.parse(phone)
        contact = self.find(normalized, refresh=refresh)
        if contact is None:
            error = ContactNotFoundError(
                "Phone number is not present in the current Eitaa contacts.",
                safe_context={"phone": normalized.masked},
            )
            self._attach_error(error, "contact_status_not_found")
            raise error
        self._emit(
            "contact_status_completed",
            fields={
                "phone": str(normalized),
                "status": contact.user.status.safe_summary() if contact.user.status else None,
            },
        )
        return contact.user.status

    def add(
        self,
        phone: PhoneNumber | str,
        *,
        first_name: str,
        last_name: str = "",
    ) -> ContactResolution:
        """Add one contact, returning an existing contact without duplication."""
        return self.resolve(
            phone,
            first_name=first_name,
            last_name=last_name,
            import_if_missing=True,
        )

    def resolve(
        self,
        phone: PhoneNumber | str,
        *,
        first_name: str = "Eitaa",
        last_name: str = "",
        import_if_missing: bool = True,
        refresh_contacts: bool = True,
    ) -> ContactResolution:
        """Resolve a phone number to a sendable user peer.

        Existing contacts are preferred. If the number is missing and
        ``import_if_missing`` is true, one ``contacts.importContacts`` request is
        issued. The returned peer always has an ``access_hash`` suitable for
        later message operations.
        """
        normalized = phone if isinstance(phone, PhoneNumber) else PhoneNumber.parse(phone)
        existing = self.find(normalized, refresh=refresh_contacts)
        if existing is not None and existing.user.peer.access_hash is not None:
            result = ContactResolution(
                contact=existing,
                source=ContactResolutionSource.EXISTING,
                contact_added=False,
            )
            self._emit(
                "contact_resolve_existing",
                fields={"phone": str(normalized), **result.safe_summary()},
            )
            return result

        if not import_if_missing:
            error = ContactNotFoundError(
                "Phone number was not found and importing is disabled.",
                safe_context={"phone": normalized.masked},
            )
            self._attach_error(error, "contact_resolve_import_disabled")
            raise error
        if not first_name.strip():
            error = ContactResolveError(
                "first_name is required when importing a new contact.",
                safe_context={"phone": normalized.masked},
            )
            self._attach_error(error, "contact_resolve_missing_name")
            raise error

        try:
            imported = self.repository.import_contact(
                normalized,
                first_name=first_name.strip(),
                last_name=last_name.strip(),
            )
        except EitaaCoreError as exc:
            self._attach_error(exc, "contact_resolve_import_failed")
            raise

        if imported.retry_client_ids:
            error = ContactImportRetryError(
                "Eitaa requested a later retry for this contact import.",
                safe_context={
                    "phone": normalized.masked,
                    "retry_count": len(imported.retry_client_ids),
                },
            )
            self._attach_error(error, "contact_resolve_retry_requested")
            raise error

        imported_ids = set(imported.imported_user_ids)
        user = next(
            (
                item
                for item in imported.users
                if item.peer.id in imported_ids and item.peer.access_hash is not None
            ),
            None,
        )
        if user is None:
            user = next(
                (
                    item
                    for item in imported.users
                    if item.phone
                    and item.phone.matches(normalized)
                    and item.peer.access_hash is not None
                ),
                None,
            )
        if user is None:
            error = ContactResolveError(
                "Eitaa did not return a sendable user for this phone number.",
                safe_context={
                    "phone": normalized.masked,
                    "returned_user_count": len(imported.users),
                    "imported_count": len(imported.imported_user_ids),
                },
            )
            self._attach_error(error, "contact_resolve_no_sendable_user")
            raise error

        contact = Contact(
            user=self._as_contact_user(user),
            mutual=user.is_mutual_contact,
            client_id=imported.client_id,
        )
        result = ContactResolution(
            contact=contact,
            source=ContactResolutionSource.IMPORTED,
            contact_added=True,
        )
        if self._snapshot is not None:
            self._snapshot = ContactSnapshot(
                contacts=self._snapshot.contacts + (contact,),
                not_modified=False,
            )
        self._emit(
            "contact_resolve_imported",
            fields={"phone": str(normalized), **result.safe_summary()},
        )
        return result

    def remove(self, phone: PhoneNumber | str) -> ContactDeleteResult:
        """Remove one contact without blocking the user or deleting the chat."""
        normalized = phone if isinstance(phone, PhoneNumber) else PhoneNumber.parse(phone)
        known = self.find(normalized, refresh=True)
        if known is None:
            error = ContactNotFoundError(
                "Phone number is not present in the current Eitaa contacts.",
                safe_context={"phone": normalized.masked},
            )
            self._attach_error(error, "contact_remove_not_found")
            raise error
        try:
            result = self.repository.delete_contact(
                normalized,
                known_contact=known,
            )
        except EitaaCoreError as exc:
            self._attach_error(exc, "contact_remove_failed")
            raise
        self._snapshot = None
        self._emit(
            "contact_remove_completed",
            fields={"phone": str(normalized), **result.safe_summary()},
        )
        return result

    def remove_known(
        self,
        phone: PhoneNumber | str,
        user: User,
    ) -> ContactDeleteResult:
        """Remove a contact using a previously resolved user without refetching the address book."""
        normalized = phone if isinstance(phone, PhoneNumber) else PhoneNumber.parse(phone)
        known = Contact(user=self._as_contact_user(user))
        try:
            result = self.repository.delete_contact(normalized, known_contact=known)
        except EitaaCoreError as exc:
            self._attach_error(exc, "contact_remove_known_failed")
            raise
        self._snapshot = None
        self._emit(
            "contact_remove_known_completed",
            fields={"phone": str(normalized), **result.safe_summary()},
        )
        return result

    @staticmethod
    def _as_contact_user(user: User) -> User:
        """Mark an imported user as a contact without mutating the entity."""
        peer = Peer(
            id=user.peer.id,
            type=PeerType.USER,
            access_hash=user.peer.access_hash,
            username=user.peer.username,
            title=user.peer.title,
        )
        return User(
            peer=peer,
            first_name=user.first_name,
            last_name=user.last_name,
            username=user.username,
            phone=user.phone,
            status=user.status,
            is_contact=True,
            is_mutual_contact=user.is_mutual_contact,
            is_deleted=user.is_deleted,
            is_bot=user.is_bot,
            is_verified=user.is_verified,
        )

    def _attach_error(self, error: EitaaCoreError, event: str) -> None:
        debug_file = self._emit(
            event,
            level="error",
            fields={
                "error_type": type(error).__name__,
                "safe_context": error.safe_context,
            },
        )
        if not error.debug_file:
            error.debug_file = debug_file

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("contacts", event, level=level, fields=fields)

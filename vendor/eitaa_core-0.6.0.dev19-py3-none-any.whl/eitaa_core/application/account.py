"""Authenticated account lifecycle operations."""

from __future__ import annotations

from ..domain.auth import LogoutResult
from ..domain.enums import EndpointRole
from ..infrastructure.auth import constructors as auth_c
from ..infrastructure.codec.tl import TLWriter
from ..infrastructure.contacts import ContactsCodec
from ..infrastructure.diagnostics import DiagnosticManager
from ..ports.session_repository import SessionRepository
from .gateway import RpcGateway


class AccountService:
    """Manage remote logout and local session archival."""

    def __init__(
        self,
        gateway: RpcGateway,
        session_repository: SessionRepository,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.gateway = gateway
        self.session_repository = session_repository
        self.diagnostics = diagnostics

    def logout(self, *, archive_local_session: bool = True) -> LogoutResult:
        """Invalidate the remote token and optionally archive the local file.

        The current :class:`EitaaCore` runtime must be closed after this call;
        its in-memory session object is no longer usable.
        """
        method = TLWriter().write_i32(auth_c.AUTH_LOG_OUT).to_bytes()
        response = self.gateway.invoke(
            method,
            operation="auth.logOut",
            endpoint_role=EndpointRole.AUTH,
        )
        remote_ok = ContactsCodec.parse_bool(response.body)
        archived_path = None
        if remote_ok and archive_local_session:
            archived_path = self.session_repository.archive("logged_out")
        result = LogoutResult(
            remote_ok=remote_ok,
            local_session_archived=archived_path is not None,
            archived_path=archived_path,
        )
        if self.diagnostics:
            self.diagnostics.emit("auth", "logout_completed", fields=result.safe_summary())
        return result

"""Staged native authentication service."""

from __future__ import annotations

import re
from dataclasses import dataclass

from ..domain.auth import LoginCodeChallenge, LoginStepResult, PasswordChallenge
from ..domain.phone import PhoneNumber
from ..domain.session import Session
from ..errors import AuthenticationError, AuthenticationStateError, RpcError
from ..infrastructure.auth import AuthCodec, LegacyPasswordInfo, SrpPasswordInfo
from ..infrastructure.diagnostics import DiagnosticManager
from ..ports.auth_repository import AuthRepository
from ..ports.session_repository import SessionRepository


class AuthenticationService:
    """Coordinate ``sendCode -> signIn -> optional 2FA -> session save``.

    The service never reads from stdin and never prints. Frontends own all user
    interaction and submit secrets through the explicit methods below. Secrets
    are not placed in diagnostics.
    """

    def __init__(
        self,
        repository: AuthRepository,
        session_repository: SessionRepository,
        *,
        imei: str,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.repository = repository
        self.session_repository = session_repository
        self.imei = imei
        self.diagnostics = diagnostics
        self._password_info: SrpPasswordInfo | LegacyPasswordInfo | None = None

    def request_code(self, phone: PhoneNumber | str) -> LoginCodeChallenge:
        """Request exactly one login code and return a staged challenge."""
        normalized = phone if isinstance(phone, PhoneNumber) else PhoneNumber.parse(phone)
        self._emit("login_code_requested", fields=normalized.safe_summary())
        challenge = self.repository.request_code(normalized)
        self._emit("login_code_challenge_created", fields=challenge.safe_summary())
        return challenge

    def submit_code(self, challenge: LoginCodeChallenge, code: str) -> LoginStepResult:
        """Submit a login code and either save a session or request 2FA."""
        normalized_code = code.strip() if isinstance(code, str) else ""
        if not re.fullmatch(r"[0-9A-Za-z-]{2,32}", normalized_code):
            raise AuthenticationError("Login code format is invalid.")
        self._emit(
            "login_code_submission_started",
            fields={"challenge": challenge.safe_summary(), "code_present": True},
        )
        try:
            data = self.repository.sign_in(challenge, normalized_code)
        except RpcError as exc:
            if "SESSION_PASSWORD_NEEDED" not in exc.text.upper():
                raise
            password_data = self.repository.get_password()
            info = AuthCodec.parse_password_info(password_data)
            self._password_info = info
            challenge_public = PasswordChallenge(
                algorithm="srp" if isinstance(info, SrpPasswordInfo) else "legacy_hash",
                hint=info.hint,
            )
            self._emit(
                "second_factor_required",
                fields=challenge_public.safe_summary(),
            )
            return LoginStepResult(password_challenge=challenge_public)
        token = AuthCodec.parse_authorization_token(data)
        session = self._save_session(token, source="auth.signIn")
        return LoginStepResult(session=session)

    def submit_password(self, password: str) -> LoginStepResult:
        """Complete a pending second-factor challenge and save the session."""
        if self._password_info is None:
            raise AuthenticationStateError(
                "No second-factor challenge is pending. Submit a login code first."
            )
        if not isinstance(password, str) or not password:
            raise AuthenticationError("Second-factor password cannot be empty.")
        info = self._password_info
        self._emit(
            "second_factor_submission_started",
            fields={"algorithm": "srp" if isinstance(info, SrpPasswordInfo) else "legacy_hash"},
        )
        if isinstance(info, SrpPasswordInfo):
            srp_id, a_value, m1 = AuthCodec.compute_srp_check(info, password)
            data = self.repository.check_password_srp(srp_id, a_value, m1)
        else:
            password_hash = AuthCodec.compute_legacy_hash(info, password)
            data = self.repository.check_password_legacy(password_hash)
        token = AuthCodec.parse_authorization_token(data)
        self._password_info = None
        session = self._save_session(token, source="auth.checkPassword")
        return LoginStepResult(session=session)

    def _save_session(self, token: str, *, source: str) -> Session:
        session = Session.now(
            token=token,
            imei=self.imei,
            metadata={
                "source": "eitaa-core7-native-login",
                "authorization_method": source,
            },
        )
        self.session_repository.save(session)
        self._emit("native_login_completed", fields=session.safe_summary())
        return session

    def _emit(self, event: str, *, level: str = "info", fields=None) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("auth", event, level=level, fields=fields)

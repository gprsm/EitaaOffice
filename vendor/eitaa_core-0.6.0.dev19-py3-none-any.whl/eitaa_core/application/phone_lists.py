"""Phone-list ingestion, resolution, export, and bulk-job integration."""

from __future__ import annotations

import csv
import json
import time
from pathlib import Path
from typing import Iterable

from ..domain.community import BulkJob, BulkMessageSpec, BulkPreview, BulkSendOptions
from ..domain.enums import ContactResolutionSource, PhoneCleanupStatus, PhoneEntryStatus, PhoneListStatus
from ..domain.phone import PhoneNumber
from ..domain.phone_list import (
    PhoneCleanupOptions,
    PhoneCleanupReport,
    PhoneListEntry,
    PhoneListExportResult,
    PhoneListInputRow,
    PhoneListInspection,
    PhoneListResolveOptions,
    PhoneRecipientList,
)
from ..errors import (
    ContactImportRetryError,
    ContactNotFoundError,
    ContactResolveError,
    EitaaCoreError,
    HttpStatusError,
    NetworkError,
    PhoneListError,
    PhoneNumberError,
    RpcError,
)
from ..infrastructure.diagnostics import DiagnosticManager
from ..infrastructure.persistence.sqlite_community import SQLiteCommunityRepository
from .community import BulkSendService, CommunityService
from .contacts import ContactService


_PHONE_HEADERS = {
    "phone", "mobile", "number", "telephone", "tel", "phonenumber",
    "شماره", "شمارهتلفن", "تلفن", "موبایل", "همراه",
}
_FIRST_HEADERS = {"first", "firstname", "first_name", "name", "نام"}
_LAST_HEADERS = {"last", "lastname", "last_name", "family", "surname", "نامخانوادگی", "فامیلی"}


def _header_key(value: str) -> str:
    return "".join(ch for ch in value.strip().lower() if ch not in " _-\u200c")


def _decode_text(path: Path) -> str:
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp1256"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise PhoneListError(
        "Phone-list file encoding is not supported; save it as UTF-8 CSV or TXT.",
        safe_context={"source_name": path.name},
    )


def _rows_from_text(text: str) -> list[list[str]]:
    sample = text[:8192]
    delimiter = ","
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        if "\t" in sample:
            delimiter = "\t"
        elif ";" in sample:
            delimiter = ";"
    return [list(row) for row in csv.reader(text.splitlines(), delimiter=delimiter)]


class PhoneListService:
    """Persist private phone lists and resolve them to sendable Eitaa users."""

    def __init__(
        self,
        contacts: ContactService,
        members: CommunityService,
        bulk_send: BulkSendService,
        store: SQLiteCommunityRepository,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.contacts = contacts
        self.members = members
        self.bulk_send = bulk_send
        self.store = store
        self.diagnostics = diagnostics

    def inspect_file(self, path: Path | str, *, max_rows: int = 10_000) -> PhoneListInspection:
        source = Path(path).expanduser().resolve()
        if not source.is_file():
            raise PhoneListError(
                "Phone-list file does not exist.",
                safe_context={"source_name": source.name, "file_present": False},
            )
        parsed = self._parse(source, max_rows=max_rows)
        self._emit("phone_list_inspected", fields=parsed.safe_summary())
        return parsed

    def import_file(
        self,
        path: Path | str,
        *,
        name: str | None = None,
        max_rows: int = 10_000,
    ) -> PhoneRecipientList:
        inspection = self.inspect_file(path, max_rows=max_rows)
        if inspection.valid_unique == 0:
            raise PhoneListError(
                "The phone-list file contains no valid unique phone numbers.",
                safe_context=inspection.safe_summary(),
            )
        result = self.store.create_phone_list(
            name=(name or inspection.source_file.stem).strip(),
            source_name=inspection.source_file.name,
            rows=inspection.rows,
            valid_unique=inspection.valid_unique,
            duplicate_count=inspection.duplicates,
            invalid_count=inspection.invalid,
        )
        self._emit("phone_list_imported", fields=result.safe_summary())
        return result

    def resolve(
        self,
        list_id: str,
        options: PhoneListResolveOptions | None = None,
    ) -> PhoneRecipientList:
        options = options or PhoneListResolveOptions()
        options.validate()
        phone_list = self._require_list(list_id)
        if phone_list.status is PhoneListStatus.CANCELLED:
            raise PhoneListError("A cancelled phone list cannot be resolved.", safe_context={"list_id": list_id})

        recovered = self.store.recover_phone_processing(list_id)
        self.store.set_phone_list_status(list_id, PhoneListStatus.RESOLVING, stop_reason=None)
        self._emit(
            "phone_list_resolution_started",
            fields={"list": phone_list.safe_summary(), "options": options.safe_summary(), "recovered": recovered},
        )

        # Fetch the contact book once. Missing numbers are then imported without
        # refreshing the entire address book for every row.
        try:
            self.contacts.list(refresh=True)
        except EitaaCoreError as exc:
            stop, code = self._classify_stop(exc, options.stop_on_server_error)
            if stop:
                result = self.store.set_phone_list_status(list_id, PhoneListStatus.BLOCKED, stop_reason=code)
                self._emit("phone_list_resolution_blocked", level="error", fields=result.safe_summary())
                return result
            raise

        while True:
            entry = self.store.claim_phone_entry(list_id, max_attempts=options.max_attempts)
            if entry is None:
                break
            assert entry.phone is not None
            network_attempted = False
            try:
                existing = self.contacts.find(entry.phone, refresh=False)
                if existing is not None and existing.user.peer.access_hash is not None:
                    user = existing.user
                    contact_source = ContactResolutionSource.EXISTING
                    contact_added_by_list = False
                else:
                    network_attempted = True
                    resolution = self.contacts.resolve(
                        entry.phone,
                        first_name=entry.first_name or "Eitaa",
                        last_name=entry.last_name,
                        import_if_missing=options.import_if_missing,
                        refresh_contacts=False,
                    )
                    user = resolution.contact.user
                    contact_source = resolution.source
                    contact_added_by_list = resolution.contact_added
                if self.store.resolved_user_exists(list_id, user.peer.id, exclude_entry_id=entry.id):
                    self.store.mark_phone_entry_terminal(
                        entry,
                        status=PhoneEntryStatus.DUPLICATE,
                        error_code="DUPLICATE_USER",
                        error_type="same_eitaa_user_already_resolved",
                    )
                else:
                    self.store.mark_phone_entry_resolved(
                        entry, user, source=contact_source,
                        contact_added_by_list=contact_added_by_list,
                    )
                    self._emit(
                        "phone_entry_resolved",
                        fields={
                            "list_id": list_id,
                            "row_number": entry.row_number,
                            "phone": entry.phone.masked,
                            "user": user.safe_summary(),
                            "attempt": entry.attempts,
                            "contact_source": contact_source.value,
                            "contact_added_by_list": contact_added_by_list,
                        },
                    )
            except (ContactNotFoundError, ContactResolveError) as exc:
                # ImportRetry is handled below because it is explicitly retryable.
                if isinstance(exc, ContactImportRetryError):
                    retry = entry.attempts < options.max_attempts
                    self.store.mark_phone_entry_terminal(
                        entry,
                        status=PhoneEntryStatus.PENDING if retry else PhoneEntryStatus.FAILED,
                        error_code="IMPORT_RETRY",
                        error_type=type(exc).__name__,
                    )
                    if retry and options.retry_delay_seconds:
                        time.sleep(options.retry_delay_seconds)
                else:
                    self.store.mark_phone_entry_terminal(
                        entry,
                        status=PhoneEntryStatus.NOT_FOUND,
                        error_code="NO_SENDABLE_EITAA_USER",
                        error_type=type(exc).__name__,
                    )
            except EitaaCoreError as exc:
                stop, code = self._classify_stop(exc, options.stop_on_server_error)
                retry = not stop and entry.attempts < options.max_attempts
                self.store.mark_phone_entry_terminal(
                    entry,
                    status=PhoneEntryStatus.PENDING if retry or stop else PhoneEntryStatus.FAILED,
                    error_code=code,
                    error_type=type(exc).__name__,
                )
                self._emit(
                    "phone_entry_resolution_failed",
                    level="warning" if retry else "error",
                    fields={
                        "list_id": list_id,
                        "row_number": entry.row_number,
                        "phone": entry.phone.masked,
                        "attempt": entry.attempts,
                        "retry": retry,
                        "stop": stop,
                        "error_code": code,
                        "error_type": type(exc).__name__,
                    },
                )
                if stop:
                    result = self.store.set_phone_list_status(list_id, PhoneListStatus.BLOCKED, stop_reason=code)
                    self._sync_resolved(result, complete_snapshot=False)
                    return result
                if retry and options.retry_delay_seconds:
                    time.sleep(options.retry_delay_seconds)
            except Exception as exc:
                self.store.mark_phone_entry_terminal(
                    entry,
                    status=PhoneEntryStatus.FAILED,
                    error_code="INTERNAL_ERROR",
                    error_type=type(exc).__name__,
                )
                result = self.store.set_phone_list_status(
                    list_id, PhoneListStatus.FAILED, stop_reason=type(exc).__name__
                )
                self._sync_resolved(result, complete_snapshot=False)
                self._emit("phone_list_resolution_internal_failure", level="error", fields=result.safe_summary())
                return result
            if network_attempted and options.delay_seconds:
                time.sleep(options.delay_seconds)

        result = self.store.refresh_phone_list_counts(list_id)
        if result.pending_count:
            status = PhoneListStatus.PARTIAL
        elif result.resolved_count == 0:
            status = PhoneListStatus.FAILED
        elif result.not_found_count or result.failed_count:
            status = PhoneListStatus.PARTIAL
        else:
            status = PhoneListStatus.READY
        result = self.store.set_phone_list_status(list_id, status, stop_reason=None)
        self._sync_resolved(result, complete_snapshot=True)
        self._emit("phone_list_resolution_finished", fields=result.safe_summary())
        return result

    def cleanup(
        self,
        list_id: str,
        options: PhoneCleanupOptions | None = None,
        *,
        confirm: bool = False,
    ) -> PhoneCleanupReport:
        """Remove only contacts imported by this list, unless legacy override is explicit."""
        if not confirm:
            raise PhoneListError(
                "Phone-list cleanup requires explicit confirmation.",
                safe_context={"list_id": list_id},
            )
        options = options or PhoneCleanupOptions()
        options.validate()
        self._require_list(list_id)
        recovered = self.store.recover_phone_cleanup_processing(list_id)
        prepared = self.store.prepare_phone_cleanup(
            list_id, include_legacy_unknown=options.include_legacy_unknown
        )
        self._emit(
            "phone_cleanup_started",
            fields={
                "list_id": list_id,
                "options": options.safe_summary(),
                "recovered": recovered,
                "prepared": prepared,
            },
        )
        stop_reason: str | None = None
        while True:
            entry = self.store.claim_phone_cleanup_entry(
                list_id, max_attempts=options.max_attempts
            )
            if entry is None:
                break
            assert entry.phone is not None
            try:
                if entry.user is not None:
                    result = self.contacts.remove_known(entry.phone, entry.user)
                else:
                    result = self.contacts.remove(entry.phone)
            except ContactNotFoundError:
                self.store.mark_phone_cleanup_removed(
                    entry, response_type="already_absent"
                )
                self._emit(
                    "phone_cleanup_already_absent",
                    fields={
                        "list_id": list_id,
                        "row_number": entry.row_number,
                        "phone": entry.phone.masked,
                    },
                )
            except EitaaCoreError as exc:
                stop, code = self._classify_stop(exc, options.stop_on_server_error)
                retry = not stop and entry.cleanup_attempts < options.max_attempts
                self.store.mark_phone_cleanup_error(
                    entry,
                    retry=retry,
                    error_code=code,
                    error_type=type(exc).__name__,
                )
                self._emit(
                    "phone_cleanup_failed",
                    level="warning" if retry else "error",
                    fields={
                        "list_id": list_id,
                        "row_number": entry.row_number,
                        "phone": entry.phone.masked,
                        "attempt": entry.cleanup_attempts,
                        "retry": retry,
                        "stop": stop,
                        "error_code": code,
                        "error_type": type(exc).__name__,
                    },
                )
                if stop:
                    stop_reason = code
                    break
                if retry and options.retry_delay_seconds:
                    time.sleep(options.retry_delay_seconds)
                continue
            except Exception as exc:
                self.store.mark_phone_cleanup_error(
                    entry, retry=False, error_code="INTERNAL_ERROR",
                    error_type=type(exc).__name__,
                )
                stop_reason = type(exc).__name__
                break
            else:
                self.store.mark_phone_cleanup_removed(
                    entry, response_type=result.method
                )
                self._emit(
                    "phone_cleanup_removed",
                    fields={
                        "list_id": list_id,
                        "row_number": entry.row_number,
                        "phone": entry.phone.masked,
                        "method": result.method,
                    },
                )
                if options.delay_seconds:
                    time.sleep(options.delay_seconds)
        report = self.store.phone_cleanup_report(list_id, stop_reason=stop_reason)
        self._emit("phone_cleanup_finished", fields=report.safe_summary())
        return report

    def cleanup_status(self, list_id: str) -> PhoneCleanupReport:
        self._require_list(list_id)
        return self.store.phone_cleanup_report(list_id)

    def status(self, list_id: str) -> PhoneRecipientList:
        return self.store.refresh_phone_list_counts(list_id)

    def lists(self, *, limit: int = 100) -> tuple[PhoneRecipientList, ...]:
        return self.store.list_phone_lists(limit=limit)

    def entries(
        self,
        list_id: str,
        *,
        status: PhoneEntryStatus | None = None,
        offset: int = 0,
        limit: int = 1000,
    ) -> tuple[PhoneListEntry, ...]:
        self._require_list(list_id)
        return self.store.list_phone_entries(list_id, status=status, offset=offset, limit=limit)

    def preview(
        self,
        list_id: str,
        *,
        test_limit: int | None = None,
        sample_limit: int = 10,
    ) -> BulkPreview:
        phone_list = self._require_list(list_id)
        return self.bulk_send.preview(
            phone_list.virtual_community,
            include_bots=False,
            test_limit=test_limit,
            sample_limit=sample_limit,
        )

    def create_job(
        self,
        list_id: str,
        spec: BulkMessageSpec,
        options: BulkSendOptions,
    ) -> BulkJob:
        phone_list = self._require_list(list_id)
        if phone_list.resolved_count == 0:
            raise PhoneListError(
                "Phone list has no resolved sendable recipients.",
                safe_context={"list_id": list_id, "status": phone_list.status.value},
            )
        return self.bulk_send.create_job(
            phone_list.virtual_community,
            spec,
            options,
            include_bots=False,
        )

    def export(
        self,
        list_id: str,
        output: Path | str,
        *,
        format: str = "csv",
    ) -> PhoneListExportResult:
        phone_list = self._require_list(list_id)
        target = Path(output).expanduser().resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        rows: list[PhoneListEntry] = []
        offset = 0
        while True:
            page = self.store.list_phone_entries(list_id, offset=offset, limit=10_000)
            rows.extend(page)
            if len(page) < 10_000:
                break
            offset += len(page)
        if format == "csv":
            with target.open("w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=[
                        "row_number", "phone", "first_name", "last_name", "status",
                        "user_id", "username", "attempts", "error_code", "error_type",
                        "contact_source", "contact_added_by_list", "cleanup_status",
                        "cleanup_attempts", "cleanup_error_code", "cleanup_error_type",
                        "cleanup_response_type",
                    ],
                )
                writer.writeheader()
                for entry in rows:
                    writer.writerow(self._export_row(entry))
        elif format == "json":
            target.write_text(
                json.dumps([self._export_row(entry) for entry in rows], ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        else:
            raise PhoneListError("Phone-list export format must be csv or json.")
        result = PhoneListExportResult(target, format, len(rows))
        self._emit(
            "phone_list_exported",
            fields={"list": phone_list.safe_summary(), **result.safe_summary()},
        )
        return result

    def cancel(self, list_id: str) -> PhoneRecipientList:
        self._require_list(list_id)
        return self.store.set_phone_list_status(list_id, PhoneListStatus.CANCELLED)

    def _parse(self, source: Path, *, max_rows: int) -> PhoneListInspection:
        if max_rows < 1:
            raise PhoneListError("max_rows must be positive.")
        table = _rows_from_text(_decode_text(source))
        nonempty = [row for row in table if any(cell.strip() for cell in row)]
        if not nonempty:
            return PhoneListInspection(source, 0, 0, 0, 0, ())

        header = [_header_key(cell) for cell in nonempty[0]]
        has_header = any(key in _PHONE_HEADERS for key in header)
        phone_index = next((i for i, key in enumerate(header) if key in _PHONE_HEADERS), 0)
        first_index = next((i for i, key in enumerate(header) if key in _FIRST_HEADERS), None)
        last_index = next((i for i, key in enumerate(header) if key in _LAST_HEADERS), None)
        data = nonempty[1:] if has_header else nonempty
        if not has_header:
            max_columns = max((len(row) for row in data), default=1)
            first_index = 1 if max_columns > 1 else None
            last_index = 2 if max_columns > 2 else None
        if len(data) > max_rows:
            raise PhoneListError(
                "Phone-list row count exceeds the configured safety limit.",
                safe_context={"row_count": len(data), "max_rows": max_rows, "source_name": source.name},
            )

        rows: list[PhoneListInputRow] = []
        seen: set[str] = set()
        valid_unique = duplicates = invalid = 0
        start_number = 2 if has_header else 1
        for position, cells in enumerate(data, start=start_number):
            raw_phone = cells[phone_index].strip() if phone_index < len(cells) else ""
            first = cells[first_index].strip() if first_index is not None and first_index < len(cells) else "Eitaa"
            last = cells[last_index].strip() if last_index is not None and last_index < len(cells) else ""
            try:
                phone = PhoneNumber.parse(raw_phone)
            except PhoneNumberError:
                rows.append(
                    PhoneListInputRow(
                        position, None, first or "Eitaa", last,
                        PhoneEntryStatus.INVALID, "INVALID_PHONE",
                    )
                )
                invalid += 1
                continue
            key = phone.canonical_digits
            if key in seen:
                rows.append(
                    PhoneListInputRow(
                        position, phone, first or "Eitaa", last,
                        PhoneEntryStatus.DUPLICATE, "DUPLICATE_PHONE",
                    )
                )
                duplicates += 1
                continue
            seen.add(key)
            rows.append(PhoneListInputRow(position, phone, first or "Eitaa", last))
            valid_unique += 1
        return PhoneListInspection(source, len(rows), valid_unique, duplicates, invalid, tuple(rows))

    def _sync_resolved(self, phone_list: PhoneRecipientList, *, complete_snapshot: bool) -> None:
        members = self.store.resolved_phone_members(phone_list)
        self.store.sync_members(
            phone_list.virtual_community,
            members,
            complete_snapshot=complete_snapshot,
        )

    def _require_list(self, list_id: str) -> PhoneRecipientList:
        result = self.store.get_phone_list(list_id)
        if result is None:
            raise PhoneListError("Phone recipient list was not found.", safe_context={"list_id": list_id})
        return result

    @staticmethod
    def _classify_stop(error: EitaaCoreError, stop_on_server_error: bool) -> tuple[bool, str]:
        if isinstance(error, RpcError):
            text = error.text.upper()
            rate = error.code in {420, 429} or any(
                marker in text for marker in ("FLOOD", "RATE", "TOO_MANY", "PEER_FLOOD", "LIMIT")
            )
            server = error.code >= 500 or "INTERNAL_SERVER_ERROR" in text or "SERVER" in text
            return rate or (server and stop_on_server_error), f"RPC_{error.code}_{text[:64]}"
        if isinstance(error, HttpStatusError):
            status = int(error.safe_context.get("http_status", 0) or 0)
            stop = status == 429 or (status >= 500 and stop_on_server_error)
            return stop, f"HTTP_{status}" if status else "HTTP_ERROR"
        if isinstance(error, NetworkError):
            return False, "NETWORK_ERROR"
        return False, type(error).__name__

    @staticmethod
    def _export_row(entry: PhoneListEntry) -> dict[str, object]:
        return {
            "row_number": entry.row_number,
            "phone": str(entry.phone) if entry.phone else None,
            "first_name": entry.first_name,
            "last_name": entry.last_name,
            "status": entry.status.value,
            "user_id": entry.user.peer.id if entry.user else None,
            "username": entry.user.username if entry.user else None,
            "attempts": entry.attempts,
            "error_code": entry.error_code,
            "error_type": entry.error_type,
            "contact_source": entry.contact_source.value if entry.contact_source else None,
            "contact_added_by_list": entry.contact_added_by_list,
            "cleanup_status": entry.cleanup_status.value,
            "cleanup_attempts": entry.cleanup_attempts,
            "cleanup_error_code": entry.cleanup_error_code,
            "cleanup_error_type": entry.cleanup_error_type,
            "cleanup_response_type": entry.cleanup_response_type,
        }

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> None:
        if self.diagnostics:
            self.diagnostics.emit("phone_lists", event, level=level, fields=fields)

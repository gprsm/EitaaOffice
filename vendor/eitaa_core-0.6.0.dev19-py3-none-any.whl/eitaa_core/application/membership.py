"""Reversible bulk membership invitation service for Core 7.4."""

from __future__ import annotations

import time

from ..domain.enums import (
    MembershipAddStatus,
    MembershipJobStatus,
    MemberRole,
    MemberState,
    PeerType,
)
from ..domain.community import CommunityMember
from ..domain.membership import (
    MembershipInviteOptions,
    MembershipJob,
    MembershipPreview,
    MembershipRecipient,
    MembershipRollbackOptions,
    MembershipRollbackReport,
    MembershipRunReport,
)
from ..domain.peer import Peer
from ..errors import (
    EitaaCoreError,
    HttpStatusError,
    MembershipConfirmationError,
    MembershipError,
    NetworkError,
    RpcError,
)
from ..infrastructure.diagnostics import DiagnosticManager
from ..infrastructure.persistence.sqlite_membership import SQLiteMembershipRepository
from ..ports.membership_repository import MembershipRepository
from .community import CommunityService


_ALREADY_MEMBER_MARKERS = (
    "USER_ALREADY_PARTICIPANT",
    "ALREADY_PARTICIPANT",
    "USER_ALREADY_INVITED",
)
_NOT_MEMBER_MARKERS = (
    "USER_NOT_PARTICIPANT",
    "PARTICIPANT_ID_INVALID",
)


class MembershipService:
    """Create, run, pause, resume, cancel, and safely roll back invite jobs."""

    def __init__(
        self,
        remote: MembershipRepository,
        store: SQLiteMembershipRepository,
        members: CommunityService,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.remote = remote
        self.store = store
        self.members = members
        self.diagnostics = diagnostics

    def preview(
        self,
        list_id: str,
        target: Peer,
        *,
        test_limit: int | None = None,
        sample_limit: int = 10,
    ) -> MembershipPreview:
        self._validate_target(target)
        return self.store.preview(
            list_id,
            target,
            test_limit=test_limit,
            sample_limit=sample_limit,
        )

    def create_job(
        self,
        list_id: str,
        target: Peer,
        options: MembershipInviteOptions | None = None,
    ) -> MembershipJob:
        self._validate_target(target)
        options = options or MembershipInviteOptions()
        options.validate()
        return self.store.create_job(list_id, target, options)

    def run(self, job_id: str, *, confirm: bool = False) -> MembershipRunReport:
        job = self._require_job(job_id)
        if job.status is MembershipJobStatus.DRAFT and not confirm:
            raise MembershipConfirmationError(
                "Membership job is still a draft; explicit confirmation is required.",
                safe_context={
                    "job_id": job_id,
                    "recipient_count": job.recipient_count,
                },
            )
        if job.status in {
            MembershipJobStatus.COMPLETED,
            MembershipJobStatus.CANCELLED,
        }:
            return self.store.report(job_id)
        if job.status is MembershipJobStatus.PAUSED:
            raise MembershipError(
                "Membership job is paused. Resume it before running.",
                safe_context={"job_id": job_id},
            )

        recovered = self.store.recover_processing(job_id)
        self.store.set_job_status(job_id, MembershipJobStatus.RUNNING)
        basic_chat_members: set[int] | None = None
        if job.target.type is PeerType.CHAT:
            page = self.members.fetch_page(
                job.target,
                offset=0,
                limit=10_000,
                store=True,
            )
            basic_chat_members = {member.user.peer.id for member in page.members}
        self._emit(
            "membership_run_started",
            fields={
                "job": job.safe_summary(),
                "recovered_processing": recovered,
                "basic_chat_snapshot_count": (
                    len(basic_chat_members) if basic_chat_members is not None else None
                ),
            },
        )

        while True:
            current = self._require_job(job_id)
            if current.status in {
                MembershipJobStatus.PAUSED,
                MembershipJobStatus.CANCELLED,
                MembershipJobStatus.BLOCKED,
                MembershipJobStatus.FAILED,
            }:
                break
            recipient = self.store.claim_recipient(
                job_id, max_attempts=current.options.max_attempts
            )
            if recipient is None:
                report = self.store.report(job_id)
                if report.complete:
                    self.store.set_job_status(job_id, MembershipJobStatus.COMPLETED)
                break
            try:
                if basic_chat_members is not None:
                    is_member = recipient.user.peer.id in basic_chat_members
                    check_type = "messages.getFullChat.snapshot"
                else:
                    check = self.remote.check_member(
                        current.target, recipient.user.peer
                    )
                    is_member = check.is_member
                    check_type = check.response_type
                if is_member:
                    self.store.mark_already_member(
                        recipient, response_type=check_type
                    )
                    self.members.store.sync_members(
                        current.target,
                        [CommunityMember(
                            community=current.target,
                            user=recipient.user,
                            role=MemberRole.MEMBER,
                            state=MemberState.ACTIVE,
                        )],
                        complete_snapshot=False,
                    )
                    self._emit(
                        "membership_recipient_already_member",
                        fields={
                            "job_id": job_id,
                            "target": current.target.safe_summary(),
                            "user": recipient.user.peer.safe_summary(),
                            "check_response_type": check_type,
                        },
                    )
                    continue

                result = self.remote.add_member(
                    current.target,
                    recipient.user.peer,
                    fwd_limit=current.options.fwd_limit,
                )
            except RpcError as exc:
                text = exc.text.upper()
                if any(marker in text for marker in _ALREADY_MEMBER_MARKERS):
                    self.store.mark_already_member(
                        recipient,
                        response_type=f"rpc.{text[:64].lower()}",
                    )
                    self.members.store.sync_members(
                        current.target,
                        [CommunityMember(
                            community=current.target,
                            user=recipient.user,
                            role=MemberRole.MEMBER,
                            state=MemberState.ACTIVE,
                        )],
                        complete_snapshot=False,
                    )
                    continue
                retryable, stop, code = self._classify_error(
                    exc,
                    stop_on_server_error=current.options.stop_on_server_error,
                )
                retry = (
                    retryable
                    and recipient.add_attempts < current.options.max_attempts
                )
                self.store.mark_add_failed(
                    recipient,
                    retry=retry,
                    error_code=code,
                    error_type=type(exc).__name__,
                )
                self._emit_failure(
                    "membership_recipient_add_failed",
                    current,
                    recipient,
                    exc,
                    retry=retry,
                    stop=stop,
                    code=code,
                )
                if stop:
                    self.store.set_job_status(
                        job_id,
                        MembershipJobStatus.BLOCKED,
                        stop_reason=code,
                    )
                    break
                if retry and current.options.retry_delay_seconds:
                    time.sleep(current.options.retry_delay_seconds)
                continue
            except EitaaCoreError as exc:
                retryable, stop, code = self._classify_error(
                    exc,
                    stop_on_server_error=current.options.stop_on_server_error,
                )
                retry = (
                    retryable
                    and recipient.add_attempts < current.options.max_attempts
                )
                self.store.mark_add_failed(
                    recipient,
                    retry=retry,
                    error_code=code,
                    error_type=type(exc).__name__,
                )
                self._emit_failure(
                    "membership_recipient_add_failed",
                    current,
                    recipient,
                    exc,
                    retry=retry,
                    stop=stop,
                    code=code,
                )
                if stop:
                    self.store.set_job_status(
                        job_id,
                        MembershipJobStatus.BLOCKED,
                        stop_reason=code,
                    )
                    break
                if retry and current.options.retry_delay_seconds:
                    time.sleep(current.options.retry_delay_seconds)
                continue
            except Exception as exc:
                self.store.mark_add_failed(
                    recipient,
                    retry=False,
                    error_code="INTERNAL_ERROR",
                    error_type=type(exc).__name__,
                )
                self.store.set_job_status(
                    job_id,
                    MembershipJobStatus.FAILED,
                    stop_reason=type(exc).__name__,
                )
                self._emit(
                    "membership_run_internal_failure",
                    level="error",
                    fields={"job_id": job_id, "error_type": type(exc).__name__},
                )
                break
            else:
                self.store.mark_added(
                    recipient, response_type=result.response_type
                )
                self.members.store.sync_members(
                    current.target,
                    [CommunityMember(
                        community=current.target,
                        user=recipient.user,
                        role=MemberRole.MEMBER,
                        state=MemberState.ACTIVE,
                    )],
                    complete_snapshot=False,
                )
                if basic_chat_members is not None:
                    basic_chat_members.add(recipient.user.peer.id)
                self._emit(
                    "membership_recipient_added",
                    fields={
                        "job_id": job_id,
                        "target": current.target.safe_summary(),
                        "user": recipient.user.peer.safe_summary(),
                        "attempt": recipient.add_attempts,
                        "response_type": result.response_type,
                    },
                )
                latest = self._require_job(job_id)
                if latest.options.delay_seconds:
                    time.sleep(latest.options.delay_seconds)

        report = self.store.report(job_id)
        self._emit("membership_run_finished", fields=report.safe_summary())
        return report

    def pause(self, job_id: str) -> MembershipJob:
        job = self._require_job(job_id)
        if job.status is not MembershipJobStatus.RUNNING:
            raise MembershipError("Only a running membership job can be paused.")
        return self.store.set_job_status(job_id, MembershipJobStatus.PAUSED)

    def resume(self, job_id: str) -> MembershipJob:
        job = self._require_job(job_id)
        if job.status not in {
            MembershipJobStatus.PAUSED,
            MembershipJobStatus.BLOCKED,
            MembershipJobStatus.FAILED,
        }:
            raise MembershipError("This membership job is not paused or blocked.")
        return self.store.set_job_status(job_id, MembershipJobStatus.DRAFT)

    def cancel(self, job_id: str) -> MembershipJob:
        job = self._require_job(job_id)
        if job.status is MembershipJobStatus.COMPLETED:
            raise MembershipError(
                "A completed membership job cannot be cancelled; use rollback instead."
            )
        return self.store.set_job_status(job_id, MembershipJobStatus.CANCELLED)

    def report(self, job_id: str) -> MembershipRunReport:
        self._require_job(job_id)
        return self.store.report(job_id)

    def jobs(self, *, limit: int = 100) -> tuple[MembershipJob, ...]:
        return self.store.jobs(limit=limit)

    def recipients(
        self,
        job_id: str,
        *,
        status: MembershipAddStatus | None = None,
        limit: int = 1000,
    ) -> tuple[MembershipRecipient, ...]:
        self._require_job(job_id)
        return self.store.recipients(job_id, add_status=status, limit=limit)

    def rollback(
        self,
        job_id: str,
        options: MembershipRollbackOptions | None = None,
        *,
        confirm: bool = False,
    ) -> MembershipRollbackReport:
        if not confirm:
            raise MembershipConfirmationError(
                "Membership rollback requires explicit confirmation.",
                safe_context={"job_id": job_id},
            )
        job = self._require_job(job_id)
        options = options or MembershipRollbackOptions()
        options.validate()
        self.store.start_rollback(job_id)
        recovered = self.store.recover_rollback_processing(job_id)
        self._emit(
            "membership_rollback_started",
            fields={
                "job": job.safe_summary(),
                "options": options.safe_summary(),
                "recovered_processing": recovered,
            },
        )
        stop_reason: str | None = None
        while True:
            recipient = self.store.claim_rollback(
                job_id, max_attempts=options.max_attempts
            )
            if recipient is None:
                break
            try:
                result = self.remote.remove_member(
                    job.target,
                    recipient.user.peer,
                    revoke_history=options.revoke_history,
                    release_channel_ban=options.release_channel_ban,
                )
            except RpcError as exc:
                text = exc.text.upper()
                if any(marker in text for marker in _NOT_MEMBER_MARKERS):
                    self.store.mark_rollback_removed(
                        recipient,
                        response_type=f"rpc.{text[:64].lower()}",
                        ban_released=True,
                    )
                    self.members.store.mark_member_left(
                        job.target, recipient.user.peer.id
                    )
                    continue
                retryable, stop, code = self._classify_error(
                    exc,
                    stop_on_server_error=options.stop_on_server_error,
                )
                retry = (
                    retryable
                    and recipient.rollback_attempts < options.max_attempts
                )
                self.store.mark_rollback_failed(
                    recipient,
                    retry=retry,
                    error_code=code,
                    error_type=type(exc).__name__,
                )
                if stop:
                    stop_reason = code
                    break
                if retry and options.retry_delay_seconds:
                    time.sleep(options.retry_delay_seconds)
                continue
            except EitaaCoreError as exc:
                retryable, stop, code = self._classify_error(
                    exc,
                    stop_on_server_error=options.stop_on_server_error,
                )
                retry = (
                    retryable
                    and recipient.rollback_attempts < options.max_attempts
                )
                self.store.mark_rollback_failed(
                    recipient,
                    retry=retry,
                    error_code=code,
                    error_type=type(exc).__name__,
                )
                if stop:
                    stop_reason = code
                    break
                if retry and options.retry_delay_seconds:
                    time.sleep(options.retry_delay_seconds)
                continue
            except Exception as exc:
                self.store.mark_rollback_failed(
                    recipient,
                    retry=False,
                    error_code="INTERNAL_ERROR",
                    error_type=type(exc).__name__,
                )
                stop_reason = type(exc).__name__
                break
            else:
                self.store.mark_rollback_removed(
                    recipient,
                    response_type=result.response_type,
                    ban_released=result.ban_released,
                )
                self.members.store.mark_member_left(
                    job.target, recipient.user.peer.id
                )
                self._emit(
                    "membership_recipient_removed",
                    fields={
                        "job_id": job_id,
                        "target": job.target.safe_summary(),
                        "user": recipient.user.peer.safe_summary(),
                        "attempt": recipient.rollback_attempts,
                        "response_type": result.response_type,
                        "ban_released": result.ban_released,
                    },
                )
                if options.delay_seconds:
                    time.sleep(options.delay_seconds)
        self.store.finish_rollback(job_id, stop_reason=stop_reason)
        report = self.store.rollback_report(job_id)
        self._emit("membership_rollback_finished", fields=report.safe_summary())
        return report

    def rollback_status(self, job_id: str) -> MembershipRollbackReport:
        self._require_job(job_id)
        return self.store.rollback_report(job_id)

    @staticmethod
    def _classify_error(
        error: EitaaCoreError, *, stop_on_server_error: bool
    ) -> tuple[bool, bool, str]:
        if isinstance(error, RpcError):
            text = error.text.upper()
            systemic = any(
                marker in text
                for marker in (
                    "CHAT_ADMIN_REQUIRED",
                    "CHANNEL_PRIVATE",
                    "CHANNEL_INVALID",
                    "CHAT_ID_INVALID",
                    "PEER_ID_INVALID",
                    "CHAT_WRITE_FORBIDDEN",
                    "USERS_TOO_MUCH",
                )
            )
            if systemic:
                return False, True, f"RPC_{error.code}_{text[:64]}"
            rate = error.code in {420, 429} or any(
                marker in text
                for marker in (
                    "FLOOD",
                    "RATE",
                    "TOO_MANY",
                    "PEER_FLOOD",
                    "LIMIT",
                )
            )
            server = (
                error.code >= 500
                or "INTERNAL_SERVER_ERROR" in text
                or "SERVER" in text
            )
            retryable = rate or server or any(
                marker in text for marker in ("TIMEOUT", "TEMPORARY", "TRY_AGAIN")
            )
            return (
                retryable,
                rate or (server and stop_on_server_error),
                f"RPC_{error.code}_{text[:64]}",
            )
        if isinstance(error, HttpStatusError):
            status = int(error.safe_context.get("http_status", 0) or 0)
            stop = status == 429 or (status >= 500 and stop_on_server_error)
            return stop, stop, f"HTTP_{status}" if status else "HTTP_ERROR"
        if isinstance(error, NetworkError):
            return True, False, "NETWORK_ERROR"
        return False, False, type(error).__name__

    @staticmethod
    def _validate_target(target: Peer) -> None:
        if target.type not in {PeerType.CHAT, PeerType.CHANNEL}:
            raise MembershipError(
                "Membership target must be a group, supergroup, or channel.",
                safe_context={"peer_type": target.type.value},
            )
        target.validate()

    def _require_job(self, job_id: str) -> MembershipJob:
        job = self.store.get_job(job_id)
        if job is None:
            raise MembershipError(
                "Membership job was not found.", safe_context={"job_id": job_id}
            )
        return job

    def _emit_failure(
        self,
        event: str,
        job: MembershipJob,
        recipient: MembershipRecipient,
        error: Exception,
        *,
        retry: bool,
        stop: bool,
        code: str,
    ) -> None:
        self._emit(
            event,
            level="warning" if retry else "error",
            fields={
                "job_id": job.id,
                "target": job.target.safe_summary(),
                "user": recipient.user.peer.safe_summary(),
                "attempt": recipient.add_attempts,
                "retry": retry,
                "stop": stop,
                "error_code": code,
                "error_type": type(error).__name__,
            },
        )

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> None:
        if self.diagnostics:
            self.diagnostics.emit(
                "membership", event, level=level, fields=fields
            )

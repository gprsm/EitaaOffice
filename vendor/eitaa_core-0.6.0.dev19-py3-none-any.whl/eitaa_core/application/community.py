"""Application services for community indexing and persistent bulk messaging."""

from __future__ import annotations

import csv
import json
import time
import unicodedata
from pathlib import Path
from typing import Iterable, Sequence

from ..domain.community import (
    BulkJob,
    BulkMessageDeleteOptions,
    BulkMessageDeleteReport,
    BulkMessageSpec,
    BulkPreview,
    BulkRunReport,
    BulkSendOptions,
    CommunityMember,
    MemberExportResult,
    MemberPage,
    MemberSearchQuery,
    MemberSyncResult,
)
from ..domain.enums import (
    BulkJobStatus,
    BulkRecipientStatus,
    MemberRemoteFilter,
    MemberRole,
    MemberState,
    SendKind,
)
from ..domain.peer import Peer
from ..errors import (
    BulkConfirmationError,
    BulkSendError,
    EitaaCoreError,
    HttpStatusError,
    NetworkError,
    RpcError,
)
from ..infrastructure.diagnostics import DiagnosticManager
from ..infrastructure.persistence.sqlite_community import SQLiteCommunityRepository
from ..ports.community_repository import CommunityRepository
from .send import MessageSendService


_ARABIC_DIACRITICS = {
    chr(code) for code in range(0x064B, 0x0660)
} | {"\u0670"}


def _member_query_variants(value: str) -> tuple[str, ...]:
    """Build literal server-search variants without exposing the query."""
    raw = unicodedata.normalize("NFKC", value).strip()
    if not raw:
        return ("",)

    def clean(text: str) -> str:
        return "".join(ch for ch in text if ch not in _ARABIC_DIACRITICS).replace("\u200c", "")

    persian = clean(raw).translate(
        str.maketrans({"ي": "ی", "ى": "ی", "ئ": "ی", "ك": "ک", "ة": "ه", "ۀ": "ه"})
    )
    arabic = persian.translate(str.maketrans({"ی": "ي", "ک": "ك"}))
    variants: list[str] = []
    for item in (clean(raw), persian, arabic):
        if item and item not in variants:
            variants.append(item)
    return tuple(variants)


class CommunityService:
    """Fetch, page, search, persist, compare, and export group/channel members."""

    def __init__(
        self,
        remote: CommunityRepository,
        store: SQLiteCommunityRepository,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.remote = remote
        self.store = store
        self.diagnostics = diagnostics

    def fetch_page(
        self,
        community: Peer,
        *,
        filter: MemberRemoteFilter = MemberRemoteFilter.RECENT,
        query: str = "",
        offset: int = 0,
        limit: int = 100,
        store: bool = False,
    ) -> MemberPage:
        page = self.remote.fetch_page(
            community, filter=filter, query=query, offset=offset, limit=limit
        )
        if store and page.members:
            self.store.sync_members(community, page.members, complete_snapshot=False)
        return page

    def admins(self, community: Peer, *, offset: int = 0, limit: int = 100, store: bool = False) -> MemberPage:
        return self.fetch_page(
            community,
            filter=MemberRemoteFilter.ADMINS,
            offset=offset,
            limit=limit,
            store=store,
        )

    def search_remote(
        self,
        community: Peer,
        text: str,
        *,
        offset: int = 0,
        limit: int = 100,
        store: bool = False,
    ) -> MemberPage:
        # Eitaa performs literal server-side matching and may distinguish
        # Persian Yeh/Kaf from their Arabic Unicode forms. On the first page,
        # retry safe spelling variants before declaring that no member exists.
        variants = _member_query_variants(text) if offset == 0 else (text,)
        first_empty: MemberPage | None = None
        for variant in variants:
            page = self.fetch_page(
                community,
                filter=MemberRemoteFilter.SEARCH,
                query=variant,
                offset=offset,
                limit=limit,
                store=store,
            )
            if page.members:
                return page
            if first_empty is None:
                first_empty = page
        assert first_empty is not None
        # Eitaa may return an empty result for channelParticipantsSearch even
        # when matching members are already present in the locally indexed
        # snapshot. Keep remote-search useful by falling back to SQLite.
        local = self.store.search_members(
            MemberSearchQuery(
                community=community,
                text=text,
                states=(MemberState.ACTIVE,),
                offset=offset,
                limit=limit,
            )
        )
        if local.members:
            self._emit(
                "members_remote_search_local_fallback",
                fields={
                    "remote_variants_tried": len(variants),
                    "local_count": len(local.members),
                    "local_total": local.total_count,
                },
            )
            return MemberPage(
                community=local.community,
                members=local.members,
                total_count=local.total_count,
                offset=local.offset,
                limit=local.limit,
                response_type="local.fallback_after_remote_empty",
                next_offset=local.next_offset,
            )
        return first_empty

    def sync_all(
        self,
        community: Peer,
        *,
        page_size: int = 200,
        max_pages: int = 10_000,
        expected_total: int | None = None,
    ) -> MemberSyncResult:
        """Fetch the broadest available active-member snapshot and detect joins/leaves.

        Eitaa may expose only a limited recent-member window for broadcast channels.
        Therefore an empty ``channelParticipantsSearch`` query is used for complete
        pagination, while ``recent`` is retained only as a compatibility fallback.
        A stalled or short server listing is never treated as a complete snapshot.
        """
        first_search = self.remote.fetch_page(
            community,
            filter=MemberRemoteFilter.SEARCH,
            query="",
            offset=0,
            limit=page_size,
        )
        first_recent = self.remote.fetch_page(
            community,
            filter=MemberRemoteFilter.RECENT,
            offset=0,
            limit=page_size,
        )

        # Prefer SEARCH on ties because RECENT can be a capped window. If one
        # endpoint reports a larger server total, retain that total as the
        # completeness target even when SEARCH is selected for pagination.
        if expected_total is not None and expected_total < 0:
            raise ValueError("expected_total must be zero or greater.")
        target_total = max(first_search.total_count, first_recent.total_count, expected_total or 0)
        if first_search.members or first_search.total_count:
            selected_filter = MemberRemoteFilter.SEARCH
            page = first_search
        else:
            selected_filter = MemberRemoteFilter.RECENT
            page = first_recent

        members_by_id: dict[int, CommunityMember] = {}
        offset = 0
        complete_snapshot = False
        seen_offsets: set[int] = set()

        for page_index in range(max_pages):
            if page_index:
                page = self.remote.fetch_page(
                    community,
                    filter=selected_filter,
                    query="",
                    offset=offset,
                    limit=page_size,
                )
            target_total = max(target_total, page.total_count)
            before = len(members_by_id)
            for member in page.members:
                members_by_id[member.user.peer.id] = member
            added = len(members_by_id) - before
            self._emit(
                "members_sync_page",
                fields={
                    "page_index": page_index,
                    "filter": selected_filter.value,
                    "added_unique": added,
                    "collected_unique": len(members_by_id),
                    "target_total": target_total,
                    **page.safe_summary(),
                },
            )

            if target_total and len(members_by_id) >= target_total:
                complete_snapshot = True
                break

            next_offset = page.next_offset
            # Some Eitaa responses report a capped count (commonly one page)
            # and omit next_offset even though a caller-provided expected count
            # indicates more members. Probe the following offset explicitly.
            if (
                next_offset is None
                and expected_total is not None
                and len(members_by_id) < expected_total
                and page.members
            ):
                next_offset = page.offset + len(page.members)

            if next_offset is None:
                complete_snapshot = target_total == 0 or len(members_by_id) >= target_total
                break
            if next_offset in seen_offsets or added == 0:
                # Do not mark missing users as LEFT when the server has stopped
                # paginating before the advertised/expected member count.
                complete_snapshot = False
                break
            seen_offsets.add(next_offset)
            offset = next_offset

        all_members = list(members_by_id.values())
        result = self.store.sync_members(
            community, all_members, complete_snapshot=complete_snapshot
        )
        fields = result.safe_summary()
        fields.update(
            {
                "filter": selected_filter.value,
                "server_target_total": max(first_search.total_count, first_recent.total_count),
                "expected_total": expected_total,
                "target_total": target_total,
                "collected_unique": len(all_members),
            }
        )
        self._emit("members_sync_completed", fields=fields)
        return result

    def search_local(self, query: MemberSearchQuery) -> MemberPage:
        return self.store.search_members(query)

    def get(self, community: Peer, user_id: int) -> CommunityMember | None:
        return self.store.get_member(community, user_id)

    def sendable_peers(
        self,
        community: Peer,
        *,
        roles: tuple[MemberRole, ...] = (),
        include_bots: bool = False,
        limit: int = 10_000,
    ) -> tuple[Peer, ...]:
        page = self.search_local(
            MemberSearchQuery(
                community=community,
                roles=roles,
                states=(MemberState.ACTIVE,),
                sendable_only=True,
                include_bots=include_bots,
                limit=limit,
            )
        )
        return tuple(member.send_peer for member in page.members if member.send_peer)

    def export(
        self,
        query: MemberSearchQuery,
        path: Path | str,
        *,
        format: str = "csv",
    ) -> MemberExportResult:
        format = format.lower()
        if format not in {"csv", "json"}:
            raise ValueError("Member export format must be csv or json.")
        members = self._all_local(query)
        target = Path(path).expanduser().resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        rows = [self._export_row(member) for member in members]
        if format == "json":
            target.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
        else:
            fields = list(rows[0].keys()) if rows else [
                "user_id", "display_name", "first_name", "last_name", "username",
                "phone", "role", "state", "is_bot", "is_deleted", "sendable",
                "joined_at", "first_seen_at", "last_seen_at",
            ]
            with target.open("w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader(); writer.writerows(rows)
        result = MemberExportResult(target, format, len(rows))
        self._emit("members_export_completed", fields=result.safe_summary())
        return result

    def _all_local(self, query: MemberSearchQuery) -> tuple[CommunityMember, ...]:
        result: list[CommunityMember] = []
        offset = query.offset
        while True:
            page = self.store.search_members(
                MemberSearchQuery(
                    community=query.community,
                    text=query.text,
                    roles=query.roles,
                    states=query.states,
                    sendable_only=query.sendable_only,
                    include_bots=query.include_bots,
                    offset=offset,
                    limit=min(10_000, query.limit),
                )
            )
            result.extend(page.members)
            if page.next_offset is None:
                break
            offset = page.next_offset
        return tuple(result)

    @staticmethod
    def _export_row(member: CommunityMember) -> dict[str, object]:
        user = member.user
        return {
            "user_id": user.peer.id,
            "display_name": user.display_name,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "username": user.username,
            "phone": str(user.phone) if user.phone else None,
            "role": member.role.value,
            "state": member.state.value,
            "is_bot": user.is_bot,
            "is_deleted": user.is_deleted,
            "sendable": member.is_sendable,
            "joined_at": member.joined_at.isoformat() if member.joined_at else None,
            "fetched_at": member.fetched_at.isoformat(),
        }

    def _emit(self, event: str, *, fields: dict[str, object] | None = None) -> None:
        if self.diagnostics:
            self.diagnostics.emit("members", event, fields=fields)


class BulkSendService:
    """Crash-safe, confirm-before-run personal delivery to selected members."""

    def __init__(
        self,
        members: CommunityService,
        sender: MessageSendService,
        store: SQLiteCommunityRepository,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.members = members
        self.sender = sender
        self.store = store
        self.diagnostics = diagnostics

    def preview(
        self,
        community: Peer,
        *,
        member_ids: Sequence[int] | None = None,
        roles: tuple[MemberRole, ...] = (),
        include_bots: bool = False,
        test_limit: int | None = None,
        sample_limit: int = 10,
    ) -> BulkPreview:
        candidates = self._select_members(
            community, member_ids=member_ids, roles=roles, include_bots=include_bots
        )
        sendable = [item for item in candidates if item.is_sendable]
        selected = sendable[:test_limit] if test_limit else sendable
        preview = BulkPreview(
            eligible_count=len(sendable),
            selected_count=len(selected),
            skipped_unsendable=len(candidates) - len(sendable),
            test_limit=test_limit,
            sample=tuple(
                {
                    "user_id": member.user.peer.id,
                    "display_name": member.user.display_name,
                    "role": member.role.value,
                }
                for member in selected[:sample_limit]
            ),
        )
        self._emit("bulk_preview_created", fields=preview.safe_summary())
        return preview

    def create_job(
        self,
        community: Peer,
        spec: BulkMessageSpec,
        options: BulkSendOptions,
        *,
        member_ids: Sequence[int] | None = None,
        roles: tuple[MemberRole, ...] = (),
        include_bots: bool = False,
    ) -> BulkJob:
        spec.validate(); options.validate()
        candidates = self._select_members(
            community, member_ids=member_ids, roles=roles, include_bots=include_bots
        )
        sendable = [item for item in candidates if item.is_sendable]
        if not sendable:
            raise BulkSendError("No sendable recipients matched the job selection.")
        # Full jobs retain unsendable selected members as SKIPPED so the final
        # sent/failed/skipped report is complete. Test jobs contain only the
        # limited sendable subset requested by the operator.
        recipients = sendable[: options.test_limit] if options.test_limit else candidates
        return self.store.create_job(community, spec, options, recipients)

    def run(self, job_id: str, *, confirm: bool = False) -> BulkRunReport:
        job = self._require_job(job_id)
        if job.status is BulkJobStatus.DRAFT and not confirm:
            raise BulkConfirmationError(
                "Bulk job is still a draft; start it again with explicit confirmation.",
                safe_context={"job_id": job_id, "recipient_count": job.recipient_count},
            )
        if job.status in {BulkJobStatus.COMPLETED, BulkJobStatus.CANCELLED}:
            return self.store.report(job_id)
        if job.status is BulkJobStatus.PAUSED:
            raise BulkSendError("Bulk job is paused. Resume it before running.", safe_context={"job_id": job_id})

        recovered = self.store.recover_processing(job_id)
        self.store.set_job_status(job_id, BulkJobStatus.RUNNING)
        self._emit(
            "bulk_run_started",
            fields={"job": job.safe_summary(), "recovered_processing": recovered},
        )
        while True:
            current = self._require_job(job_id)
            if current.status in {
                BulkJobStatus.PAUSED,
                BulkJobStatus.CANCELLED,
                BulkJobStatus.BLOCKED,
                BulkJobStatus.FAILED,
            }:
                break
            recipient = self.store.claim_next_recipient(job_id)
            if recipient is None:
                report = self.store.report(job_id)
                if report.complete:
                    self.store.set_job_status(job_id, BulkJobStatus.COMPLETED)
                break
            try:
                result = self._send(current, recipient.user.peer, recipient.random_id)
            except EitaaCoreError as exc:
                retryable, stop, code = self._classify_error(exc)
                retry = retryable and recipient.attempts < current.options.max_attempts
                self.store.mark_recipient_error(
                    recipient,
                    retry=retry,
                    error_code=code,
                    error_type=type(exc).__name__,
                )
                self._emit(
                    "bulk_recipient_failed",
                    level="warning" if retry else "error",
                    fields={
                        "job_id": job_id,
                        "recipient": recipient.user.peer.safe_summary(),
                        "attempt": recipient.attempts,
                        "retry": retry,
                        "stop": stop,
                        "error_code": code,
                        "error_type": type(exc).__name__,
                    },
                )
                if stop:
                    self.store.set_job_status(
                        job_id,
                        BulkJobStatus.BLOCKED,
                        stop_reason=code or type(exc).__name__,
                    )
                    break
                if retry and current.options.retry_delay_seconds:
                    time.sleep(current.options.retry_delay_seconds)
                continue
            except Exception as exc:
                self.store.mark_recipient_error(
                    recipient, retry=False, error_code=None, error_type=type(exc).__name__
                )
                self.store.set_job_status(
                    job_id, BulkJobStatus.FAILED, stop_reason=type(exc).__name__
                )
                self._emit(
                    "bulk_run_internal_failure",
                    level="error",
                    fields={"job_id": job_id, "error_type": type(exc).__name__},
                )
                break
            else:
                self.store.mark_recipient_sent(
                    recipient,
                    response_type=result.response_type,
                    message_id=result.message_id,
                )
                self._emit(
                    "bulk_recipient_sent",
                    fields={
                        "job_id": job_id,
                        "recipient": recipient.user.peer.safe_summary(),
                        "attempt": recipient.attempts,
                        "response_type": result.response_type,
                        "message_id": result.message_id,
                    },
                )
                latest = self._require_job(job_id)
                if latest.options.delay_seconds:
                    time.sleep(latest.options.delay_seconds)

        report = self.store.report(job_id)
        self._emit("bulk_run_finished", fields=report.safe_summary())
        return report

    def pause(self, job_id: str) -> BulkJob:
        job = self._require_job(job_id)
        if job.status not in {BulkJobStatus.RUNNING, BulkJobStatus.QUEUED}:
            raise BulkSendError("Only a running or queued job can be paused.")
        return self.store.set_job_status(job_id, BulkJobStatus.PAUSED)

    def resume(self, job_id: str) -> BulkJob:
        job = self._require_job(job_id)
        if job.status not in {BulkJobStatus.PAUSED, BulkJobStatus.BLOCKED, BulkJobStatus.FAILED}:
            raise BulkSendError("This job is not paused or blocked.")
        return self.store.set_job_status(job_id, BulkJobStatus.QUEUED)

    def cancel(self, job_id: str) -> BulkJob:
        job = self._require_job(job_id)
        if job.status is BulkJobStatus.COMPLETED:
            raise BulkSendError("A completed job cannot be cancelled.")
        return self.store.set_job_status(job_id, BulkJobStatus.CANCELLED)

    def report(self, job_id: str) -> BulkRunReport:
        self._require_job(job_id)
        return self.store.report(job_id)

    def jobs(self, *, limit: int = 100) -> tuple[BulkJob, ...]:
        return self.store.list_jobs(limit=limit)

    def recipients(
        self,
        job_id: str,
        *,
        status: BulkRecipientStatus | None = None,
        limit: int = 1000,
    ):
        self._require_job(job_id)
        return self.store.list_recipients(job_id, status=status, limit=limit)

    def delete_messages(
        self,
        job_id: str,
        options: BulkMessageDeleteOptions | None = None,
        *,
        confirm: bool = False,
    ) -> BulkMessageDeleteReport:
        """Delete messages sent by a job with persistent per-recipient state."""
        if not confirm:
            raise BulkConfirmationError(
                "Bulk-message deletion requires explicit confirmation.",
                safe_context={"job_id": job_id},
            )
        self._require_job(job_id)
        options = options or BulkMessageDeleteOptions()
        options.validate()
        self.store.prepare_bulk_message_deletion(job_id)
        recovered = self.store.recover_bulk_delete_processing(job_id)
        self._emit(
            "bulk_delete_started",
            fields={
                "job_id": job_id,
                "options": options.safe_summary(),
                "recovered_processing": recovered,
            },
        )
        stop_reason: str | None = None
        while True:
            recipient = self.store.claim_next_message_deletion(
                job_id, max_attempts=options.max_attempts
            )
            if recipient is None:
                break
            assert recipient.message_id is not None
            try:
                result = self.sender.delete_messages(
                    (recipient.message_id,), revoke=options.revoke
                )
            except EitaaCoreError as exc:
                retryable, stop, code = self._classify_error(
                    exc, stop_on_server_error=options.stop_on_server_error
                )
                retry = retryable and not stop and recipient.delete_attempts < options.max_attempts
                self.store.mark_message_delete_error(
                    recipient, retry=retry, error_code=code, error_type=type(exc).__name__
                )
                self._emit(
                    "bulk_delete_recipient_failed",
                    level="warning" if retry else "error",
                    fields={
                        "job_id": job_id,
                        "recipient": recipient.user.peer.safe_summary(),
                        "message_id": recipient.message_id,
                        "attempt": recipient.delete_attempts,
                        "retry": retry,
                        "stop": stop,
                        "error_code": code,
                        "error_type": type(exc).__name__,
                    },
                )
                if stop:
                    stop_reason = code or type(exc).__name__
                    break
                if retry and options.retry_delay_seconds:
                    time.sleep(options.retry_delay_seconds)
                continue
            except Exception as exc:
                self.store.mark_message_delete_error(
                    recipient, retry=False, error_code="INTERNAL_ERROR",
                    error_type=type(exc).__name__,
                )
                stop_reason = type(exc).__name__
                break
            else:
                self.store.mark_message_deleted(
                    recipient, response_type=result.response_type
                )
                self._emit(
                    "bulk_delete_recipient_completed",
                    fields={
                        "job_id": job_id,
                        "recipient": recipient.user.peer.safe_summary(),
                        "message_id": recipient.message_id,
                        "response_type": result.response_type,
                        "revoke": options.revoke,
                    },
                )
                if options.delay_seconds:
                    time.sleep(options.delay_seconds)
        report = self.store.bulk_message_delete_report(
            job_id, revoke=options.revoke, stop_reason=stop_reason
        )
        self._emit("bulk_delete_finished", fields=report.safe_summary())
        return report

    def delete_status(
        self, job_id: str, *, revoke: bool = True
    ) -> BulkMessageDeleteReport:
        self._require_job(job_id)
        return self.store.bulk_message_delete_report(job_id, revoke=revoke)

    def _select_members(
        self,
        community: Peer,
        *,
        member_ids: Sequence[int] | None,
        roles: tuple[MemberRole, ...],
        include_bots: bool,
    ) -> list[CommunityMember]:
        selected_ids = set(member_ids or ())
        result: list[CommunityMember] = []
        offset = 0
        while True:
            page = self.members.search_local(
                MemberSearchQuery(
                    community=community,
                    roles=roles,
                    states=(MemberState.ACTIVE,),
                    include_bots=include_bots,
                    offset=offset,
                    limit=10_000,
                )
            )
            for member in page.members:
                if not selected_ids or member.user.peer.id in selected_ids:
                    result.append(member)
            if page.next_offset is None:
                break
            offset = page.next_offset
        return result

    def _send(self, job: BulkJob, peer: Peer, random_id: int):
        spec = job.spec
        if spec.kind is SendKind.TEXT:
            return self.sender.send_text(peer, spec.text, random_id=random_id)
        if spec.kind is SendKind.PHOTO:
            assert spec.file_path is not None
            return self.sender.send_photo(
                peer, spec.file_path, caption=spec.caption, random_id=random_id
            )
        assert spec.file_path is not None
        return self.sender.send_file(
            peer,
            spec.file_path,
            caption=spec.caption,
            mime_type=spec.mime_type,
            random_id=random_id,
        )

    @staticmethod
    def _classify_error(
        error: EitaaCoreError, *, stop_on_server_error: bool = True
    ) -> tuple[bool, bool, str | None]:
        if isinstance(error, RpcError):
            text = error.text.upper()
            code = str(error.code)
            rate = error.code in {420, 429} or any(
                marker in text for marker in ("FLOOD", "RATE", "TOO_MANY", "PEER_FLOOD", "LIMIT")
            )
            server = error.code >= 500 or "INTERNAL_SERVER_ERROR" in text or "SERVER" in text
            retryable = rate or server or any(marker in text for marker in ("TIMEOUT", "TEMPORARY", "TRY_AGAIN"))
            return retryable, rate or (server and stop_on_server_error), f"RPC_{code}_{text[:64]}"
        if isinstance(error, HttpStatusError):
            status = int(error.safe_context.get("http_status", 0) or 0)
            stop = status == 429 or (status >= 500 and stop_on_server_error)
            return stop, stop, f"HTTP_{status}" if status else "HTTP_ERROR"
        if isinstance(error, NetworkError):
            return True, False, "NETWORK_ERROR"
        return False, False, type(error).__name__

    def _require_job(self, job_id: str) -> BulkJob:
        job = self.store.get_job(job_id)
        if job is None:
            raise BulkSendError("Bulk job was not found.", safe_context={"job_id": job_id})
        return job

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> None:
        if self.diagnostics:
            self.diagnostics.emit("bulk_send", event, level=level, fields=fields)

"""Authentication repository port."""

from __future__ import annotations

from typing import Protocol

from ..domain.auth import LoginCodeChallenge
from ..domain.phone import PhoneNumber


class AuthRepository(Protocol):
    """Wire-level authentication operations."""

    def request_code(self, phone: PhoneNumber) -> LoginCodeChallenge: ...

    def sign_in(self, challenge: LoginCodeChallenge, code: str) -> bytes: ...

    def get_password(self) -> bytes: ...

    def check_password_srp(self, srp_id: int, a_value: bytes, m1: bytes) -> bytes: ...

    def check_password_legacy(self, password_hash: bytes) -> bytes: ...

"""Port for outbound Eitaa requests.

The application service owns local file iteration, retries, and progress.  This
port owns only one serialized RPC per method call.
"""

from __future__ import annotations

from typing import Protocol

from ..domain.peer import Peer
from ..domain.send import MessageDeleteResult, SendResult, UploadedFile


class SendRepository(Protocol):
    """Infrastructure contract used by :class:`MessageSendService`."""

    def upload_part(
        self,
        peer: Peer,
        *,
        file_id: int,
        part_index: int,
        total_parts: int,
        total_size: int,
        chunk: bytes,
        big: bool,
    ) -> bool:
        """Upload one file part and return the server Bool result."""
        ...

    def send_text(self, peer: Peer, text: str, *, random_id: int) -> SendResult:
        """Send one text message."""
        ...

    def send_photo(
        self,
        peer: Peer,
        uploaded: UploadedFile,
        caption: str,
        *,
        random_id: int,
    ) -> SendResult:
        """Send one previously uploaded photo."""
        ...

    def send_file(
        self,
        peer: Peer,
        uploaded: UploadedFile,
        caption: str,
        *,
        mime_type: str,
        original_name: str,
        random_id: int,
    ) -> SendResult:
        """Send one previously uploaded document/file."""
        ...

    def delete_messages(
        self, message_ids: tuple[int, ...], *, revoke: bool
    ) -> MessageDeleteResult:
        """Delete one or more previously sent private-message ids."""
        ...

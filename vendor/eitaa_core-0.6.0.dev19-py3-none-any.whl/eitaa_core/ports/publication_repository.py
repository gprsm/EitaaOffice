"""Persistence port for external publication workflow state."""

from __future__ import annotations

from typing import Protocol

from ..domain.enums import PublicationStatus
from ..domain.peer import Peer
from ..domain.workflow import PublicationRecord


class PublicationRepository(Protocol):
    """Store one record per message and external destination."""

    def get_publication(
        self, peer: Peer, message_id: int, target_type: str, target_key: str
    ) -> PublicationRecord | None: ...

    def save_publication(self, record: PublicationRecord) -> PublicationRecord: ...

    def list_publications(
        self,
        *,
        peer: Peer | None = None,
        target_type: str | None = None,
        target_key: str | None = None,
        status: PublicationStatus | None = None,
        limit: int = 100,
    ) -> tuple[PublicationRecord, ...]: ...

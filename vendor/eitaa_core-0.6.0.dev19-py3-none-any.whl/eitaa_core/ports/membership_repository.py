"""Remote reversible membership mutation port."""

from __future__ import annotations

from typing import Protocol

from ..domain.membership import MembershipCheckResult, MembershipMutationResult
from ..domain.peer import Peer


class MembershipRepository(Protocol):
    def check_member(self, target: Peer, user: Peer) -> MembershipCheckResult:
        ...

    def add_member(
        self, target: Peer, user: Peer, *, fwd_limit: int = 0
    ) -> MembershipMutationResult:
        ...

    def remove_member(
        self,
        target: Peer,
        user: Peer,
        *,
        revoke_history: bool = False,
        release_channel_ban: bool = True,
    ) -> MembershipMutationResult:
        ...

"""Local dialog snapshot persistence port."""

from __future__ import annotations

from typing import Protocol, Sequence

from ..domain.discovery import DialogCollection, DialogEntry
from ..domain.enums import DialogKind
from ..domain.peer import Peer


class DialogStoreRepository(Protocol):
    def store_snapshot(self, result: DialogCollection) -> int: ...

    def list_dialogs(
        self,
        *,
        kind: DialogKind | None = None,
        active_only: bool = True,
        limit: int = 10_000,
    ) -> tuple[DialogEntry, ...]: ...

    def set_photo_cache(self, peer: Peer, photo_id: int, path: str) -> None: ...

    def mark_read(
        self, peer: Peer, *, max_id: int, remaining_unread_count: int | None = None
    ) -> DialogEntry | None: ...

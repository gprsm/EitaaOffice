"""Peer-discovery repository port."""

from __future__ import annotations

from typing import Protocol

from ..domain.discovery import DialogPage, PeerPhotoReference, UsernameResolution
from ..domain.media import MediaReference
from ..domain.peer import Peer


class DiscoveryRepository(Protocol):
    """Remote dialog and public-username discovery operations."""

    def get_dialogs(
        self,
        *,
        limit: int,
        offset_date: int = 0,
        offset_id: int = 0,
        offset_peer: Peer | None = None,
        exclude_pinned: bool = False,
        folder_id: int | None = None,
        hash_value: int = 0,
    ) -> DialogPage: ...

    def resolve_username(self, username: str) -> UsernameResolution: ...

    def resolve_peer_photo(self, photo: PeerPhotoReference) -> MediaReference: ...

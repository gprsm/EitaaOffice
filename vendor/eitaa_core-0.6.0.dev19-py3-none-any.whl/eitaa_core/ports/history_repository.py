"""Remote history repository port."""

from __future__ import annotations

from typing import Protocol

from ..domain.message import HistoryPage, HistoryQuery, ReadHistoryResult
from ..domain.peer import Peer


class HistoryRepository(Protocol):
    """Fetch normalized history pages from Eitaa."""

    def get_history(self, peer: Peer, query: HistoryQuery) -> HistoryPage:
        """Fetch one page for ``peer``."""
        ...

    def mark_read(self, peer: Peer, max_id: int) -> ReadHistoryResult:
        """Mark messages up to ``max_id`` read on the server."""
        ...


"""Remote community member repository port."""

from __future__ import annotations

from typing import Protocol

from ..domain.community import MemberPage
from ..domain.enums import MemberRemoteFilter
from ..domain.peer import Peer


class CommunityRepository(Protocol):
    def fetch_page(
        self,
        community: Peer,
        *,
        filter: MemberRemoteFilter = MemberRemoteFilter.RECENT,
        query: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> MemberPage:
        ...

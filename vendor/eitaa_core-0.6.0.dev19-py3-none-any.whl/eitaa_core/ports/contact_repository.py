"""Contact repository port.

The application layer depends on this protocol rather than on TL constructors or
HTTP. A different adapter could later read from a mock server, a local cache, or
another compatible transport without changing :class:`ContactService`.
"""

from __future__ import annotations

from typing import Protocol

from ..domain.phone import PhoneNumber
from ..domain.user import (
    Contact,
    ContactDeleteResult,
    ContactImportResult,
    ContactSnapshot,
)


class ContactRepository(Protocol):
    """Remote contact-book operations required by the application layer."""

    def list_contacts(self, *, hash_value: int = 0) -> ContactSnapshot:
        """Fetch the current Eitaa contact snapshot."""
        ...

    def import_contact(
        self,
        phone: PhoneNumber,
        *,
        first_name: str,
        last_name: str = "",
    ) -> ContactImportResult:
        """Import one phone number and return normalized Eitaa users."""
        ...

    def delete_contact(
        self,
        phone: PhoneNumber,
        *,
        known_contact: Contact | None = None,
    ) -> ContactDeleteResult:
        """Remove a contact, using a supported server method or fallback."""
        ...

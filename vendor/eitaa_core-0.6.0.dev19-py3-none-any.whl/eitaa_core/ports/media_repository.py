"""Remote media download port."""

from __future__ import annotations

from typing import Protocol

from ..domain.enums import MediaDownloadMethod
from ..domain.media import MediaChunk, RemoteMediaReference


class MediaRepository(Protocol):
    """Fetch one remote media chunk without exposing TL or HTTP to callers."""

    def fetch_chunk(
        self,
        media: RemoteMediaReference,
        *,
        offset: int,
        limit: int,
        method: MediaDownloadMethod,
        thumb_type: str | None = None,
        endpoint_index: int | None = None,
    ) -> MediaChunk: ...

"""Transport port independent of the requests implementation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Protocol


@dataclass(slots=True, frozen=True)
class TransportRequest:
    """Binary HTTP request passed to a transport adapter."""

    endpoint: str
    body: bytes
    operation: str
    headers: Mapping[str, str] = field(default_factory=dict)


@dataclass(slots=True, frozen=True)
class TransportResponse:
    """Binary HTTP response returned by a transport adapter."""

    status_code: int
    body: bytes
    endpoint: str
    elapsed_seconds: float
    content_type: str | None = None


class BinaryTransport(Protocol):
    """Port implemented by synchronous or asynchronous HTTP adapters."""

    def send(self, request: TransportRequest) -> TransportResponse:
        """Send one binary request and return a normalized response."""
        ...

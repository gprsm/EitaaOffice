"""Session persistence port."""

from __future__ import annotations

from typing import Protocol

from ..domain.session import Session


class SessionRepository(Protocol):
    """Persistence contract used by the application layer.

    Infrastructure adapters may use JSON, an encrypted store, or an operating
    system credential manager without changing core services.
    """

    def load(self) -> Session:
        """Load and validate the current session."""
        ...

    def save(self, session: Session) -> None:
        """Atomically persist a session."""
        ...

    def exists(self) -> bool:
        """Return whether a session is currently stored."""
        ...

    def archive(self, reason: str = "archived") -> str | None:
        """Move the current session aside and return the archive path."""
        ...

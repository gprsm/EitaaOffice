"""Persistence port for named history cursors."""

from __future__ import annotations

from typing import Protocol

from ..domain.peer import Peer
from ..domain.workflow import HistoryCursor


class CursorRepository(Protocol):
    """Store independent history positions for peers and workflows."""

    def get_cursor(self, peer: Peer, key: str) -> HistoryCursor | None: ...
    def save_cursor(self, cursor: HistoryCursor) -> None: ...
    def delete_cursor(self, peer: Peer, key: str) -> bool: ...

"""Public facade for creating a native Eitaa session without an existing token."""

from __future__ import annotations

import time
from dataclasses import dataclass

from .application.auth import AuthenticationService
from .config import EitaaCoreConfig
from .infrastructure.auth import EitaaAuthRepository
from .infrastructure.diagnostics import DiagnosticManager
from .infrastructure.session import JsonSessionRepository
from .infrastructure.transport import RequestsBinaryTransport


def _base36(value: int) -> str:
    alphabet = "0123456789abcdefghijklmnopqrstuvwxyz"
    if value == 0:
        return "0"
    output: list[str] = []
    while value:
        value, remainder = divmod(value, 36)
        output.append(alphabet[remainder])
    return "".join(reversed(output))


def generate_web_imei() -> str:
    """Generate an IMEI-like identifier matching the observed web shape."""
    milliseconds = int(time.time() * 1000)
    return (
        _base36(milliseconds % int(9e65))
        + _base36(milliseconds % int(9e10))
        + "__web"
    )


@dataclass(slots=True)
class EitaaAuth:
    """UI-independent runtime used only for native login."""

    config: EitaaCoreConfig
    imei: str
    diagnostics: DiagnosticManager
    auth: AuthenticationService
    _transport: RequestsBinaryTransport
    _session_repository: JsonSessionRepository

    @classmethod
    def open(
        cls,
        config: EitaaCoreConfig | None = None,
        *,
        imei: str | None = None,
        reuse_existing_imei: bool = True,
    ) -> "EitaaAuth":
        """Assemble login services without requiring a valid session file."""
        config = config or EitaaCoreConfig()
        config.validate()
        diagnostics = DiagnosticManager(
            config.diagnostics_root, enabled=config.diagnostics_enabled
        )
        session_repository = JsonSessionRepository(config.session_file, diagnostics)
        existing_imei = (
            session_repository.peek_imei()
            if imei is None and reuse_existing_imei
            else None
        )
        selected_imei = imei or existing_imei or generate_web_imei()
        transport = RequestsBinaryTransport(
            timeout_seconds=config.timeout_seconds,
            user_agent=config.user_agent,
            diagnostics=diagnostics,
        )
        repository = EitaaAuthRepository(
            config=config,
            imei=selected_imei,
            transport=transport,
            diagnostics=diagnostics,
        )
        service = AuthenticationService(
            repository,
            session_repository,
            imei=selected_imei,
            diagnostics=diagnostics,
        )
        diagnostics.emit(
            "auth",
            "auth_facade_opened",
            fields={
                "session_file": str(config.session_file),
                "imei_present": True,
                "imei_is_web_compatible": selected_imei.endswith("__web"),
                "reused_existing_imei": existing_imei is not None,
            },
        )
        return cls(
            config=config,
            imei=selected_imei,
            diagnostics=diagnostics,
            auth=service,
            _transport=transport,
            _session_repository=session_repository,
        )

    def close(self) -> None:
        self._transport.close()
        self.diagnostics.emit("auth", "auth_facade_closed")

    def __enter__(self) -> "EitaaAuth":
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        if exc is not None:
            self.diagnostics.emit(
                "auth", "auth_context_failed", level="error",
                fields={"error_type": type(exc).__name__},
            )
        self.close()

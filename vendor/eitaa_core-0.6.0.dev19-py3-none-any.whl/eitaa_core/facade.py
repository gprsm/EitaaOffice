"""Public facade consumed by CLI, GUI, and future middleware adapters."""

from __future__ import annotations

from dataclasses import dataclass

from .application import (
    AccountService,
    ContactService,
    CommunityService,
    BulkSendService,
    PhoneListService,
    MembershipService,
    DiscoveryService,
    ExportService,
    HistoryService,
    MediaDownloadService,
    MessageSendService,
    PublicationService,
    RetrievalService,
    MessageStoreService,
    RpcGateway,
    RpcResult,
    SessionLifecycleService,
    SyncService,
    TokenRefreshResult,
    run_local_health_checks,
)
from .application.health import HealthReport
from .config import EitaaCoreConfig
from .domain.enums import EndpointRole
from .domain.session import Session
from .infrastructure.contacts import EitaaContactRepository
from .infrastructure.community import EitaaCommunityRepository
from .infrastructure.membership import EitaaMembershipRepository
from .infrastructure.diagnostics import DiagnosticManager
from .infrastructure.discovery import EitaaDiscoveryRepository
from .infrastructure.history import EitaaHistoryRepository
from .infrastructure.media import EitaaMediaRepository, LocalMediaStorage
from .infrastructure.send import EitaaSendRepository
from .infrastructure.persistence import (
    SQLiteDialogRepository, SQLiteMessageRepository,
    SQLiteCommunityRepository, SQLiteMembershipRepository,
)
from .infrastructure.session import JsonSessionRepository
from .infrastructure.transport import EndpointRouter, RequestsBinaryTransport
from .version import __version__


@dataclass(slots=True)
class EitaaCore:
    """Assembled UI-independent Eitaa core runtime.

    Public frontends use the assembled account, contacts, discovery, history,
    messages, export, media, send, retrieval, publication, and sync services.
    TL constructors, endpoint selection, response parsing, and SQLite statements
    remain private to infrastructure adapters.
    """

    config: EitaaCoreConfig
    session: Session
    diagnostics: DiagnosticManager
    gateway: RpcGateway
    session_lifecycle: SessionLifecycleService
    account: AccountService
    contacts: ContactService
    discovery: DiscoveryService
    export: ExportService
    history: HistoryService
    messages: MessageStoreService
    media: MediaDownloadService
    send: MessageSendService
    retrieval: RetrievalService
    publications: PublicationService
    sync: SyncService
    members: CommunityService
    bulk_send: BulkSendService
    phone_lists: PhoneListService
    membership: MembershipService
    _transport: RequestsBinaryTransport
    _session_repository: JsonSessionRepository
    _contact_repository: EitaaContactRepository
    _discovery_repository: EitaaDiscoveryRepository
    _history_repository: EitaaHistoryRepository
    _media_repository: EitaaMediaRepository
    _send_repository: EitaaSendRepository
    _media_storage: LocalMediaStorage
    _message_repository: SQLiteMessageRepository
    _dialog_repository: SQLiteDialogRepository
    _community_remote_repository: EitaaCommunityRepository
    _community_repository: SQLiteCommunityRepository
    _membership_remote_repository: EitaaMembershipRepository
    _membership_repository: SQLiteMembershipRepository

    @classmethod
    def open(cls, config: EitaaCoreConfig | None = None) -> "EitaaCore":
        """Load the session, migrate SQLite, and assemble cumulative Core 7.4.4 services."""
        config = config or EitaaCoreConfig()
        config.validate()
        diagnostics = DiagnosticManager(
            config.diagnostics_root,
            enabled=config.diagnostics_enabled,
        )
        session_repository = JsonSessionRepository(config.session_file, diagnostics)
        session = session_repository.load()
        endpoint_router = EndpointRouter(config)
        transport = RequestsBinaryTransport(
            timeout_seconds=config.timeout_seconds,
            user_agent=config.user_agent,
            diagnostics=diagnostics,
        )
        session_lifecycle = SessionLifecycleService(
            config=config,
            session=session,
            session_repository=session_repository,
            transport=transport,
            endpoint_router=endpoint_router,
            diagnostics=diagnostics,
        )
        gateway = RpcGateway(
            config=config,
            session=session,
            transport=transport,
            endpoint_router=endpoint_router,
            session_lifecycle=session_lifecycle,
            diagnostics=diagnostics,
        )
        account = AccountService(gateway, session_repository, diagnostics)
        contact_repository = EitaaContactRepository(gateway, diagnostics)
        contacts = ContactService(contact_repository, diagnostics)
        history_repository = EitaaHistoryRepository(gateway, diagnostics)
        message_repository = SQLiteMessageRepository(config.database_file, diagnostics)
        message_repository.initialize()
        dialog_repository = SQLiteDialogRepository(config.database_file, diagnostics)
        dialog_repository.initialize()
        history = HistoryService(history_repository, diagnostics, dialog_repository)
        discovery_repository = EitaaDiscoveryRepository(gateway, diagnostics)
        discovery = DiscoveryService(discovery_repository, diagnostics, dialog_repository)
        messages = MessageStoreService(message_repository)
        export = ExportService(messages, diagnostics)
        media_repository = EitaaMediaRepository(gateway, diagnostics)
        media_storage = LocalMediaStorage(diagnostics)
        media = MediaDownloadService(
            media_repository, media_storage, diagnostics,
            default_output_directory=config.media_directory,
            peer_photo_resolver=discovery.resolve_peer_photo,
        )
        send_repository = EitaaSendRepository(gateway, diagnostics)
        send = MessageSendService(
            send_repository,
            contacts,
            diagnostics,
            max_text_length=config.send_max_text_length,
            max_caption_length=config.send_max_caption_length,
            big_file_threshold=config.upload_big_file_threshold,
        )
        retrieval = RetrievalService(history, messages, message_repository, diagnostics)
        publications = PublicationService(message_repository, messages, diagnostics)
        sync = SyncService(history, messages, diagnostics)
        community_remote_repository = EitaaCommunityRepository(gateway, diagnostics)
        community_repository = SQLiteCommunityRepository(config.database_file, diagnostics)
        community_repository.initialize()
        members = CommunityService(community_remote_repository, community_repository, diagnostics)
        bulk_send = BulkSendService(members, send, community_repository, diagnostics)
        phone_lists = PhoneListService(contacts, members, bulk_send, community_repository, diagnostics)
        membership_remote_repository = EitaaMembershipRepository(gateway, diagnostics)
        membership_repository = SQLiteMembershipRepository(config.database_file, diagnostics)
        membership_repository.initialize()
        membership = MembershipService(
            membership_remote_repository, membership_repository, members, diagnostics
        )
        diagnostics.emit(
            "core",
            "core_opened",
            fields={
                "version": __version__,
                "session": session.safe_summary(),
                "database_file": str(config.database_file),
                "api_endpoint": config.api_endpoint,
                "media_endpoint": config.media_endpoint,
                "download_endpoint_count": len(config.download_endpoints),
                "services": [
                    "session_lifecycle", "account", "contacts", "discovery", "history", "messages", "export",
                    "media", "send", "retrieval", "publications", "sync",
                    "members", "bulk_send", "phone_lists", "membership"
                ],
                "automatic_token_refresh": config.auto_refresh_token,
            },
        )
        return cls(
            config=config,
            session=session,
            diagnostics=diagnostics,
            gateway=gateway,
            session_lifecycle=session_lifecycle,
            account=account,
            contacts=contacts,
            discovery=discovery,
            export=export,
            history=history,
            messages=messages,
            media=media,
            send=send,
            retrieval=retrieval,
            publications=publications,
            sync=sync,
            members=members,
            bulk_send=bulk_send,
            phone_lists=phone_lists,
            membership=membership,
            _transport=transport,
            _session_repository=session_repository,
            _contact_repository=contact_repository,
            _discovery_repository=discovery_repository,
            _history_repository=history_repository,
            _media_repository=media_repository,
            _send_repository=send_repository,
            _media_storage=media_storage,
            _message_repository=message_repository,
            _dialog_repository=dialog_repository,
            _community_remote_repository=community_remote_repository,
            _community_repository=community_repository,
            _membership_remote_repository=membership_remote_repository,
            _membership_repository=membership_repository,
        )


    def capabilities(self) -> dict[str, object]:
        """Return a stable, UI-safe manifest of assembled Core 7 features."""
        return {
            "version": __version__,
            "authentication": {
                "native_login": True,
                "two_factor_srp": True,
                "remote_logout": True,
                "automatic_token_refresh": self.config.auto_refresh_token,
            },
            "discovery": {
                "dialogs": True,
                "complete_pagination": True,
                "dialog_type_classification": True,
                "sqlite_snapshots": True,
                "profile_photo_download": True,
                "cooperative_snapshot_persistence": True,
                "resolve_username": True,
                "peer_file_save": True,
            },
            "contacts": True,
            "history": True,
            "mark_read": True,
            "read_state_cache_consistency": True,
            "local_search": True,
            "local_search_sender_filter": True,
            "date_range_sync": True,
            "media_download": True,
            "send_text": True,
            "send_photo": True,
            "send_file": True,
            "publication_workflow": True,
            "community_management": {
                "members": True,
                "administrators": True,
                "remote_search": True,
                "pagination": True,
                "role_detection": True,
                "sqlite_snapshots": True,
                "join_leave_detection": True,
                "export_formats": ["json", "csv"],
            },
            "bulk_send": {
                "text": True,
                "photo": True,
                "file": True,
                "preview_and_confirmation": True,
                "test_limit": True,
                "pause_resume_cancel": True,
                "persistent_deduplication": True,
                "bounded_retry": True,
                "rate_limit_stop": True,
                "phone_list_sources": ["csv", "txt"],
                "delete_sent_messages": True,
                "persistent_delete_results": True,
            },
            "phone_lists": {
                "inspect_import": True,
                "persistent_resolution": True,
                "contact_import": True,
                "owned_contact_cleanup": True,
                "legacy_cleanup_requires_override": True,
                "masked_diagnostics": True,
                "export_formats": ["json", "csv"],
            },
            "membership": {
                "reversible_bulk_invite": True,
                "phone_list_source": True,
                "basic_groups": True,
                "supergroups": True,
                "channels": True,
                "preview_and_confirmation": True,
                "test_limit": True,
                "pause_resume_cancel": True,
                "persistent_results": True,
                "rollback_only_added_by_job": True,
                "release_channel_ban_after_removal": True,
                "rate_limit_stop": True,
            },
            "export_formats": ["jsonl", "json", "csv"],
            "database_schema": 9,
            "grouped_media": True,
        }

    def doctor(self) -> HealthReport:
        """Run deterministic local checks and create a safe report."""
        return run_local_health_checks(
            config=self.config,
            session=self.session,
            diagnostics=self.diagnostics,
        )

    def logout(self, *, archive_local_session: bool = True):
        """Invalidate the remote session and archive the local file by default."""
        return self.account.logout(archive_local_session=archive_local_session)

    def refresh_token(self) -> TokenRefreshResult:
        """Explicitly refresh and persist the current token.

        Ordinary feature calls do not need this method because
        :class:`RpcGateway` refreshes automatically when the server requests it.
        This explicit method is useful for diagnostics and maintenance.
        """
        return self.session_lifecycle.refresh(force=True)

    def invoke_experimental(
        self,
        packed_method: bytes,
        *,
        operation: str,
        endpoint_role: EndpointRole = EndpointRole.API,
        fallback_index: int = 0,
    ) -> RpcResult:
        """Invoke a serialized method during core development only."""
        return self.gateway.invoke(
            packed_method,
            operation=operation,
            endpoint_role=endpoint_role,
            fallback_index=fallback_index,
        )

    def close(self) -> None:
        """Close persistence and transport resources."""
        self._membership_repository.close()
        self._community_repository.close()
        self._dialog_repository.close()
        self._message_repository.close()
        self._transport.close()
        self.diagnostics.emit("core", "core_closed")

    def __enter__(self) -> "EitaaCore":
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        if exc is not None:
            self.diagnostics.emit(
                "core",
                "context_failed",
                level="error",
                fields={"error_type": type(exc).__name__},
            )
        self.close()

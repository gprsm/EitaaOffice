"""Media domain models shared by readers, downloaders, and senders."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import TypeAlias

from .discovery import PeerPhotoReference
from .enums import MediaDownloadMethod, MediaType


@dataclass(slots=True, frozen=True)
class PhotoSizeReference:
    """One server-declared photo or document thumbnail size.

    Legacy photo sizes may include a file location. Core 5 preserves those
    fields because Eitaa often serves the full/large photo through
    ``inputFileLocation`` rather than ``inputPhotoFileLocation``.
    """

    type: str | None = None
    width: int | None = None
    height: int | None = None
    size: int | None = None
    cached_bytes: bytes | None = field(default=None, repr=False)
    location_constructor: int | None = None
    location_dc_id: int | None = None
    volume_id: int | None = None
    local_id: int | None = None
    secret: int | None = field(default=None, repr=False)

    def safe_summary(self) -> dict[str, object]:
        return {
            "type": self.type,
            "width": self.width,
            "height": self.height,
            "size": self.size,
            "cached_bytes_length": len(self.cached_bytes or b""),
            "legacy_location_present": self.volume_id is not None and self.local_id is not None,
            "location_constructor": (
                f"0x{self.location_constructor & 0xFFFFFFFF:08x}"
                if self.location_constructor is not None else None
            ),
            "location_dc_id": self.location_dc_id,
        }


@dataclass(slots=True, frozen=True)
class MediaReference:
    """Remote media metadata without downloaded bytes."""

    type: MediaType
    remote_id: int | None = None
    access_hash: int | None = field(default=None, repr=False)
    file_reference: bytes | None = field(default=None, repr=False)
    mime_type: str | None = None
    file_name: str | None = None
    size: int | None = None
    dc_id: int | None = None
    date: int | None = None
    thumb_types: tuple[str, ...] = ()
    photo_sizes: tuple[PhotoSizeReference, ...] = ()
    attributes: tuple[str, ...] = ()
    constructor: int | None = None

    def safe_summary(self) -> dict[str, object]:
        """Return a summary that omits access hashes and file references."""
        return {
            "type": self.type.value,
            "remote_id": self.remote_id,
            "access_hash_present": self.access_hash is not None,
            "file_reference_length": len(self.file_reference or b""),
            "mime_type": self.mime_type,
            "file_name_present": bool(self.file_name),
            "file_extension": Path(self.file_name).suffix.lower() if self.file_name else None,
            "size": self.size,
            "dc_id": self.dc_id,
            "date": self.date,
            "thumb_types": list(self.thumb_types),
            "photo_size_count": len(self.photo_sizes),
            "legacy_photo_location_count": sum(
                1 for item in self.photo_sizes
                if item.volume_id is not None and item.local_id is not None
            ),
            "attributes": list(self.attributes),
            "constructor": (
                f"0x{self.constructor & 0xFFFFFFFF:08x}"
                if self.constructor is not None else None
            ),
        }


@dataclass(slots=True, frozen=True)
class LocalMedia:
    """Downloaded or pending-upload local media file."""

    path: Path
    type: MediaType
    mime_type: str | None = None
    size: int | None = None


@dataclass(slots=True, frozen=True)
class MediaChunk:
    """One decoded ``upload.file`` response chunk."""

    data: bytes = field(repr=False)
    offset: int = 0
    requested_limit: int = 0
    file_type: str = "unknown"
    extension: str = "bin"
    modified_time: int = 0
    file_type_constructor: int | None = None
    endpoint: str | None = None
    endpoint_index: int | None = None
    method: MediaDownloadMethod | None = None
    thumb_type: str = ""
    location_kind: str = ""
    expected_size: int | None = None

    def with_transport(self, **changes: object) -> "MediaChunk":
        """Return a copy enriched by repository transport metadata."""
        return replace(self, **changes)

    def safe_summary(self) -> dict[str, object]:
        return {
            "offset": self.offset,
            "requested_limit": self.requested_limit,
            "bytes_length": len(self.data),
            "file_type": self.file_type,
            "extension": self.extension,
            "endpoint": self.endpoint,
            "endpoint_index": self.endpoint_index,
            "method": self.method.value if self.method else None,
            "thumb_type": self.thumb_type,
            "location_kind": self.location_kind,
            "expected_size": self.expected_size,
        }


@dataclass(slots=True, frozen=True)
class MediaDownloadOptions:
    """Application-level controls for a native media download."""

    output_directory: Path = Path("downloads")
    file_name: str | None = None
    overwrite: bool = False
    chunk_size: int = 512 * 1024
    max_bytes: int | None = 100 * 1024 * 1024
    request_delay_seconds: float = 0.35
    method: MediaDownloadMethod = MediaDownloadMethod.AUTO
    photo_thumb_type: str | None = None
    allow_cached_fallback: bool = True
    keep_partial_on_error: bool = True

    def validate(self) -> None:
        if not 32 * 1024 <= self.chunk_size <= 1024 * 1024:
            raise ValueError("chunk_size must be between 32 KiB and 1 MiB.")
        if self.max_bytes is not None and self.max_bytes <= 0:
            raise ValueError("max_bytes must be positive or None.")
        if self.request_delay_seconds < 0:
            raise ValueError("request_delay_seconds cannot be negative.")

    def safe_summary(self) -> dict[str, object]:
        return {
            "output_directory": str(self.output_directory),
            "custom_file_name": self.file_name is not None,
            "overwrite": self.overwrite,
            "chunk_size": self.chunk_size,
            "max_bytes": self.max_bytes,
            "request_delay_seconds": self.request_delay_seconds,
            "method": self.method.value,
            "photo_thumb_type": self.photo_thumb_type,
            "allow_cached_fallback": self.allow_cached_fallback,
            "keep_partial_on_error": self.keep_partial_on_error,
        }


@dataclass(slots=True, frozen=True)
class MediaDownloadResult:
    """Completed local media download."""

    media: MediaReference | PeerPhotoReference
    path: Path
    bytes_written: int
    chunks: int
    method: MediaDownloadMethod | None
    endpoint: str | None
    complete: bool
    used_cached_bytes: bool = False

    def safe_summary(self) -> dict[str, object]:
        return {
            "media": self.media.safe_summary(),
            "file_name_length": len(self.path.name),
            "file_extension": self.path.suffix.lower(),
            "bytes_written": self.bytes_written,
            "chunks": self.chunks,
            "method": self.method.value if self.method else None,
            "endpoint": self.endpoint,
            "complete": self.complete,
            "used_cached_bytes": self.used_cached_bytes,
        }


RemoteMediaReference: TypeAlias = MediaReference | PeerPhotoReference

"""User, status, and contact domain models.

These immutable entities contain normalized information returned by Eitaa. Any
``access_hash`` remains inside :class:`~eitaa_core.domain.peer.Peer`, whose
``repr`` and safe summaries never expose the value.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .enums import ContactResolutionSource, UserStatusKind
from .peer import Peer
from .phone import PhoneNumber


@dataclass(slots=True, frozen=True)
class UserStatus:
    """Privacy-aware normalized presence status.

    ``unknown_or_hidden`` must not be interpreted as definitely offline because
    Eitaa privacy settings can hide the actual value.
    """

    kind: UserStatusKind
    expires_at: datetime | None = None
    was_online_at: datetime | None = None

    def safe_summary(self) -> dict[str, object]:
        """Return status metadata safe for reports and diagnostics."""
        return {
            "kind": self.kind.value,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "was_online_at": (
                self.was_online_at.isoformat() if self.was_online_at else None
            ),
        }


@dataclass(slots=True, frozen=True)
class User:
    """Normalized Eitaa user returned by peer and contact operations."""

    peer: Peer
    first_name: str | None = None
    last_name: str | None = None
    username: str | None = None
    phone: PhoneNumber | None = None
    status: UserStatus | None = None
    is_contact: bool = False
    is_mutual_contact: bool = False
    is_deleted: bool = False
    is_bot: bool = False
    is_verified: bool = False

    @property
    def display_name(self) -> str:
        """Return the best human-readable name available."""
        joined = " ".join(
            item for item in (self.first_name, self.last_name) if item
        ).strip()
        return joined or self.username or str(self.peer.id)

    def safe_summary(self) -> dict[str, object]:
        """Return a secret-free summary for CLI output and diagnostics."""
        return {
            "peer": self.peer.safe_summary(),
            "display_name": self.display_name,
            "username_present": bool(self.username),
            "phone": self.phone.masked if self.phone else None,
            "status": self.status.safe_summary() if self.status else None,
            "is_contact": self.is_contact,
            "is_mutual_contact": self.is_mutual_contact,
            "is_deleted": self.is_deleted,
            "is_bot": self.is_bot,
            "is_verified": self.is_verified,
        }


@dataclass(slots=True, frozen=True)
class Contact:
    """Contact-book view of an Eitaa user."""

    user: User
    mutual: bool = False
    client_id: int | None = None

    @property
    def phone(self) -> PhoneNumber | None:
        """Return the user's phone number when Eitaa exposes it."""
        return self.user.phone

    def safe_summary(self) -> dict[str, object]:
        """Return a report-safe contact representation."""
        return {
            "user": self.user.safe_summary(),
            "mutual": self.mutual,
            "client_id_present": self.client_id is not None,
        }


@dataclass(slots=True, frozen=True)
class ContactSnapshot:
    """One result of ``contacts.getContacts``."""

    contacts: tuple[Contact, ...]
    not_modified: bool = False

    def find_by_phone(self, phone: PhoneNumber | str) -> Contact | None:
        """Find a contact using normalized phone matching."""
        target = phone if isinstance(phone, PhoneNumber) else PhoneNumber.parse(phone)
        for contact in self.contacts:
            if contact.phone and contact.phone.matches(target):
                return contact
        return None

    def safe_summary(self) -> dict[str, object]:
        """Return counts without exposing the complete address book."""
        return {
            "count": len(self.contacts),
            "not_modified": self.not_modified,
            "with_phone_count": sum(1 for item in self.contacts if item.phone),
        }


@dataclass(slots=True, frozen=True)
class ContactImportResult:
    """Normalized result of one ``contacts.importContacts`` request."""

    users: tuple[User, ...]
    imported_user_ids: tuple[int, ...]
    retry_client_ids: tuple[int, ...]
    popular_invite_count: int
    client_id: int

    def safe_summary(self) -> dict[str, object]:
        """Return only non-sensitive import metadata."""
        return {
            "user_count": len(self.users),
            "imported_count": len(self.imported_user_ids),
            "retry_count": len(self.retry_client_ids),
            "popular_invite_count": self.popular_invite_count,
            "client_id_present": True,
        }


@dataclass(slots=True, frozen=True)
class ContactResolution:
    """A user resolved from a phone number for later messaging operations."""

    contact: Contact
    source: ContactResolutionSource
    contact_added: bool

    def safe_summary(self) -> dict[str, object]:
        """Return a result summary without access hashes or full phone numbers."""
        return {
            "contact": self.contact.safe_summary(),
            "source": self.source.value,
            "contact_added": self.contact_added,
        }


@dataclass(slots=True, frozen=True)
class ContactDeleteResult:
    """Result of removing a contact from the Eitaa address book."""

    ok: bool
    method: str
    contact_was_known: bool

    def safe_summary(self) -> dict[str, object]:
        """Return a stable serialization for reports."""
        return {
            "ok": self.ok,
            "method": self.method,
            "contact_was_known": self.contact_was_known,
        }

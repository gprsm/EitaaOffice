"""Reversible bulk membership invitation domain models for Core 7.4."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ..errors import DomainValidationError
from .enums import (
    MembershipAddStatus,
    MembershipJobStatus,
    MembershipRollbackStatus,
)
from .peer import Peer
from .user import User


@dataclass(slots=True, frozen=True)
class MembershipInviteOptions:
    """Bounded controls for adding a resolved phone list to one community."""

    delay_seconds: float = 2.0
    max_attempts: int = 2
    retry_delay_seconds: float = 5.0
    test_limit: int | None = None
    stop_on_server_error: bool = True
    fwd_limit: int = 0

    def validate(self) -> None:
        if self.delay_seconds < 0:
            raise DomainValidationError("Membership delay cannot be negative.")
        if not 1 <= self.max_attempts <= 10:
            raise DomainValidationError("Membership max_attempts must be between 1 and 10.")
        if self.retry_delay_seconds < 0:
            raise DomainValidationError("Membership retry delay cannot be negative.")
        if self.test_limit is not None and self.test_limit < 1:
            raise DomainValidationError("Membership test_limit must be positive.")
        if not 0 <= self.fwd_limit <= 100:
            raise DomainValidationError("Membership fwd_limit must be between 0 and 100.")

    def safe_summary(self) -> dict[str, object]:
        return {
            "delay_seconds": self.delay_seconds,
            "max_attempts": self.max_attempts,
            "retry_delay_seconds": self.retry_delay_seconds,
            "test_limit": self.test_limit,
            "stop_on_server_error": self.stop_on_server_error,
            "fwd_limit": self.fwd_limit,
        }


@dataclass(slots=True, frozen=True)
class MembershipRollbackOptions:
    """Bounded controls for removing only users added by one membership job."""

    delay_seconds: float = 2.0
    max_attempts: int = 2
    retry_delay_seconds: float = 5.0
    stop_on_server_error: bool = True
    revoke_history: bool = False
    release_channel_ban: bool = True

    def validate(self) -> None:
        if self.delay_seconds < 0:
            raise DomainValidationError("Membership rollback delay cannot be negative.")
        if not 1 <= self.max_attempts <= 10:
            raise DomainValidationError("Membership rollback max_attempts must be between 1 and 10.")
        if self.retry_delay_seconds < 0:
            raise DomainValidationError("Membership rollback retry delay cannot be negative.")

    def safe_summary(self) -> dict[str, object]:
        return {
            "delay_seconds": self.delay_seconds,
            "max_attempts": self.max_attempts,
            "retry_delay_seconds": self.retry_delay_seconds,
            "stop_on_server_error": self.stop_on_server_error,
            "revoke_history": self.revoke_history,
            "release_channel_ban": self.release_channel_ban,
        }


@dataclass(slots=True, frozen=True)
class MembershipPreview:
    """Recipient count and safe sample before creating a membership job."""

    list_id: str
    target: Peer
    eligible_count: int
    selected_count: int
    known_existing_count: int
    unresolved_count: int
    test_limit: int | None
    sample: tuple[dict[str, object], ...]

    def safe_summary(self) -> dict[str, object]:
        return {
            "list_id": self.list_id,
            "target": self.target.safe_summary(),
            "eligible_count": self.eligible_count,
            "selected_count": self.selected_count,
            "known_existing_count": self.known_existing_count,
            "unresolved_count": self.unresolved_count,
            "test_limit": self.test_limit,
            "sample": list(self.sample),
        }


@dataclass(slots=True, frozen=True)
class MembershipJob:
    """Persistent reversible membership job metadata."""

    id: str
    list_id: str
    target: Peer
    options: MembershipInviteOptions
    status: MembershipJobStatus
    recipient_count: int
    added_count: int = 0
    already_member_count: int = 0
    failed_count: int = 0
    skipped_count: int = 0
    stop_reason: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    rollback_started_at: datetime | None = None
    rollback_finished_at: datetime | None = None
    rollback_stop_reason: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "id": self.id,
            "list_id": self.list_id,
            "target": self.target.safe_summary(),
            "options": self.options.safe_summary(),
            "status": self.status.value,
            "recipient_count": self.recipient_count,
            "added_count": self.added_count,
            "already_member_count": self.already_member_count,
            "failed_count": self.failed_count,
            "skipped_count": self.skipped_count,
            "stop_reason": self.stop_reason,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "rollback_started_at": self.rollback_started_at.isoformat() if self.rollback_started_at else None,
            "rollback_finished_at": self.rollback_finished_at.isoformat() if self.rollback_finished_at else None,
            "rollback_stop_reason": self.rollback_stop_reason,
        }


@dataclass(slots=True, frozen=True)
class MembershipRecipient:
    """Persistent add and rollback state for one resolved Eitaa user."""

    job_id: str
    entry_id: int
    user: User
    add_status: MembershipAddStatus
    add_attempts: int = 0
    previously_member: bool | None = None
    added_by_job: bool = False
    add_error_code: str | None = None
    add_error_type: str | None = None
    add_response_type: str | None = None
    last_attempt_at: datetime | None = None
    added_at: datetime | None = None
    rollback_status: MembershipRollbackStatus = MembershipRollbackStatus.NOT_REQUIRED
    rollback_attempts: int = 0
    rollback_error_code: str | None = None
    rollback_error_type: str | None = None
    rollback_response_type: str | None = None
    rollback_updated_at: datetime | None = None
    removed_at: datetime | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "job_id": self.job_id,
            "entry_id": self.entry_id,
            "user": self.user.safe_summary(),
            "add_status": self.add_status.value,
            "add_attempts": self.add_attempts,
            "previously_member": self.previously_member,
            "added_by_job": self.added_by_job,
            "add_error_code": self.add_error_code,
            "add_error_type": self.add_error_type,
            "add_response_type": self.add_response_type,
            "last_attempt_at": self.last_attempt_at.isoformat() if self.last_attempt_at else None,
            "added_at": self.added_at.isoformat() if self.added_at else None,
            "rollback_status": self.rollback_status.value,
            "rollback_attempts": self.rollback_attempts,
            "rollback_error_code": self.rollback_error_code,
            "rollback_error_type": self.rollback_error_type,
            "rollback_response_type": self.rollback_response_type,
            "rollback_updated_at": self.rollback_updated_at.isoformat() if self.rollback_updated_at else None,
            "removed_at": self.removed_at.isoformat() if self.removed_at else None,
        }


@dataclass(slots=True, frozen=True)
class MembershipCheckResult:
    """Remote membership check result."""

    is_member: bool
    response_type: str

    def safe_summary(self) -> dict[str, object]:
        return {"is_member": self.is_member, "response_type": self.response_type}


@dataclass(slots=True, frozen=True)
class MembershipMutationResult:
    """Normalized add/remove RPC result."""

    accepted: bool
    response_type: str
    ban_released: bool | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "accepted": self.accepted,
            "response_type": self.response_type,
            "ban_released": self.ban_released,
        }


@dataclass(slots=True, frozen=True)
class MembershipRunReport:
    """Current add-job result."""

    job: MembershipJob
    pending: int
    processing: int

    @property
    def complete(self) -> bool:
        return self.pending == 0 and self.processing == 0

    def safe_summary(self) -> dict[str, object]:
        return {
            "job": self.job.safe_summary(),
            "pending": self.pending,
            "processing": self.processing,
            "complete": self.complete,
        }


@dataclass(slots=True, frozen=True)
class MembershipRollbackReport:
    """Current rollback result for one membership job."""

    job_id: str
    added_by_job: int
    eligible: int
    removed: int
    removed_but_restricted: int
    failed: int
    pending: int
    processing: int
    complete: bool
    stop_reason: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "job_id": self.job_id,
            "added_by_job": self.added_by_job,
            "eligible": self.eligible,
            "removed": self.removed,
            "removed_but_restricted": self.removed_but_restricted,
            "failed": self.failed,
            "pending": self.pending,
            "processing": self.processing,
            "complete": self.complete,
            "stop_reason": self.stop_reason,
        }

"""Authentication domain models for staged native login.

The core never asks for input directly. CLI, GUI, or middleware frontends call
``request_code`` and then submit the user-provided code or second-factor
password through explicit methods.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from .phone import PhoneNumber
from .session import Session


class CodeDeliveryType(StrEnum):
    """Delivery channel reported by ``auth.sentCode``."""

    APP = "app"
    SMS = "sms"
    CALL = "call"
    FLASH_CALL = "flash_call"
    UNKNOWN = "unknown"


@dataclass(slots=True, frozen=True)
class LoginCodeChallenge:
    """Pending login-code challenge returned by Eitaa.

    ``phone_code_hash`` is authentication state and is intentionally hidden
    from representations and diagnostic summaries.
    """

    phone: PhoneNumber
    phone_code_hash: str = field(repr=False)
    delivery_type: CodeDeliveryType = CodeDeliveryType.UNKNOWN
    code_length: int | None = None
    next_type: CodeDeliveryType | None = None
    timeout_seconds: int | None = None

    def safe_summary(self) -> dict[str, object]:
        """Return non-secret challenge metadata."""
        return {
            "phone": self.phone.masked,
            "phone_code_hash_present": bool(self.phone_code_hash),
            "delivery_type": self.delivery_type.value,
            "code_length": self.code_length,
            "next_type": self.next_type.value if self.next_type else None,
            "timeout_seconds": self.timeout_seconds,
        }


@dataclass(slots=True, frozen=True)
class PasswordChallenge:
    """Public description of a required second-factor password step."""

    algorithm: str
    hint: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {"algorithm": self.algorithm, "hint_present": bool(self.hint)}


@dataclass(slots=True, frozen=True)
class LoginStepResult:
    """Result of submitting a login code.

    Exactly one of ``session`` and ``password_challenge`` is populated.
    """

    session: Session | None = None
    password_challenge: PasswordChallenge | None = None

    @property
    def completed(self) -> bool:
        return self.session is not None

    @property
    def password_required(self) -> bool:
        return self.password_challenge is not None

    def safe_summary(self) -> dict[str, object]:
        return {
            "completed": self.completed,
            "password_required": self.password_required,
            "session": self.session.safe_summary() if self.session else None,
            "password_challenge": (
                self.password_challenge.safe_summary()
                if self.password_challenge
                else None
            ),
        }


@dataclass(slots=True, frozen=True)
class LogoutResult:
    """Result of invalidating the remote session."""

    remote_ok: bool
    local_session_archived: bool = False
    archived_path: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "remote_ok": self.remote_ok,
            "local_session_archived": self.local_session_archived,
            "archived_path": self.archived_path,
        }

"""Session domain model.

Secrets are excluded from ``repr`` and from all safe summaries. Consumers must
never log or serialize the dataclass through a generic ``asdict`` operation.
Use the explicit session repository instead.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from ..errors import SessionValidationError


@dataclass(slots=True, frozen=True)
class EitaaAppInfo:
    """Client identity fields sent only during token refresh.

    Defaults are configured by :class:`eitaa_core.EitaaCoreConfig`. These
    values are not authentication secrets, but diagnostics still expose only a
    compact summary rather than the complete strings.
    """

    build_version: int
    device_model: str
    system_version: str
    app_version: str
    lang_code: str
    sign: str = ""

    def validate(self) -> None:
        """Validate values against their TL representations."""
        if not -(2**31) <= self.build_version <= 2**31 - 1:
            raise SessionValidationError("Refresh build_version must fit int32.")
        for name in (
            "device_model",
            "system_version",
            "app_version",
            "lang_code",
            "sign",
        ):
            value = getattr(self, name)
            if not isinstance(value, str):
                raise SessionValidationError(
                    f"Refresh app info {name} must be a string."
                )
        if not self.device_model or not self.system_version or not self.app_version:
            raise SessionValidationError(
                "Refresh app info requires device, system, and app version strings."
            )
        if not self.lang_code:
            raise SessionValidationError("Refresh app info lang_code is required.")

    def safe_summary(self) -> dict[str, Any]:
        """Return non-secret lengths and stable numeric fields for diagnostics."""
        return {
            "build_version": self.build_version,
            "device_model_length": len(self.device_model),
            "system_version_length": len(self.system_version),
            "app_version_length": len(self.app_version),
            "lang_code": self.lang_code,
            "sign_present": bool(self.sign),
            "sign_length": len(self.sign),
        }


@dataclass(slots=True)
class Session:
    """Authenticated Eitaa web-compatible session.

    Args:
        token: Authentication token returned by ``auth.authorization``.
        imei: Device identifier. Web-compatible sessions normally end in
            ``__web``.
        dc: Optional data-center number retained for compatibility.
        created_at: UTC creation time when known.
        metadata: Non-secret metadata. Sensitive keys are rejected.
    """

    token: str = field(repr=False)
    imei: str = field(repr=False)
    dc: int | None = None
    created_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        """Validate required secret values without exposing them in errors."""
        if not isinstance(self.token, str) or not self.token.strip():
            raise SessionValidationError("Session token is missing or empty.")
        if not isinstance(self.imei, str) or not self.imei.strip():
            raise SessionValidationError("Session IMEI is missing or empty.")
        if self.dc is not None and not isinstance(self.dc, int):
            raise SessionValidationError("Session dc must be an integer or null.")

        forbidden = {
            "token",
            "imei",
            "password",
            "phone_code",
            "phone_code_hash",
            "access_hash",
        }
        offending = forbidden.intersection(key.lower() for key in self.metadata)
        if offending:
            raise SessionValidationError(
                "Session metadata contains forbidden sensitive keys.",
                safe_context={"forbidden_keys": sorted(offending)},
            )

    @property
    def is_web_compatible(self) -> bool:
        """Return whether the IMEI follows the observed web-client format."""
        return self.imei.endswith("__web")

    def safe_summary(self) -> dict[str, Any]:
        """Return a diagnostic-safe summary containing no secret values."""
        return {
            "token_present": bool(self.token),
            "token_length": len(self.token),
            "imei_present": bool(self.imei),
            "imei_length": len(self.imei),
            "imei_is_web_compatible": self.is_web_compatible,
            "dc": self.dc,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "metadata_keys": sorted(self.metadata),
        }

    @classmethod
    def now(
        cls,
        *,
        token: str,
        imei: str,
        dc: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "Session":
        """Create a session stamped with the current UTC time."""
        return cls(
            token=token,
            imei=imei,
            dc=dc,
            created_at=datetime.now(timezone.utc),
            metadata=dict(metadata or {}),
        )

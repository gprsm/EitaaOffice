"""Local message export domain models."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .enums import ExportFormat


@dataclass(slots=True, frozen=True)
class ExportOptions:
    """Controls for exporting locally stored messages.

    Export files may contain full message text and must be treated as private
    application data, unlike diagnostic files.
    """

    output_file: Path
    format: ExportFormat = ExportFormat.JSONL
    page_size: int = 500
    max_messages: int | None = None
    overwrite: bool = False

    def validate(self) -> None:
        if not 1 <= self.page_size <= 10_000:
            raise ValueError("Export page_size must be between 1 and 10000.")
        if self.max_messages is not None and self.max_messages < 1:
            raise ValueError("max_messages must be positive or None.")
        if self.output_file.exists() and not self.overwrite:
            raise FileExistsError(
                f"Export file already exists: {self.output_file}. Use overwrite=True."
            )

    def safe_summary(self) -> dict[str, object]:
        return {
            "output_directory": str(self.output_file.parent),
            "file_extension": self.output_file.suffix.lower(),
            "format": self.format.value,
            "page_size": self.page_size,
            "max_messages": self.max_messages,
            "overwrite": self.overwrite,
        }


@dataclass(slots=True, frozen=True)
class ExportResult:
    """Outcome of one local export operation."""

    path: Path
    format: ExportFormat
    message_count: int
    pages: int
    complete: bool

    def safe_summary(self) -> dict[str, object]:
        return {
            "file_name": self.path.name,
            "file_extension": self.path.suffix.lower(),
            "format": self.format.value,
            "message_count": self.message_count,
            "pages": self.pages,
            "complete": self.complete,
        }

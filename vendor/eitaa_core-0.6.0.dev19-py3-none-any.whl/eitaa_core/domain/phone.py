"""Phone-number value object used by contact and message workflows.

The core stores a normalized international representation and deliberately masks
it in ``repr`` and diagnostic summaries. Iranian mobile numbers are recognized
both with the local leading zero (``09...``) and without it (``9...``). Already
international numbers beginning with ``+`` are preserved.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..errors import PhoneNumberError


def _digits(value: str) -> str:
    """Return only decimal digits from a phone-like value."""
    return "".join(character for character in value if character.isdigit())


@dataclass(slots=True, frozen=True)
class PhoneNumber:
    """Normalized phone number safe to pass between core layers.

    Args:
        value: International number beginning with ``+``. Use :meth:`parse`
            rather than constructing this class directly in application code.
    """

    value: str = field(repr=False)

    @classmethod
    def parse(cls, raw: str) -> "PhoneNumber":
        """Normalize common Iranian and international phone formats.

        Accepted examples include ``09361234567``, ``9361234567``,
        ``989361234567``, ``00989361234567`` and ``+989361234567``.

        A ten-digit number beginning with ``9`` is treated as an Iranian mobile
        number whose local leading zero was omitted, which commonly happens
        when spreadsheets store phone numbers as numeric cells.
        """
        if not isinstance(raw, str):
            raise PhoneNumberError(
                "Phone number must be a string.",
                safe_context={"value_type": type(raw).__name__},
            )
        cleaned = raw.strip().replace(" ", "").replace("-", "")
        cleaned = cleaned.replace("(", "").replace(")", "")
        if cleaned.startswith("00"):
            cleaned = "+" + cleaned[2:]
        elif cleaned.startswith("0"):
            cleaned = "+98" + cleaned[1:]
        elif cleaned.startswith("98"):
            cleaned = "+" + cleaned
        elif not cleaned.startswith("+"):
            # Excel and similar tools often remove the leading zero from an
            # Iranian mobile number. A local mobile then has exactly ten digits
            # and starts with 9, e.g. 9121234567 -> +989121234567.
            local_digits = _digits(cleaned)
            if cleaned == local_digits and len(local_digits) == 10 and local_digits.startswith("9"):
                cleaned = "+98" + local_digits
            else:
                # Preserve the existing generic behavior for international
                # numbers supplied without a plus sign.
                cleaned = "+" + cleaned

        digits = _digits(cleaned)
        if not cleaned.startswith("+") or not digits:
            raise PhoneNumberError("Phone number could not be normalized.")
        if len(digits) < 8 or len(digits) > 15:
            raise PhoneNumberError(
                "Phone number length is outside the supported range.",
                safe_context={"digit_count": len(digits)},
            )
        if cleaned != "+" + digits:
            raise PhoneNumberError("Phone number contains unsupported characters.")
        return cls(cleaned)

    @property
    def canonical_digits(self) -> str:
        """Return the normalized number without the leading plus sign."""
        return self.value[1:]

    @property
    def masked(self) -> str:
        """Return a report-safe representation."""
        digits = self.canonical_digits
        if len(digits) <= 6:
            return "+***"
        return "+" + digits[:3] + "*" * max(4, len(digits) - 7) + digits[-4:]

    def matches(self, other: "PhoneNumber | str") -> bool:
        """Compare normalized numbers, tolerating equivalent local suffixes."""
        candidate = other if isinstance(other, PhoneNumber) else PhoneNumber.parse(other)
        left = self.canonical_digits
        right = candidate.canonical_digits
        return left == right or (
            len(left) >= 10 and len(right) >= 10 and left[-10:] == right[-10:]
        )

    def safe_summary(self) -> dict[str, object]:
        """Return a diagnostic-safe representation."""
        return {"phone": self.masked, "digit_count": len(self.canonical_digits)}

    def __str__(self) -> str:
        """Return the normalized value for serialization and API requests."""
        return self.value

    def __repr__(self) -> str:
        return f"PhoneNumber(masked={self.masked!r})"

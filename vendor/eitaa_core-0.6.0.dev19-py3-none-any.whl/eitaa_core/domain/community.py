"""Community member and persistent bulk-messaging domain models."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from ..errors import DomainValidationError
from .enums import (
    BulkDeleteStatus,
    BulkJobStatus,
    BulkRecipientStatus,
    MemberRemoteFilter,
    MemberRole,
    MemberState,
    SendKind,
)
from .peer import Peer
from .user import User


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True, frozen=True)
class CommunityMember:
    """One normalized member of a basic group, supergroup, or channel."""

    community: Peer
    user: User
    role: MemberRole = MemberRole.MEMBER
    state: MemberState = MemberState.ACTIVE
    joined_at: datetime | None = None
    inviter_id: int | None = None
    promoted_by: int | None = None
    rank: str | None = None
    can_edit: bool = False
    fetched_at: datetime = field(default_factory=_utc_now)

    @property
    def send_peer(self) -> Peer | None:
        """Return a personal send peer when Eitaa supplied an access hash."""
        peer = self.user.peer
        if peer.access_hash is None or self.user.is_deleted:
            return None
        return peer

    @property
    def is_sendable(self) -> bool:
        return self.state is MemberState.ACTIVE and self.send_peer is not None

    def safe_summary(self) -> dict[str, object]:
        return {
            "community": self.community.safe_summary(),
            "user": self.user.safe_summary(),
            "role": self.role.value,
            "state": self.state.value,
            "joined_at": self.joined_at.isoformat() if self.joined_at else None,
            "inviter_id_present": self.inviter_id is not None,
            "promoted_by_present": self.promoted_by is not None,
            "rank_present": bool(self.rank),
            "can_edit": self.can_edit,
            "sendable": self.is_sendable,
        }


@dataclass(slots=True, frozen=True)
class MemberPage:
    """One remote or local page of community members."""

    community: Peer
    members: tuple[CommunityMember, ...]
    total_count: int
    offset: int
    limit: int
    response_type: str
    next_offset: int | None = None
    not_modified: bool = False

    def safe_summary(self) -> dict[str, object]:
        return {
            "community": self.community.safe_summary(),
            "count": len(self.members),
            "total_count": self.total_count,
            "offset": self.offset,
            "limit": self.limit,
            "next_offset": self.next_offset,
            "response_type": self.response_type,
            "not_modified": self.not_modified,
            "sendable_count": sum(item.is_sendable for item in self.members),
        }


@dataclass(slots=True, frozen=True)
class MemberSyncResult:
    """Result of persisting one complete or partial membership snapshot."""

    fetched: int
    inserted: int
    updated: int
    unchanged: int
    reactivated: int
    marked_left: int
    complete_snapshot: bool

    def safe_summary(self) -> dict[str, object]:
        return {
            "fetched": self.fetched,
            "inserted": self.inserted,
            "updated": self.updated,
            "unchanged": self.unchanged,
            "reactivated": self.reactivated,
            "marked_left": self.marked_left,
            "complete_snapshot": self.complete_snapshot,
        }


@dataclass(slots=True, frozen=True)
class MemberSearchQuery:
    """Local member filtering and pagination."""

    community: Peer
    text: str | None = None
    roles: tuple[MemberRole, ...] = ()
    states: tuple[MemberState, ...] = (MemberState.ACTIVE,)
    sendable_only: bool = False
    include_bots: bool = True
    offset: int = 0
    limit: int = 100

    def validate(self) -> None:
        if self.offset < 0:
            raise DomainValidationError("Member offset cannot be negative.")
        if not 1 <= self.limit <= 10_000:
            raise DomainValidationError(
                "Member limit must be between 1 and 10000.",
                safe_context={"limit": self.limit},
            )


@dataclass(slots=True, frozen=True)
class MemberExportResult:
    """Metadata for a member CSV or JSON export."""

    path: Path
    format: str
    count: int

    def safe_summary(self) -> dict[str, object]:
        return {"path": str(self.path), "format": self.format, "count": self.count}


@dataclass(slots=True, frozen=True)
class BulkMessageSpec:
    """Private job payload stored in SQLite for resumable delivery."""

    kind: SendKind
    text: str = ""
    file_path: Path | None = None
    caption: str = ""
    mime_type: str | None = None

    def validate(self) -> None:
        if self.kind is SendKind.TEXT:
            if not self.text:
                raise DomainValidationError("Bulk text cannot be empty.")
            if self.file_path is not None:
                raise DomainValidationError("Text bulk jobs cannot include a file.")
        else:
            if self.file_path is None:
                raise DomainValidationError("Photo and file bulk jobs require file_path.")
            if not Path(self.file_path).expanduser().is_file():
                raise DomainValidationError(
                    "Bulk upload file does not exist.",
                    safe_context={"file_present": False},
                )

    @property
    def content_hash(self) -> str:
        payload = {
            "kind": self.kind.value,
            "text": self.text,
            "file_path": str(self.file_path) if self.file_path else None,
            "caption": self.caption,
            "mime_type": self.mime_type,
        }
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def safe_summary(self) -> dict[str, object]:
        return {
            "kind": self.kind.value,
            "text_length": len(self.text),
            "file_present": self.file_path is not None,
            "caption_length": len(self.caption),
            "mime_type_present": bool(self.mime_type),
            "content_hash_prefix": self.content_hash[:12],
        }


@dataclass(slots=True, frozen=True)
class BulkSendOptions:
    """Persistent execution controls for a bulk-send job."""

    delay_seconds: float = 2.0
    max_attempts: int = 3
    retry_delay_seconds: float = 5.0
    test_limit: int | None = None
    stop_on_server_error: bool = True

    def validate(self) -> None:
        if self.delay_seconds < 0:
            raise DomainValidationError("Bulk delay cannot be negative.")
        if not 1 <= self.max_attempts <= 10:
            raise DomainValidationError("Bulk max_attempts must be between 1 and 10.")
        if self.retry_delay_seconds < 0:
            raise DomainValidationError("Bulk retry delay cannot be negative.")
        if self.test_limit is not None and self.test_limit < 1:
            raise DomainValidationError("Bulk test_limit must be positive.")

    def safe_summary(self) -> dict[str, object]:
        return {
            "delay_seconds": self.delay_seconds,
            "max_attempts": self.max_attempts,
            "retry_delay_seconds": self.retry_delay_seconds,
            "test_limit": self.test_limit,
            "stop_on_server_error": self.stop_on_server_error,
        }


@dataclass(slots=True, frozen=True)
class BulkPreview:
    """Recipient count and sample shown before a job is confirmed."""

    eligible_count: int
    selected_count: int
    skipped_unsendable: int
    test_limit: int | None
    sample: tuple[dict[str, object], ...]

    def safe_summary(self) -> dict[str, object]:
        return {
            "eligible_count": self.eligible_count,
            "selected_count": self.selected_count,
            "skipped_unsendable": self.skipped_unsendable,
            "test_limit": self.test_limit,
            "sample": list(self.sample),
        }


@dataclass(slots=True, frozen=True)
class BulkJob:
    """Persistent bulk-send job metadata."""

    id: str
    community: Peer
    spec: BulkMessageSpec
    options: BulkSendOptions
    status: BulkJobStatus
    recipient_count: int
    sent_count: int = 0
    failed_count: int = 0
    skipped_count: int = 0
    stop_reason: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "id": self.id,
            "community": self.community.safe_summary(),
            "spec": self.spec.safe_summary(),
            "options": self.options.safe_summary(),
            "status": self.status.value,
            "recipient_count": self.recipient_count,
            "sent_count": self.sent_count,
            "failed_count": self.failed_count,
            "skipped_count": self.skipped_count,
            "stop_reason": self.stop_reason,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
        }


@dataclass(slots=True, frozen=True)
class BulkRecipient:
    """Persistent delivery state for one selected member."""

    job_id: str
    user: User
    role: MemberRole
    status: BulkRecipientStatus
    random_id: int
    attempts: int = 0
    error_code: str | None = None
    error_type: str | None = None
    response_type: str | None = None
    message_id: int | None = None
    last_attempt_at: datetime | None = None
    sent_at: datetime | None = None
    delete_status: BulkDeleteStatus = BulkDeleteStatus.NOT_REQUESTED
    delete_attempts: int = 0
    delete_error_code: str | None = None
    delete_error_type: str | None = None
    delete_response_type: str | None = None
    delete_updated_at: datetime | None = None
    deleted_at: datetime | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "job_id": self.job_id,
            "user": self.user.safe_summary(),
            "role": self.role.value,
            "status": self.status.value,
            "attempts": self.attempts,
            "random_id_present": True,
            "error_code": self.error_code,
            "error_type": self.error_type,
            "response_type": self.response_type,
            "message_id": self.message_id,
            "last_attempt_at": self.last_attempt_at.isoformat() if self.last_attempt_at else None,
            "sent_at": self.sent_at.isoformat() if self.sent_at else None,
            "delete_status": self.delete_status.value,
            "delete_attempts": self.delete_attempts,
            "delete_error_code": self.delete_error_code,
            "delete_error_type": self.delete_error_type,
            "delete_response_type": self.delete_response_type,
            "delete_updated_at": self.delete_updated_at.isoformat() if self.delete_updated_at else None,
            "deleted_at": self.deleted_at.isoformat() if self.deleted_at else None,
        }


@dataclass(slots=True, frozen=True)
class BulkMessageDeleteOptions:
    """Bounded controls for deleting messages produced by one bulk job."""

    revoke: bool = True
    delay_seconds: float = 1.0
    max_attempts: int = 2
    retry_delay_seconds: float = 3.0
    stop_on_server_error: bool = True

    def validate(self) -> None:
        if self.delay_seconds < 0:
            raise DomainValidationError("Bulk delete delay cannot be negative.")
        if not 1 <= self.max_attempts <= 10:
            raise DomainValidationError("Bulk delete max_attempts must be between 1 and 10.")
        if self.retry_delay_seconds < 0:
            raise DomainValidationError("Bulk delete retry delay cannot be negative.")

    def safe_summary(self) -> dict[str, object]:
        return {
            "revoke": self.revoke,
            "delay_seconds": self.delay_seconds,
            "max_attempts": self.max_attempts,
            "retry_delay_seconds": self.retry_delay_seconds,
            "stop_on_server_error": self.stop_on_server_error,
        }


@dataclass(slots=True, frozen=True)
class BulkMessageDeleteReport:
    """Persistent deletion outcome for messages sent by a bulk job."""

    job_id: str
    sent_recipients: int
    eligible: int
    deleted: int
    failed: int
    missing_message_id: int
    pending: int
    processing: int
    revoke: bool
    complete: bool
    stop_reason: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "job_id": self.job_id,
            "sent_recipients": self.sent_recipients,
            "eligible": self.eligible,
            "deleted": self.deleted,
            "failed": self.failed,
            "missing_message_id": self.missing_message_id,
            "pending": self.pending,
            "processing": self.processing,
            "revoke": self.revoke,
            "complete": self.complete,
            "stop_reason": self.stop_reason,
        }


@dataclass(slots=True, frozen=True)
class BulkRunReport:
    """Final or interim delivery report."""

    job: BulkJob
    pending: int
    processing: int

    @property
    def complete(self) -> bool:
        return self.pending == 0 and self.processing == 0

    def safe_summary(self) -> dict[str, object]:
        return {
            "job": self.job.safe_summary(),
            "pending": self.pending,
            "processing": self.processing,
            "complete": self.complete,
        }

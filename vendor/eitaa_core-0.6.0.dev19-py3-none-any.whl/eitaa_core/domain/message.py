"""Message and history domain models.

These dataclasses are deliberately independent of TL constructors, SQLite, CLI,
and UI code.  They form the stable contract consumed by repositories and
frontends.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from .media import MediaReference
from .peer import Peer


@dataclass(slots=True, frozen=True)
class Message:
    """Normalized Eitaa message.

    Args:
        id: Message identifier inside ``peer``.
        peer: Conversation to which the message belongs.
        date: Message timestamp as timezone-aware UTC datetime.
        text: UTF-8 message text.
        media: Optional normalized remote media reference.
        outgoing: Whether the authenticated account sent the message.
        from_peer: Explicit sender when supplied by Eitaa.
        reply_to_message_id: Replied message id when available.
        grouped_id: Server-provided identifier shared by media in one album.
        flags: Original message flags. Kept for deterministic debugging.
        parse_warning: Non-fatal conservative-parser warning.
    """

    id: int
    peer: Peer
    date: datetime
    text: str = ""
    media: MediaReference | None = None
    outgoing: bool = False
    from_peer: Peer | None = None
    reply_to_message_id: int | None = None
    grouped_id: int | None = None
    flags: int = 0
    parse_warning: str | None = None

    def safe_summary(self) -> dict[str, object]:
        """Return metadata safe for diagnostics.

        Message text is represented only by its length.  Access hashes and file
        references are omitted by nested ``safe_summary`` methods.
        """
        return {
            "id": self.id,
            "peer": self.peer.safe_summary(),
            "date": self.date.isoformat(),
            "text_length": len(self.text),
            "media": self.media.safe_summary() if self.media else None,
            "outgoing": self.outgoing,
            "from_peer": self.from_peer.safe_summary() if self.from_peer else None,
            "reply_to_message_id": self.reply_to_message_id,
            "grouped_id": self.grouped_id,
            "flags_hex": f"0x{self.flags & 0xFFFFFFFF:08x}",
            "parse_warning_present": bool(self.parse_warning),
        }


@dataclass(slots=True, frozen=True)
class HistoryQuery:
    """Pagination arguments accepted by ``messages.getHistory``."""

    limit: int = 20
    offset_id: int = 0
    offset_date: int = 0
    add_offset: int = 0
    max_id: int = 0
    min_id: int = 0
    hash_value: int = 0

    def validate(self) -> None:
        """Validate query values before network serialization."""
        if not 1 <= self.limit <= 100:
            raise ValueError("History limit must be between 1 and 100.")
        for name in ("offset_id", "offset_date", "add_offset", "max_id", "min_id"):
            value = getattr(self, name)
            if not -(2**31) <= value <= 2**31 - 1:
                raise ValueError(f"{name} must fit in int32.")


@dataclass(slots=True, frozen=True)
class HistoryPage:
    """One normalized ``messages.getHistory`` response."""

    peer: Peer
    messages: tuple[Message, ...]
    total_count: int | None = None
    pts: int | None = None
    inexact: bool = False
    offset_id_offset: int | None = None
    response_type: str = "messages.Messages"
    parse_errors: tuple[str, ...] = field(default_factory=tuple)

    @property
    def next_offset_id(self) -> int | None:
        """Return the oldest positive message id for the next backfill page."""
        ids = [message.id for message in self.messages if message.id > 0]
        return min(ids) if ids else None

    def safe_summary(self) -> dict[str, object]:
        """Return page counts without message content."""
        return {
            "peer": self.peer.safe_summary(),
            "message_count": len(self.messages),
            "total_count": self.total_count,
            "pts": self.pts,
            "inexact": self.inexact,
            "offset_id_offset": self.offset_id_offset,
            "response_type": self.response_type,
            "parse_error_count": len(self.parse_errors),
            "next_offset_id": self.next_offset_id,
        }


@dataclass(slots=True, frozen=True)
class ReadHistoryResult:
    """Result of marking a conversation read on the Eitaa server."""

    peer: Peer
    max_id: int
    accepted: bool
    response_type: str
    pts: int | None = None
    pts_count: int | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "peer": self.peer.safe_summary(),
            "max_id": self.max_id,
            "accepted": self.accepted,
            "response_type": self.response_type,
            "pts": self.pts,
            "pts_count": self.pts_count,
        }


@dataclass(slots=True, frozen=True)
class MessageWriteStats:
    """Outcome of writing a page into a local message repository."""

    inserted: int = 0
    updated: int = 0
    unchanged: int = 0

    @property
    def processed(self) -> int:
        return self.inserted + self.updated + self.unchanged

    def safe_summary(self) -> dict[str, int]:
        return {
            "inserted": self.inserted,
            "updated": self.updated,
            "unchanged": self.unchanged,
            "processed": self.processed,
        }


@dataclass(slots=True, frozen=True)
class SyncResult:
    """Result of one or more history pages persisted locally."""

    peer: Peer
    pages: int
    fetched: int
    stored: MessageWriteStats
    next_offset_id: int | None
    stopped_reason: str

    def safe_summary(self) -> dict[str, object]:
        return {
            "peer": self.peer.safe_summary(),
            "pages": self.pages,
            "fetched": self.fetched,
            "stored": self.stored.safe_summary(),
            "next_offset_id": self.next_offset_id,
            "stopped_reason": self.stopped_reason,
        }

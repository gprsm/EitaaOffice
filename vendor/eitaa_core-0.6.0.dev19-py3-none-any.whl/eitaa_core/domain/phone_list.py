"""Persistent phone-recipient list domain models for Core 7.3."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .enums import ContactResolutionSource, PhoneCleanupStatus, PhoneEntryStatus, PhoneListStatus
from .peer import Peer
from .phone import PhoneNumber
from .user import User


@dataclass(slots=True, frozen=True)
class PhoneListInputRow:
    """One parsed source row before persistence."""

    row_number: int
    phone: PhoneNumber | None
    first_name: str = "Eitaa"
    last_name: str = ""
    status: PhoneEntryStatus = PhoneEntryStatus.PENDING
    error_code: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "row_number": self.row_number,
            "phone": self.phone.masked if self.phone else None,
            "first_name_present": bool(self.first_name),
            "last_name_present": bool(self.last_name),
            "status": self.status.value,
            "error_code": self.error_code,
        }


@dataclass(slots=True, frozen=True)
class PhoneListInspection:
    """Offline parsing result shown before a list is persisted."""

    source_file: Path
    total_rows: int
    valid_unique: int
    duplicates: int
    invalid: int
    rows: tuple[PhoneListInputRow, ...]

    def safe_summary(self) -> dict[str, object]:
        return {
            "source_file": self.source_file.name,
            "total_rows": self.total_rows,
            "valid_unique": self.valid_unique,
            "duplicates": self.duplicates,
            "invalid": self.invalid,
            "sample": [row.safe_summary() for row in self.rows[:10]],
        }


@dataclass(slots=True, frozen=True)
class PhoneRecipientList:
    """Persistent metadata for one imported phone list."""

    id: str
    name: str
    virtual_community: Peer
    status: PhoneListStatus
    source_name: str
    total_rows: int
    valid_unique: int
    duplicate_count: int
    invalid_count: int
    pending_count: int
    resolved_count: int
    not_found_count: int
    failed_count: int
    stop_reason: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    resolved_at: datetime | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "id": self.id,
            "name": self.name,
            "virtual_community": self.virtual_community.safe_summary(),
            "status": self.status.value,
            "source_name": self.source_name,
            "total_rows": self.total_rows,
            "valid_unique": self.valid_unique,
            "duplicate_count": self.duplicate_count,
            "invalid_count": self.invalid_count,
            "pending_count": self.pending_count,
            "resolved_count": self.resolved_count,
            "not_found_count": self.not_found_count,
            "failed_count": self.failed_count,
            "stop_reason": self.stop_reason,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }


@dataclass(slots=True, frozen=True)
class PhoneListEntry:
    """Persistent resolution state for one source row."""

    id: int
    list_id: str
    row_number: int
    phone: PhoneNumber | None
    first_name: str
    last_name: str
    status: PhoneEntryStatus
    attempts: int = 0
    user: User | None = None
    error_code: str | None = None
    error_type: str | None = None
    contact_source: ContactResolutionSource | None = None
    contact_added_by_list: bool = False
    cleanup_status: PhoneCleanupStatus = PhoneCleanupStatus.NOT_REQUIRED
    cleanup_attempts: int = 0
    cleanup_error_code: str | None = None
    cleanup_error_type: str | None = None
    cleanup_response_type: str | None = None
    cleanup_updated_at: datetime | None = None
    removed_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    resolved_at: datetime | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "id": self.id,
            "list_id": self.list_id,
            "row_number": self.row_number,
            "phone": self.phone.masked if self.phone else None,
            "first_name_present": bool(self.first_name),
            "last_name_present": bool(self.last_name),
            "status": self.status.value,
            "attempts": self.attempts,
            "user": self.user.safe_summary() if self.user else None,
            "error_code": self.error_code,
            "error_type": self.error_type,
            "contact_source": self.contact_source.value if self.contact_source else None,
            "contact_added_by_list": self.contact_added_by_list,
            "cleanup_status": self.cleanup_status.value,
            "cleanup_attempts": self.cleanup_attempts,
            "cleanup_error_code": self.cleanup_error_code,
            "cleanup_error_type": self.cleanup_error_type,
            "cleanup_response_type": self.cleanup_response_type,
            "cleanup_updated_at": self.cleanup_updated_at.isoformat() if self.cleanup_updated_at else None,
            "removed_at": self.removed_at.isoformat() if self.removed_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }


@dataclass(slots=True, frozen=True)
class PhoneListResolveOptions:
    """Bounded controls for phone-to-user resolution."""

    import_if_missing: bool = True
    delay_seconds: float = 1.0
    max_attempts: int = 2
    retry_delay_seconds: float = 3.0
    stop_on_server_error: bool = True

    def validate(self) -> None:
        from ..errors import DomainValidationError

        if self.delay_seconds < 0:
            raise DomainValidationError("Phone-list resolution delay cannot be negative.")
        if not 1 <= self.max_attempts <= 10:
            raise DomainValidationError("Phone-list max_attempts must be between 1 and 10.")
        if self.retry_delay_seconds < 0:
            raise DomainValidationError("Phone-list retry delay cannot be negative.")

    def safe_summary(self) -> dict[str, object]:
        return {
            "import_if_missing": self.import_if_missing,
            "delay_seconds": self.delay_seconds,
            "max_attempts": self.max_attempts,
            "retry_delay_seconds": self.retry_delay_seconds,
            "stop_on_server_error": self.stop_on_server_error,
        }


@dataclass(slots=True, frozen=True)
class PhoneListExportResult:
    path: Path
    format: str
    count: int

    def safe_summary(self) -> dict[str, object]:
        return {"path": str(self.path), "format": self.format, "count": self.count}


@dataclass(slots=True, frozen=True)
class PhoneCleanupOptions:
    """Bounded controls for removing contacts imported by one phone list."""

    delay_seconds: float = 1.0
    max_attempts: int = 2
    retry_delay_seconds: float = 3.0
    stop_on_server_error: bool = True
    include_legacy_unknown: bool = False

    def validate(self) -> None:
        from ..errors import DomainValidationError

        if self.delay_seconds < 0:
            raise DomainValidationError("Phone cleanup delay cannot be negative.")
        if not 1 <= self.max_attempts <= 10:
            raise DomainValidationError("Phone cleanup max_attempts must be between 1 and 10.")
        if self.retry_delay_seconds < 0:
            raise DomainValidationError("Phone cleanup retry delay cannot be negative.")

    def safe_summary(self) -> dict[str, object]:
        return {
            "delay_seconds": self.delay_seconds,
            "max_attempts": self.max_attempts,
            "retry_delay_seconds": self.retry_delay_seconds,
            "stop_on_server_error": self.stop_on_server_error,
            "include_legacy_unknown": self.include_legacy_unknown,
        }


@dataclass(slots=True, frozen=True)
class PhoneCleanupReport:
    """Persistent cleanup outcome without exposing full phone numbers."""

    list_id: str
    eligible: int
    removed: int
    failed: int
    skipped_existing: int
    skipped_legacy_unknown: int
    pending: int
    processing: int
    complete: bool
    stop_reason: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "list_id": self.list_id,
            "eligible": self.eligible,
            "removed": self.removed,
            "failed": self.failed,
            "skipped_existing": self.skipped_existing,
            "skipped_legacy_unknown": self.skipped_legacy_unknown,
            "pending": self.pending,
            "processing": self.processing,
            "complete": self.complete,
            "stop_reason": self.stop_reason,
        }

"""Domain models for outbound text, photo, and document operations.

The models in this module contain no HTTP, filesystem, CLI, or UI code.  They
form the stable contract consumed by future desktop, command-line, and HTTP
frontends.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from .enums import ContactResolutionSource, SendKind
from .peer import Peer
from ..errors import DomainValidationError


@dataclass(slots=True, frozen=True)
class UploadOptions:
    """Controls local-file upload behavior.

    Args:
        chunk_size: Requested part size in bytes.  A value of ``0`` selects the
            web-compatible size automatically from the file length.
        max_bytes: Local safety cap.  ``None`` disables the cap.
        request_delay_seconds: Delay between successful parts.
        part_max_attempts: Bounded attempts for one failed upload part.
        retry_delay_seconds: Delay between retry attempts for a part.
    """

    chunk_size: int = 0
    max_bytes: int | None = 100 * 1024 * 1024
    request_delay_seconds: float = 0.35
    part_max_attempts: int = 3
    retry_delay_seconds: float = 1.0

    def validate(self) -> None:
        """Validate bounds before opening the local file."""
        if self.chunk_size < 0:
            raise DomainValidationError("Upload chunk_size cannot be negative.")
        if self.chunk_size:
            if not 4 * 1024 <= self.chunk_size <= 512 * 1024:
                raise DomainValidationError(
                    "Upload chunk_size must be between 4 KiB and 512 KiB.",
                    safe_context={"chunk_size": self.chunk_size},
                )
            if self.chunk_size % 1024:
                raise DomainValidationError(
                    "Upload chunk_size must be a multiple of 1024 bytes.",
                    safe_context={"chunk_size": self.chunk_size},
                )
        if self.max_bytes is not None and self.max_bytes <= 0:
            raise DomainValidationError("Upload max_bytes must be positive or None.")
        if self.request_delay_seconds < 0 or self.retry_delay_seconds < 0:
            raise DomainValidationError("Upload delays cannot be negative.")
        if self.part_max_attempts < 1:
            raise DomainValidationError("part_max_attempts must be at least one.")

    def safe_summary(self) -> dict[str, object]:
        """Return diagnostics-safe option metadata."""
        return {
            "chunk_size": self.chunk_size,
            "max_bytes": self.max_bytes,
            "request_delay_seconds": self.request_delay_seconds,
            "part_max_attempts": self.part_max_attempts,
            "retry_delay_seconds": self.retry_delay_seconds,
        }


@dataclass(slots=True, frozen=True)
class UploadProgress:
    """A UI-neutral upload progress event.

    Frontends may display this event as a progress bar, console line, or HTTP
    stream.  The core never prints progress itself.
    """

    phase: str
    bytes_sent: int
    total_bytes: int
    parts_sent: int
    total_parts: int
    current_part: int | None = None
    attempt: int | None = None

    @property
    def fraction(self) -> float:
        """Return completion in the inclusive range 0.0 to 1.0."""
        if self.total_bytes <= 0:
            return 0.0
        return min(1.0, max(0.0, self.bytes_sent / self.total_bytes))

    def safe_summary(self) -> dict[str, object]:
        return {
            "phase": self.phase,
            "bytes_sent": self.bytes_sent,
            "total_bytes": self.total_bytes,
            "parts_sent": self.parts_sent,
            "total_parts": self.total_parts,
            "current_part": self.current_part,
            "attempt": self.attempt,
            "fraction": round(self.fraction, 6),
        }


UploadProgressCallback = Callable[[UploadProgress], None]


@dataclass(slots=True, frozen=True)
class UploadedFile:
    """Server-side file handle produced by chunked upload.

    ``file_id`` is an ephemeral upload identifier and is intentionally omitted
    from :meth:`safe_summary`.
    """

    file_id: int
    parts: int
    size: int
    big: bool
    remote_name: str
    chunk_size: int
    md5_checksum: str = ""

    def validate(self) -> None:
        if not -(2**63) <= self.file_id <= 2**63 - 1:
            raise DomainValidationError("Uploaded file_id must fit signed int64.")
        if self.parts < 1 or self.size < 1 or self.chunk_size < 1:
            raise DomainValidationError("Uploaded file metadata is incomplete.")
        if not self.remote_name:
            raise DomainValidationError("Uploaded remote_name cannot be empty.")

    def safe_summary(self) -> dict[str, object]:
        """Return metadata without file id, checksum, or file name."""
        return {
            "parts": self.parts,
            "size": self.size,
            "big": self.big,
            "chunk_size": self.chunk_size,
            "remote_name_present": bool(self.remote_name),
        }


@dataclass(slots=True, frozen=True)
class SendResult:
    """Normalized result of an outbound Eitaa operation."""

    kind: SendKind
    peer: Peer
    accepted: bool
    response_constructor: str
    response_type: str
    message_id: int | None = None
    pts: int | None = None
    pts_count: int | None = None
    server_date: datetime | None = None
    uploaded: UploadedFile | None = None
    resolution_source: ContactResolutionSource | None = None
    contact_added: bool = False

    def safe_summary(self) -> dict[str, object]:
        """Return a report suitable for logs and frontends."""
        return {
            "kind": self.kind.value,
            "peer": self.peer.safe_summary(),
            "accepted": self.accepted,
            "response_constructor": self.response_constructor,
            "response_type": self.response_type,
            "message_id": self.message_id,
            "pts": self.pts,
            "pts_count": self.pts_count,
            "server_date": self.server_date.isoformat() if self.server_date else None,
            "uploaded": self.uploaded.safe_summary() if self.uploaded else None,
            "resolution_source": self.resolution_source.value if self.resolution_source else None,
            "contact_added": self.contact_added,
        }

    @classmethod
    def from_server_timestamp(
        cls,
        *,
        kind: SendKind,
        peer: Peer,
        accepted: bool,
        response_constructor: str,
        response_type: str,
        message_id: int | None = None,
        pts: int | None = None,
        pts_count: int | None = None,
        server_timestamp: int | None = None,
        uploaded: UploadedFile | None = None,
    ) -> "SendResult":
        date = (
            datetime.fromtimestamp(server_timestamp, timezone.utc)
            if server_timestamp is not None
            else None
        )
        return cls(
            kind=kind,
            peer=peer,
            accepted=accepted,
            response_constructor=response_constructor,
            response_type=response_type,
            message_id=message_id,
            pts=pts,
            pts_count=pts_count,
            server_date=date,
            uploaded=uploaded,
        )


def validate_local_upload(path: Path, options: UploadOptions) -> tuple[Path, int]:
    """Validate a local upload target and return its resolved path and size."""
    options.validate()
    resolved = Path(path).expanduser().resolve()
    if not resolved.is_file():
        raise DomainValidationError(
            "Upload file does not exist or is not a regular file.",
            safe_context={"path_present": resolved.exists()},
        )
    size = resolved.stat().st_size
    if size <= 0:
        raise DomainValidationError("Upload file is empty.")
    if options.max_bytes is not None and size > options.max_bytes:
        raise DomainValidationError(
            "Upload file exceeds the configured local safety limit.",
            safe_context={"size": size, "max_bytes": options.max_bytes},
        )
    return resolved, size


@dataclass(slots=True, frozen=True)
class MessageDeleteResult:
    """Normalized result of one ``messages.deleteMessages`` request."""

    accepted: bool
    response_constructor: str
    response_type: str
    message_count: int
    revoke: bool
    pts: int | None = None
    pts_count: int | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "accepted": self.accepted,
            "response_constructor": self.response_constructor,
            "response_type": self.response_type,
            "message_count": self.message_count,
            "revoke": self.revoke,
            "pts": self.pts,
            "pts_count": self.pts_count,
        }

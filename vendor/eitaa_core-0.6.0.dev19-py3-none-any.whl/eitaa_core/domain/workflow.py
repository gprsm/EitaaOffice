"""Retrieval cursors, local search, and external-publication domain models.

The objects in this module contain no SQLite statements, network calls, CLI
formatting, or WordPress-specific implementation code.  They are stable
contracts that a CLI, desktop UI, FastAPI middleware, or future WordPress
adapter can consume.
"""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Iterable

from .enums import MediaType, PeerType, PublicationStatus
from .message import HistoryPage, Message, MessageWriteStats
from .peer import Peer


def _ensure_aware(value: datetime | None, field_name: str) -> None:
    if value is not None and value.tzinfo is None:
        raise ValueError(f"{field_name} must be timezone-aware.")


@dataclass(slots=True, frozen=True)
class HistoryCursor:
    """Persisted position for repeated newest-to-oldest history retrieval.

    A cursor is scoped by ``peer`` and an arbitrary ``key``.  Multiple
    frontends or workflows can therefore maintain independent positions for the
    same channel, for example ``ui-preview`` and ``wordpress-backfill``.
    """

    peer: Peer
    key: str
    next_offset_id: int = 0
    page_size: int = 10
    pages_fetched: int = 0
    messages_fetched: int = 0
    completed: bool = False
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def validate(self) -> None:
        self.peer.validate()
        if not self.key.strip():
            raise ValueError("Cursor key cannot be empty.")
        if len(self.key) > 128:
            raise ValueError("Cursor key cannot exceed 128 characters.")
        if not 1 <= self.page_size <= 100:
            raise ValueError("Cursor page_size must be between 1 and 100.")
        if self.next_offset_id < 0:
            raise ValueError("Cursor next_offset_id cannot be negative.")
        _ensure_aware(self.updated_at, "updated_at")

    def safe_summary(self) -> dict[str, object]:
        return {
            "peer": self.peer.safe_summary(),
            "key": self.key,
            "next_offset_id": self.next_offset_id,
            "page_size": self.page_size,
            "pages_fetched": self.pages_fetched,
            "messages_fetched": self.messages_fetched,
            "completed": self.completed,
            "updated_at": self.updated_at.isoformat(),
        }


@dataclass(slots=True, frozen=True)
class CursorFetchResult:
    """One remote page fetched through a persisted :class:`HistoryCursor`."""

    page: HistoryPage
    cursor: HistoryCursor
    stored: MessageWriteStats = field(default_factory=MessageWriteStats)

    def safe_summary(self) -> dict[str, object]:
        return {
            "page": self.page.safe_summary(),
            "cursor": self.cursor.safe_summary(),
            "stored": self.stored.safe_summary(),
        }


@dataclass(slots=True, frozen=True)
class MessageSearchQuery:
    """Filters for deterministic local SQLite message retrieval.

    ``sender`` filters by the normalized sender identity stored in
    ``Message.from_peer``.  Because this is a local SQLite lookup, only the
    sender's ``Peer.type`` and ``Peer.id`` are used; an access hash is not
    required.

    ``cursor`` is an opaque keyset cursor returned by a previous
    :class:`MessageSearchPage`.  It is preferable to numeric offsets because
    newly inserted messages do not shift already-seen pages.  The same filters,
    including ``peer`` and ``sender``, must be supplied with each next cursor.
    """

    peer: Peer | None = None
    sender: Peer | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None
    before_id: int | None = None
    after_id: int | None = None
    media_types: tuple[MediaType, ...] = ()
    publication_status: PublicationStatus | None = None
    unpublished: bool = False
    target_type: str | None = None
    target_key: str | None = None
    text: str | None = None
    limit: int = 100
    cursor: str | None = None

    def validate(self) -> None:
        if self.peer:
            self.peer.validate()
        if self.sender is not None:
            # Sender filtering is a local identity lookup.  Unlike a remote TL
            # input peer, it deliberately requires only peer type + id and not
            # an access_hash.
            if not isinstance(self.sender, Peer):
                raise ValueError("sender must be a Peer.")
            if not isinstance(self.sender.type, PeerType):
                raise ValueError("sender.type must be a PeerType.")
            if not isinstance(self.sender.id, int):
                raise ValueError("sender.id must be an integer.")
            if self.sender.id <= 0:
                raise ValueError("sender.id must be positive.")
        _ensure_aware(self.date_from, "date_from")
        _ensure_aware(self.date_to, "date_to")
        if self.date_from and self.date_to and self.date_from > self.date_to:
            raise ValueError("date_from cannot be after date_to.")
        if self.before_id is not None and self.before_id <= 0:
            raise ValueError("before_id must be positive.")
        if self.after_id is not None and self.after_id <= 0:
            raise ValueError("after_id must be positive.")
        if self.before_id is not None and self.after_id is not None:
            raise ValueError("before_id and after_id cannot be used together.")
        if self.unpublished and self.publication_status is not None:
            raise ValueError("unpublished and publication_status cannot be used together.")
        if not 1 <= self.limit <= 10_000:
            raise ValueError("Search limit must be between 1 and 10000.")
        for name, value in (("target_type", self.target_type), ("target_key", self.target_key)):
            if value is not None and not value.strip():
                raise ValueError(f"{name} cannot be blank.")
        if self.cursor:
            decode_search_cursor(self.cursor)


@dataclass(slots=True, frozen=True)
class MessageSearchPage:
    """One keyset-paginated page of locally stored messages."""

    messages: tuple[Message, ...]
    next_cursor: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "message_count": len(self.messages),
            "next_cursor_present": self.next_cursor is not None,
        }


@dataclass(slots=True, frozen=True)
class PublicationRecord:
    """State of publishing one Eitaa message to one external destination.

    ``target_type`` is intentionally generic, although ``wordpress`` is the
    first planned adapter.  ``target_key`` distinguishes sites or destinations,
    such as ``medical-site`` and ``news-site``.
    """

    peer: Peer
    message_id: int
    target_type: str
    target_key: str
    status: PublicationStatus
    external_post_id: str | None = None
    external_url: str | None = None
    published_content_hash: str | None = None
    attempts: int = 0
    last_attempt_at: datetime | None = None
    published_at: datetime | None = None
    error_code: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    current_content_hash: str | None = None

    @property
    def stale(self) -> bool:
        """Return whether current local content differs from published content."""
        return bool(
            self.published_content_hash
            and self.current_content_hash
            and self.published_content_hash != self.current_content_hash
        )

    def validate(self) -> None:
        self.peer.validate()
        if self.message_id <= 0:
            raise ValueError("message_id must be positive.")
        if not self.target_type.strip() or len(self.target_type) > 64:
            raise ValueError("target_type must contain 1 to 64 characters.")
        if not self.target_key.strip() or len(self.target_key) > 128:
            raise ValueError("target_key must contain 1 to 128 characters.")
        if self.attempts < 0:
            raise ValueError("attempts cannot be negative.")
        for name, value in (
            ("last_attempt_at", self.last_attempt_at),
            ("published_at", self.published_at),
            ("created_at", self.created_at),
            ("updated_at", self.updated_at),
        ):
            _ensure_aware(value, name)

    def safe_summary(self) -> dict[str, object]:
        return {
            "peer": self.peer.safe_summary(),
            "message_id": self.message_id,
            "target_type": self.target_type,
            "target_key": self.target_key,
            "status": self.status.value,
            "external_post_id_present": self.external_post_id is not None,
            "external_url_present": self.external_url is not None,
            "published_content_hash_present": self.published_content_hash is not None,
            "attempts": self.attempts,
            "last_attempt_at": self.last_attempt_at.isoformat() if self.last_attempt_at else None,
            "published_at": self.published_at.isoformat() if self.published_at else None,
            "error_code": self.error_code,
            "stale": self.stale,
        }


@dataclass(slots=True, frozen=True)
class DateRangeSyncResult:
    """Outcome of retrieving and optionally storing a server date range."""

    peer: Peer
    date_from: datetime
    date_to: datetime
    pages: int
    fetched: int
    matched: int
    stored: MessageWriteStats
    next_offset_id: int | None
    stopped_reason: str

    def safe_summary(self) -> dict[str, object]:
        return {
            "peer": self.peer.safe_summary(),
            "date_from": self.date_from.isoformat(),
            "date_to": self.date_to.isoformat(),
            "pages": self.pages,
            "fetched": self.fetched,
            "matched": self.matched,
            "stored": self.stored.safe_summary(),
            "next_offset_id": self.next_offset_id,
            "stopped_reason": self.stopped_reason,
        }


def encode_search_cursor(
    *, date_utc: str, peer_type: str, peer_id: int, message_id: int
) -> str:
    """Encode a local keyset position as an opaque URL-safe string."""
    raw = json.dumps(
        {
            "v": 1,
            "d": date_utc,
            "t": peer_type,
            "p": peer_id,
            "m": message_id,
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def decode_search_cursor(value: str) -> tuple[str, str, int, int]:
    """Decode and validate an opaque local-search cursor."""
    try:
        padding = "=" * (-len(value) % 4)
        data = json.loads(base64.urlsafe_b64decode(value + padding).decode("utf-8"))
        if data.get("v") != 1:
            raise ValueError("Unsupported cursor version.")
        date_utc = str(data["d"])
        peer_type = str(data["t"])
        peer_id = int(data["p"])
        message_id = int(data["m"])
        datetime.fromisoformat(date_utc)
        if peer_id <= 0 or message_id <= 0:
            raise ValueError("Cursor ids must be positive.")
        return date_utc, peer_type, peer_id, message_id
    except Exception as exc:
        raise ValueError("Invalid message search cursor.") from exc


def normalize_media_types(values: Iterable[str]) -> tuple[MediaType, ...]:
    """Convert user-facing media type strings to stable enum values."""
    return tuple(MediaType(value.strip()) for value in values if value.strip())

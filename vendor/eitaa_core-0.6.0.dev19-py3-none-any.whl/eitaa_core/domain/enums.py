"""Stable enumerations shared by domain models and service adapters."""

from enum import StrEnum


class EndpointRole(StrEnum):
    """Logical endpoint role used by the endpoint router."""

    API = "api"
    AUTH = "auth"
    MEDIA = "media"
    DOWNLOAD = "download"


class PeerType(StrEnum):
    """Supported Eitaa peer categories."""

    USER = "user"
    CHAT = "chat"
    CHANNEL = "channel"


class DialogKind(StrEnum):
    """UI-facing dialog category independent of the TL constructor name."""

    PRIVATE = "private"
    BASIC_GROUP = "basic_group"
    SUPERGROUP = "supergroup"
    CHANNEL = "channel"
    UNKNOWN = "unknown"


class MediaDownloadMethod(StrEnum):
    """Wire methods supported by the Eitaa media downloader."""

    AUTO = "auto"
    GET_FILE = "getFile"
    GET_FILE2 = "getFile2"


class MediaType(StrEnum):
    """Normalized media categories used by the local client."""

    PHOTO = "photo"
    IMAGE_DOCUMENT = "image_document"
    VIDEO = "video"
    AUDIO = "audio"
    STICKER = "sticker"
    DOCUMENT = "document"
    NONE = "no_media"
    UNKNOWN = "unknown"


class UserStatusKind(StrEnum):
    """Privacy-aware normalized user status values."""

    ONLINE = "online"
    OFFLINE = "offline"
    RECENTLY = "recently"
    LAST_WEEK = "last_week"
    LAST_MONTH = "last_month"
    UNKNOWN_OR_HIDDEN = "unknown_or_hidden"


class ContactResolutionSource(StrEnum):
    """How a phone number was resolved to an Eitaa contact."""

    EXISTING = "existing_contact"
    IMPORTED = "imported_contact"


class PublicationStatus(StrEnum):
    """Lifecycle state of an external publication derived from a message."""

    PENDING = "pending"
    PROCESSING = "processing"
    PUBLISHED = "published"
    FAILED = "failed"
    SKIPPED = "skipped"
    NEEDS_UPDATE = "needs_update"


class ExportFormat(StrEnum):
    """Portable formats supported by local message export."""

    JSONL = "jsonl"
    JSON = "json"
    CSV = "csv"


class SendKind(StrEnum):
    """Outbound operation categories exposed by the core."""

    TEXT = "text"
    PHOTO = "photo"
    FILE = "file"


class MemberRole(StrEnum):
    """Normalized role of a user inside a group or channel."""

    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"
    SELF = "self"
    BANNED = "banned"
    LEFT = "left"
    UNKNOWN = "unknown"


class MemberState(StrEnum):
    """Current membership state stored by the local community index."""

    ACTIVE = "active"
    LEFT = "left"
    BANNED = "banned"
    KICKED = "kicked"


class MemberRemoteFilter(StrEnum):
    """Remote participant filters supported by Eitaa channels.getParticipants."""

    RECENT = "recent"
    ADMINS = "admins"
    BOTS = "bots"
    BANNED = "banned"
    KICKED = "kicked"
    SEARCH = "search"
    CONTACTS = "contacts"


class PhoneListStatus(StrEnum):
    """Persistent lifecycle of a phone-recipient list."""

    DRAFT = "draft"
    RESOLVING = "resolving"
    READY = "ready"
    PARTIAL = "partial"
    BLOCKED = "blocked"
    FAILED = "failed"
    CANCELLED = "cancelled"


class PhoneEntryStatus(StrEnum):
    """Resolution state for one imported phone-list row."""

    PENDING = "pending"
    PROCESSING = "processing"
    RESOLVED = "resolved"
    NOT_FOUND = "not_found"
    INVALID = "invalid"
    DUPLICATE = "duplicate"
    FAILED = "failed"


class PhoneCleanupStatus(StrEnum):
    """Cleanup state for contacts associated with one phone-list entry."""

    NOT_REQUIRED = "not_required"
    ELIGIBLE = "eligible"
    PROCESSING = "processing"
    REMOVED = "removed"
    FAILED = "failed"
    SKIPPED = "skipped"


class BulkDeleteStatus(StrEnum):
    """Persistent deletion state for one sent bulk-message recipient."""

    NOT_REQUESTED = "not_requested"
    PENDING = "pending"
    PROCESSING = "processing"
    DELETED = "deleted"
    FAILED = "failed"
    SKIPPED_MISSING_ID = "skipped_missing_id"


class BulkJobStatus(StrEnum):
    """Persistent lifecycle of a bulk-send job."""

    DRAFT = "draft"
    QUEUED = "queued"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    BLOCKED = "blocked"
    FAILED = "failed"


class BulkRecipientStatus(StrEnum):
    """Persistent per-recipient delivery state."""

    PENDING = "pending"
    PROCESSING = "processing"
    SENT = "sent"
    FAILED = "failed"
    SKIPPED = "skipped"


class MembershipJobStatus(StrEnum):
    """Persistent lifecycle of a reversible bulk membership job."""

    DRAFT = "draft"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    BLOCKED = "blocked"
    FAILED = "failed"


class MembershipAddStatus(StrEnum):
    """Per-user result of adding a resolved phone-list user to a community."""

    PENDING = "pending"
    PROCESSING = "processing"
    ADDED = "added"
    ALREADY_MEMBER = "already_member"
    FAILED = "failed"
    SKIPPED = "skipped"


class MembershipRollbackStatus(StrEnum):
    """Per-user rollback state for members added by one job."""

    NOT_REQUIRED = "not_required"
    ELIGIBLE = "eligible"
    PROCESSING = "processing"
    REMOVED = "removed"
    REMOVED_BUT_RESTRICTED = "removed_but_restricted"
    FAILED = "failed"
    SKIPPED = "skipped"

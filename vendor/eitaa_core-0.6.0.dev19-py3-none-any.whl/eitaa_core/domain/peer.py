"""Peer domain model."""

from __future__ import annotations

from dataclasses import dataclass

from .enums import PeerType
from ..errors import DomainValidationError


@dataclass(slots=True, frozen=True)
class Peer:
    """Normalized Eitaa peer identifier.

    ``access_hash`` is required for users and channels but not for basic chats.
    It is deliberately omitted from ``repr``.
    """

    id: int
    type: PeerType
    access_hash: int | None = None
    username: str | None = None
    title: str | None = None

    def __repr__(self) -> str:
        return (
            f"Peer(id={self.id!r}, type={self.type.value!r}, "
            f"access_hash_present={self.access_hash is not None}, "
            f"username={self.username!r}, title={self.title!r})"
        )

    def validate(self) -> None:
        """Validate invariants required to build TL input peers."""
        if not isinstance(self.id, int):
            raise DomainValidationError("Peer id must be an integer.")
        if self.type in {PeerType.USER, PeerType.CHANNEL} and self.access_hash is None:
            raise DomainValidationError(
                "User and channel peers require an access_hash.",
                safe_context={"peer_type": self.type.value, "peer_id": self.id},
            )

    def safe_summary(self) -> dict[str, object]:
        """Return a summary safe for diagnostics."""
        return {
            "id": self.id,
            "type": self.type.value,
            "access_hash_present": self.access_hash is not None,
            "username_present": bool(self.username),
            "title_present": bool(self.title),
        }

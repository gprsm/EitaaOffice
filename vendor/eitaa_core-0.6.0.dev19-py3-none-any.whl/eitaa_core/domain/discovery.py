"""Dialog and peer-discovery domain models."""

from __future__ import annotations

from dataclasses import dataclass

from .enums import DialogKind
from .peer import Peer


@dataclass(slots=True, frozen=True)
class PhotoLocationReference:
    """Legacy file location preserved for diagnostics and fallbacks."""

    constructor: int
    dc_id: int | None = None
    volume_id: int | None = None
    local_id: int | None = None
    secret: int | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "constructor": f"0x{self.constructor & 0xFFFFFFFF:08x}",
            "dc_id": self.dc_id,
            "volume_id_present": self.volume_id is not None,
            "local_id": self.local_id,
            "secret_present": self.secret is not None,
        }


@dataclass(slots=True, frozen=True)
class PeerPhotoReference:
    """Downloadable current profile photo for a user, group, or channel."""

    peer: Peer
    photo_id: int
    dc_id: int | None = None
    small: PhotoLocationReference | None = None
    big: PhotoLocationReference | None = None
    has_video: bool = False

    def safe_summary(self) -> dict[str, object]:
        return {
            "peer": self.peer.safe_summary(),
            "photo_id": self.photo_id,
            "dc_id": self.dc_id,
            "small_location_present": self.small is not None,
            "big_location_present": self.big is not None,
            "has_video": self.has_video,
        }


@dataclass(slots=True, frozen=True)
class DialogCursor:
    """Server keyset cursor for the next ``messages.getDialogs`` page."""

    offset_date: int
    offset_id: int
    offset_peer: Peer

    def key(self) -> tuple[int, int, str, int]:
        return (self.offset_date, self.offset_id, self.offset_peer.type.value, self.offset_peer.id)


@dataclass(slots=True, frozen=True)
class DialogEntry:
    """One dialog row returned by ``messages.getDialogs``."""

    peer: Peer
    top_message_id: int
    unread_count: int = 0
    unread_mentions_count: int = 0
    read_inbox_max_id: int = 0
    read_outbox_max_id: int = 0
    pinned: bool = False
    unread_mark: bool = False
    folder_id: int | None = None
    top_message_date: int | None = None
    kind: DialogKind = DialogKind.UNKNOWN
    broadcast: bool = False
    megagroup: bool = False
    participants_count: int | None = None
    photo: PeerPhotoReference | None = None
    photo_cached_path: str | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "peer": self.peer.safe_summary(),
            "top_message_id": self.top_message_id,
            "unread_count": self.unread_count,
            "unread_mentions_count": self.unread_mentions_count,
            "read_inbox_max_id": self.read_inbox_max_id,
            "read_outbox_max_id": self.read_outbox_max_id,
            "pinned": self.pinned,
            "unread_mark": self.unread_mark,
            "folder_id": self.folder_id,
            "top_message_date": self.top_message_date,
            "kind": self.kind.value,
            "broadcast": self.broadcast,
            "megagroup": self.megagroup,
            "participants_count": self.participants_count,
            "photo": self.photo.safe_summary() if self.photo else None,
            "photo_cached_path": self.photo_cached_path,
        }


@dataclass(slots=True, frozen=True)
class DialogPage:
    """Normalized page of dialogs."""

    dialogs: tuple[DialogEntry, ...]
    total_count: int | None = None
    response_type: str = "messages.dialogs"
    parse_warnings: tuple[str, ...] = ()
    next_cursor: DialogCursor | None = None

    def safe_summary(self) -> dict[str, object]:
        return {
            "dialog_count": len(self.dialogs),
            "total_count": self.total_count,
            "response_type": self.response_type,
            "parse_warning_count": len(self.parse_warnings),
            "next_cursor_present": self.next_cursor is not None,
        }


@dataclass(slots=True, frozen=True)
class DialogCollection:
    """Complete or bounded multi-page dialog synchronization result."""

    dialogs: tuple[DialogEntry, ...]
    total_count: int | None
    pages_fetched: int
    duplicate_count: int = 0
    complete: bool = False
    parse_warnings: tuple[str, ...] = ()
    stored_count: int = 0

    def safe_summary(self) -> dict[str, object]:
        counts = {kind.value: 0 for kind in DialogKind}
        for item in self.dialogs:
            counts[item.kind.value] += 1
        return {
            "dialog_count": len(self.dialogs),
            "total_count": self.total_count,
            "pages_fetched": self.pages_fetched,
            "duplicate_count": self.duplicate_count,
            "complete": self.complete,
            "parse_warning_count": len(self.parse_warnings),
            "stored_count": self.stored_count,
            "counts_by_kind": counts,
        }


@dataclass(slots=True, frozen=True)
class UsernameResolution:
    """Peer resolved from a public username."""

    username: str
    peer: Peer

    def safe_summary(self) -> dict[str, object]:
        return {"username": self.username, "peer": self.peer.safe_summary()}

"""TL request builders for history operations."""

from __future__ import annotations

from ...domain.enums import PeerType
from ...domain.message import HistoryQuery
from ...domain.peer import Peer
from ..codec.peer import PeerCodec
from ..codec.tl import TLWriter
from .constructors import CHANNELS_READ_HISTORY, INPUT_CHANNEL, MESSAGES_GET_HISTORY, MESSAGES_READ_HISTORY


class HistoryRequestCodec:
    """Serialize ``messages.getHistory`` from domain values."""

    @staticmethod
    def build_get_history(peer: Peer, query: HistoryQuery) -> bytes:
        """Build one validated ``messages.getHistory`` request."""
        query.validate()
        return (
            TLWriter()
            .write_i32(MESSAGES_GET_HISTORY)
            .write_raw(PeerCodec.encode_input_peer(peer))
            .write_i32(query.offset_id)
            .write_i32(query.offset_date)
            .write_i32(query.add_offset)
            .write_i32(query.limit)
            .write_i32(query.max_id)
            .write_i32(query.min_id)
            .write_i64(query.hash_value)
            .to_bytes()
        )

    @staticmethod
    def build_read_history(peer: Peer, max_id: int) -> bytes:
        """Build ``messages.readHistory`` or ``channels.readHistory``."""
        peer.validate()
        if not isinstance(max_id, int) or not 1 <= max_id <= 2**31 - 1:
            raise ValueError("max_id must be a positive int32.")
        writer = TLWriter()
        if peer.type is PeerType.CHANNEL:
            if peer.access_hash is None:
                raise ValueError("Channel access_hash is required to mark history read.")
            return (
                writer.write_i32(CHANNELS_READ_HISTORY)
                .write_i32(INPUT_CHANNEL)
                .write_i64(peer.id)
                .write_i64(peer.access_hash)
                .write_i32(max_id)
                .to_bytes()
            )
        return (
            writer.write_i32(MESSAGES_READ_HISTORY)
            .write_raw(PeerCodec.encode_input_peer(peer))
            .write_i32(max_id)
            .to_bytes()
        )


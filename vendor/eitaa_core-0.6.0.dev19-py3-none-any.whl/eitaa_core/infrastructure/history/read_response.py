"""Parsers for read-history responses."""

from __future__ import annotations

from ...domain.message import ReadHistoryResult
from ...domain.peer import Peer
from ...errors import HistoryParseError
from ..codec.constructors import BOOL_FALSE, BOOL_TRUE
from ..codec.tl import TLReader, hex_constructor
from .constructors import MESSAGES_AFFECTED_MESSAGES


class ReadHistoryResponseCodec:
    @staticmethod
    def parse(data: bytes, peer: Peer, max_id: int) -> ReadHistoryResult:
        reader = TLReader(data)
        constructor = reader.read_u32()
        if constructor == BOOL_TRUE:
            return ReadHistoryResult(peer, max_id, True, "boolTrue")
        if constructor == BOOL_FALSE:
            return ReadHistoryResult(peer, max_id, False, "boolFalse")
        if constructor == MESSAGES_AFFECTED_MESSAGES:
            pts = reader.read_i32()
            pts_count = reader.read_i32()
            return ReadHistoryResult(
                peer, max_id, True, "messages.affectedMessages", pts=pts, pts_count=pts_count
            )
        raise HistoryParseError(
            "Unsupported read-history response constructor.",
            safe_context={
                "constructor": hex_constructor(constructor),
                "response_length": len(data),
            },
        )

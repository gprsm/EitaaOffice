"""Conservative decoder for ``messages.getHistory`` responses.

Eitaa's message objects contain many optional nested structures. Core 5 parses
all fields needed by the local client and discovers each ordinary message by its
validated constructor offset. Unsupported optional media creates a warning for
that message instead of discarding the whole page.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from ...domain.enums import PeerType
from ...domain.message import HistoryPage, Message
from ...domain.peer import Peer
from ...errors import HistoryParseError, TLCodecError, UnexpectedConstructorError
from ..codec.tl import TLReader, hex_constructor
from . import constructors as c
from .media_codec import parse_message_media


@dataclass(slots=True, frozen=True)
class _HistoryHeader:
    response_type: str
    first_message_offset: int
    expected_message_count: int
    total_count: int | None = None
    pts: int | None = None
    inexact: bool = False
    offset_id_offset: int | None = None


def _read_peer(reader: TLReader) -> Peer:
    constructor = reader.read_u32()
    peer_type = {
        c.PEER_USER: PeerType.USER,
        c.PEER_CHAT: PeerType.CHAT,
        c.PEER_CHANNEL: PeerType.CHANNEL,
    }.get(constructor)
    if peer_type is None:
        raise UnexpectedConstructorError(
            "Unknown Peer constructor in message.",
            safe_context={"constructor": hex_constructor(constructor), "offset": reader.offset - 4},
        )
    return Peer(id=reader.read_i64(), type=peer_type)


def _skip_fwd_header(reader: TLReader) -> None:
    reader.expect_constructor(c.MESSAGE_FWD_HEADER)
    flags = reader.read_u32()
    if flags & 1: _read_peer(reader)
    if flags & (1 << 5): reader.read_string()
    reader.read_i32()
    if flags & (1 << 2): reader.read_i32()
    if flags & (1 << 3): reader.read_string()
    if flags & (1 << 4):
        _read_peer(reader); reader.read_i32()
    if flags & (1 << 6): reader.read_string()


def _parse_reply_header(reader: TLReader) -> int:
    reader.expect_constructor(c.MESSAGE_REPLY_HEADER)
    flags = reader.read_u32()
    reply_to_message_id = reader.read_i32()
    if flags & 1: _read_peer(reader)
    if flags & 2: reader.read_i32()
    return reply_to_message_id


def _read_vector_count(reader: TLReader, *, field: str) -> int:
    reader.expect_constructor(c.VECTOR)
    count = reader.read_i32()
    if count < 0 or count > 100_000:
        raise HistoryParseError(
            "Invalid TL vector count while reading message metadata.",
            safe_context={"field": field, "count": count, "offset": reader.offset},
        )
    return count


def _skip_message_entity(reader: TLReader) -> None:
    """Skip one layer-134 MessageEntity without retaining presentation markup."""
    constructor = reader.read_u32()
    offset_length_only = {
        0xBB92BA95,  # unknown
        0xFA04579D,  # mention
        0x6F635B0D,  # hashtag
        0x6CEF8AC7,  # bot command
        0x6ED02538,  # URL
        0x64E475C2,  # email
        0xBD610BC9,  # bold
        0x826F8B60,  # italic
        0x28A20571,  # code
        0x9B69E34B,  # phone
        0x4C4E743F,  # cashtag
        0x9C4E7E8B,  # underline
        0xBF0693D4,  # strike
        0x020DF5D0,  # blockquote
        0x761E6AF4,  # bank card
    }
    if constructor in offset_length_only:
        reader.read_i32()
        reader.read_i32()
        return
    if constructor in {0x73924BE0, 0x76A6D327}:  # pre(language), textUrl(url)
        reader.read_i32()
        reader.read_i32()
        reader.read_string()
        return
    if constructor == 0xDC7B1140:  # mentionName
        reader.read_i32()
        reader.read_i32()
        reader.read_i64()
        return
    raise UnexpectedConstructorError(
        "Unsupported MessageEntity while reading grouped media metadata.",
        safe_context={"constructor": hex_constructor(constructor), "offset": reader.offset - 4},
    )


def _skip_message_entities(reader: TLReader) -> None:
    for _ in range(_read_vector_count(reader, field="message_entities")):
        _skip_message_entity(reader)


def _skip_keyboard_button(reader: TLReader) -> None:
    """Skip the layer-134 keyboard button shapes used by Eitaa."""
    constructor = reader.read_u32()
    text_only = {
        0xA2FA4880,  # keyboardButton
        0xB16A6C29,  # requestPhone
        0xFC796B3F,  # requestGeoLocation
        0x50F41CCF,  # game
        0xAFD93FBB,  # buy
    }
    if constructor in text_only:
        reader.read_string()
        return
    if constructor == 0x258AFF05:  # url
        reader.read_string()
        reader.read_string()
        return
    if constructor == 0x35BBDB6B:  # callback
        reader.read_u32()
        reader.read_string()
        reader.read_bytes()
        return
    if constructor == 0x0568A748:  # switchInline
        reader.read_u32()
        reader.read_string()
        reader.read_string()
        return
    if constructor == 0x10B78D29:  # urlAuth
        flags = reader.read_u32()
        reader.read_string()
        if flags & 1:
            reader.read_string()
        reader.read_string()
        reader.read_i32()
        return
    if constructor == 0xBBC7515D:  # requestPoll
        flags = reader.read_u32()
        if flags & 1:
            reader.read_bool()
        reader.read_string()
        return
    if constructor == 0x308660C1:  # userProfile
        reader.read_string()
        reader.read_i64()
        return
    raise UnexpectedConstructorError(
        "Unsupported KeyboardButton while reading grouped media metadata.",
        safe_context={"constructor": hex_constructor(constructor), "offset": reader.offset - 4},
    )


def _skip_keyboard_rows(reader: TLReader) -> None:
    for _ in range(_read_vector_count(reader, field="keyboard_rows")):
        reader.expect_constructor(0x77608B83)
        for _ in range(_read_vector_count(reader, field="keyboard_buttons")):
            _skip_keyboard_button(reader)


def _skip_reply_markup(reader: TLReader) -> None:
    constructor = reader.read_u32()
    if constructor == 0xA03E5B85:  # replyKeyboardHide
        reader.read_u32()
        return
    if constructor == 0x86B40B08:  # replyKeyboardForceReply
        flags = reader.read_u32()
        if flags & (1 << 3):
            reader.read_string()
        return
    if constructor == 0x85DD99D1:  # replyKeyboardMarkup
        flags = reader.read_u32()
        _skip_keyboard_rows(reader)
        if flags & (1 << 3):
            reader.read_string()
        return
    if constructor == 0x48A30254:  # replyInlineMarkup
        _skip_keyboard_rows(reader)
        return
    raise UnexpectedConstructorError(
        "Unsupported ReplyMarkup while reading grouped media metadata.",
        safe_context={"constructor": hex_constructor(constructor), "offset": reader.offset - 4},
    )


def _skip_message_replies(reader: TLReader) -> None:
    reader.expect_constructor(0x83D60FC2)
    flags = reader.read_u32()
    reader.read_i32()
    reader.read_i32()
    if flags & (1 << 1):
        for _ in range(_read_vector_count(reader, field="recent_repliers")):
            _read_peer(reader)
    if flags & 1:
        reader.read_i64()
    if flags & (1 << 2):
        reader.read_i32()
    if flags & (1 << 3):
        reader.read_i32()


def _parse_grouped_id(reader: TLReader, flags: int) -> int | None:
    """Advance through layer-134 optional fields and return ``grouped_id``."""
    if flags & (1 << 6):
        _skip_reply_markup(reader)
    if flags & (1 << 7):
        _skip_message_entities(reader)
    if flags & (1 << 10):
        reader.read_i32()  # views
        reader.read_i32()  # forwards
    if flags & (1 << 23):
        _skip_message_replies(reader)
    if flags & (1 << 15):
        reader.read_i32()
    if flags & (1 << 16):
        reader.read_string()
    return reader.read_i64() if flags & (1 << 17) else None


def _parse_message_at(data: bytes, offset: int, requested_peer: Peer) -> Message:
    reader = TLReader(data, offset)
    reader.expect_constructor(c.MESSAGE)
    flags = reader.read_u32()
    message_id = reader.read_i32()
    from_peer = _read_peer(reader) if flags & (1 << 8) else None
    parsed_peer = _read_peer(reader)
    if flags & (1 << 2): _skip_fwd_header(reader)
    if flags & (1 << 11): reader.read_i64()
    reply_to_message_id = _parse_reply_header(reader) if flags & (1 << 3) else None
    date_raw = reader.read_i32()
    text = reader.read_string()
    media = None
    warning = None
    media_metadata_aligned = True
    if flags & (1 << 9):
        try:
            media = parse_message_media(reader)
        except Exception as exc:  # page-level resilience is intentional here
            warning = f"media:{type(exc).__name__}"
            media_metadata_aligned = False
    grouped_id = None
    if media_metadata_aligned and flags & (1 << 17):
        try:
            grouped_id = _parse_grouped_id(reader, flags)
        except Exception as exc:
            warning = ";".join(
                item for item in (warning, f"grouped_id:{type(exc).__name__}") if item
            )
    peer = requested_peer if (
        parsed_peer.id == requested_peer.id and parsed_peer.type is requested_peer.type
    ) else parsed_peer
    try:
        date = datetime.fromtimestamp(date_raw, tz=timezone.utc)
    except (OverflowError, OSError, ValueError) as exc:
        raise HistoryParseError(
            "Message date is outside the supported timestamp range.",
            safe_context={"message_id": message_id, "date_raw": date_raw},
        ) from exc
    return Message(
        id=message_id,
        peer=peer,
        date=date,
        text=text,
        media=media,
        outgoing=bool(flags & (1 << 1)),
        from_peer=from_peer,
        reply_to_message_id=reply_to_message_id,
        grouped_id=grouped_id,
        flags=flags,
        parse_warning=warning,
    )



def _parse_service_message_at(data: bytes, offset: int, requested_peer: Peer) -> Message:
    """Parse the common prefix of ``messageService``.

    Service action payloads vary widely. Core 5 records the action constructor as
    a warning and intentionally does not decode the action body. Independent
    constructor discovery means no offset alignment is required afterwards.
    """
    reader = TLReader(data, offset)
    reader.expect_constructor(c.MESSAGE_SERVICE)
    flags = reader.read_u32()
    message_id = reader.read_i32()
    from_peer = _read_peer(reader) if flags & (1 << 8) else None
    parsed_peer = _read_peer(reader)
    reply_to_message_id = _parse_reply_header(reader) if flags & (1 << 3) else None
    date_raw = reader.read_i32()
    action_constructor = reader.read_u32()
    peer = requested_peer if (
        parsed_peer.id == requested_peer.id and parsed_peer.type is requested_peer.type
    ) else parsed_peer
    try:
        date = datetime.fromtimestamp(date_raw, tz=timezone.utc)
    except (OverflowError, OSError, ValueError) as exc:
        raise HistoryParseError(
            "Service message date is outside the supported timestamp range.",
            safe_context={"message_id": message_id, "date_raw": date_raw},
        ) from exc
    return Message(
        id=message_id,
        peer=peer,
        date=date,
        text="",
        outgoing=bool(flags & (1 << 1)),
        from_peer=from_peer,
        reply_to_message_id=reply_to_message_id,
        flags=flags,
        parse_warning=f"service_action:{hex_constructor(action_constructor)}",
    )

def _parse_header(data: bytes) -> _HistoryHeader:
    reader = TLReader(data)
    constructor = reader.read_u32()
    if constructor == c.MESSAGES_MESSAGES_NOT_MODIFIED:
        count = reader.read_i32()
        return _HistoryHeader("messages.messagesNotModified", reader.offset, 0, total_count=count)
    if constructor == c.MESSAGES_MESSAGES:
        reader.expect_constructor(c.VECTOR)
        count = reader.read_i32()
        return _HistoryHeader("messages.messages", reader.offset, count, total_count=count)
    if constructor == c.MESSAGES_MESSAGES_SLICE:
        flags = reader.read_u32()
        total_count = reader.read_i32()
        if flags & 1: reader.read_i32()  # next_rate
        offset_id_offset = reader.read_i32() if flags & (1 << 2) else None
        reader.expect_constructor(c.VECTOR)
        count = reader.read_i32()
        return _HistoryHeader(
            "messages.messagesSlice",
            reader.offset,
            count,
            total_count=total_count,
            inexact=bool(flags & (1 << 1)),
            offset_id_offset=offset_id_offset,
        )
    if constructor == c.MESSAGES_CHANNEL_MESSAGES:
        flags = reader.read_u32()
        pts = reader.read_i32()
        total_count = reader.read_i32()
        offset_id_offset = reader.read_i32() if flags & (1 << 2) else None
        reader.expect_constructor(c.VECTOR)
        count = reader.read_i32()
        return _HistoryHeader(
            "messages.channelMessages",
            reader.offset,
            count,
            total_count=total_count,
            pts=pts,
            inexact=bool(flags & (1 << 1)),
            offset_id_offset=offset_id_offset,
        )
    raise UnexpectedConstructorError(
        "Unsupported messages.getHistory response constructor.",
        safe_context={"constructor": hex_constructor(constructor), "response_length": len(data)},
    )


def _discover_messages(
    data: bytes,
    start: int,
    expected_count: int,
    peer: Peer,
) -> tuple[list[Message], list[str]]:
    """Scan and fully validate ordinary and service message candidates."""
    needles = {
        c.MESSAGE.to_bytes(4, "little"): _parse_message_at,
        c.MESSAGE_SERVICE.to_bytes(4, "little"): _parse_service_message_at,
    }
    messages: list[Message] = []
    errors: list[str] = []
    seen_ids: set[int] = set()
    position = start
    while len(messages) < expected_count:
        candidates = [
            (index, parser)
            for needle, parser in needles.items()
            if (index := data.find(needle, position)) >= 0
        ]
        if not candidates:
            break
        candidate, parser = min(candidates, key=lambda item: item[0])
        try:
            message = parser(data, candidate, peer)
            if message.id > 0 and message.id not in seen_ids:
                messages.append(message)
                seen_ids.add(message.id)
        except Exception as exc:
            errors.append(f"candidate@{candidate}:{type(exc).__name__}")
        position = candidate + 4
    return messages, errors


class HistoryResponseCodec:
    """Decode normalized history pages from gateway response bodies."""

    @staticmethod
    def parse(data: bytes, peer: Peer) -> HistoryPage:
        """Parse one response body after RPC error and gzip normalization."""
        header = _parse_header(data)
        if header.expected_message_count == 0:
            return HistoryPage(
                peer=peer,
                messages=(),
                total_count=header.total_count,
                pts=header.pts,
                inexact=header.inexact,
                offset_id_offset=header.offset_id_offset,
                response_type=header.response_type,
            )
        messages, parse_errors = _discover_messages(
            data,
            header.first_message_offset,
            header.expected_message_count,
            peer,
        )
        messages.sort(key=lambda item: item.id, reverse=True)
        if not messages and header.expected_message_count:
            raise HistoryParseError(
                "The history response declared messages but none could be parsed.",
                safe_context={
                    "response_type": header.response_type,
                    "declared_count": header.expected_message_count,
                    "response_length": len(data),
                    "parse_error_count": len(parse_errors),
                },
            )
        if len(messages) < header.expected_message_count:
            parse_errors.append(
                f"declared={header.expected_message_count},parsed={len(messages)}"
            )
        return HistoryPage(
            peer=peer,
            messages=tuple(messages),
            total_count=header.total_count,
            pts=header.pts,
            inexact=header.inexact,
            offset_id_offset=header.offset_id_offset,
            response_type=header.response_type,
            parse_errors=tuple(parse_errors),
        )

"""Conservative parser for photo and document media in history responses."""

from __future__ import annotations

import struct
from dataclasses import dataclass

from ...domain.enums import MediaType
from ...domain.media import MediaReference, PhotoSizeReference
from ...errors import HistoryParseError, UnexpectedConstructorError
from ..codec.tl import TLReader, hex_constructor
from . import constructors as c


@dataclass(slots=True)
class _DocumentAttributeSummary:
    names: list[str]
    file_name: str | None = None
    has_video: bool = False
    has_audio: bool = False
    has_sticker: bool = False


def _read_vector_count(reader: TLReader) -> int:
    reader.expect_constructor(c.VECTOR)
    count = reader.read_i32()
    if count < 0 or count > 100_000:
        raise HistoryParseError(
            "Invalid TL vector count in media.",
            safe_context={"count": count, "offset": reader.offset},
        )
    return count


def _parse_file_location(reader: TLReader) -> dict[str, int | None]:
    """Parse legacy file location fields needed by Core 5 photo downloads."""
    constructor = reader.read_u32()
    if constructor == c.FILE_LOCATION:
        return {
            "constructor": constructor,
            "dc_id": reader.read_i32(),
            "volume_id": reader.read_i64(),
            "local_id": reader.read_i32(),
            "secret": reader.read_i64(),
        }
    if constructor == c.FILE_LOCATION_TO_BE_DEPRECATED:
        return {
            "constructor": constructor,
            "dc_id": None,
            "volume_id": reader.read_i64(),
            "local_id": reader.read_i32(),
            "secret": 0,
        }
    raise UnexpectedConstructorError(
        "Unsupported legacy file location.",
        safe_context={"constructor": hex_constructor(constructor)},
    )


def _parse_photo_size(reader: TLReader) -> PhotoSizeReference:
    constructor = reader.read_u32()
    if constructor == c.PHOTO_SIZE_EMPTY:
        return PhotoSizeReference(type=reader.read_string())
    if constructor == c.PHOTO_SIZE:
        return PhotoSizeReference(
            type=reader.read_string(),
            width=reader.read_i32(),
            height=reader.read_i32(),
            size=reader.read_i32(),
        )
    if constructor == c.PHOTO_CACHED_SIZE:
        kind = reader.read_string(); width = reader.read_i32(); height = reader.read_i32()
        cached = reader.read_bytes()
        return PhotoSizeReference(kind, width, height, len(cached), cached)
    if constructor == c.PHOTO_CACHED_SIZE_LEGACY:
        kind = reader.read_string(); location = _parse_file_location(reader)
        width = reader.read_i32(); height = reader.read_i32(); cached = reader.read_bytes()
        return PhotoSizeReference(
            kind, width, height, len(cached), cached,
            location["constructor"], location["dc_id"], location["volume_id"],
            location["local_id"], location["secret"],
        )
    if constructor == c.PHOTO_SIZE_LEGACY:
        kind = reader.read_string(); location = _parse_file_location(reader)
        return PhotoSizeReference(
            kind, reader.read_i32(), reader.read_i32(), reader.read_i32(), None,
            location["constructor"], location["dc_id"], location["volume_id"],
            location["local_id"], location["secret"],
        )
    if constructor == c.PHOTO_STRIPPED_SIZE or constructor == c.PHOTO_PATH_SIZE:
        kind = reader.read_string(); cached = reader.read_bytes()
        return PhotoSizeReference(kind, size=len(cached))
    if constructor == c.PHOTO_SIZE_PROGRESSIVE:
        kind = reader.read_string(); width = reader.read_i32(); height = reader.read_i32()
        count = _read_vector_count(reader)
        sizes = [reader.read_i32() for _ in range(count)]
        return PhotoSizeReference(kind, width, height, max(sizes) if sizes else None)
    raise UnexpectedConstructorError(
        "Unsupported PhotoSize constructor.",
        safe_context={"constructor": hex_constructor(constructor), "offset": reader.offset - 4},
    )


def _skip_video_size(reader: TLReader) -> None:
    constructor = reader.read_u32()
    if constructor != c.VIDEO_SIZE:
        raise UnexpectedConstructorError(
            "Unsupported VideoSize constructor.",
            safe_context={"constructor": hex_constructor(constructor)},
        )
    flags = reader.read_u32()
    reader.read_string(); reader.read_i32(); reader.read_i32(); reader.read_i32()
    if flags & 1:
        reader.read_raw(8)


def _skip_input_sticker_set(reader: TLReader) -> None:
    constructor = reader.read_u32()
    no_fields = {
        0xFFB62B95, 0x028703C8, 0x0CDE3739, 0xC88B3B02,
        0x04C4D4CE, 0x29D0F5EE, 0x44C1F8E9, 0x49748553,
    }
    if constructor in no_fields:
        return
    if constructor == 0x9DE7A269:
        reader.read_i64(); reader.read_i64(); return
    if constructor in {0x861CC8A0, 0xE67F520E}:
        reader.read_string(); return
    raise UnexpectedConstructorError(
        "Unsupported InputStickerSet constructor.",
        safe_context={"constructor": hex_constructor(constructor)},
    )


def _skip_mask_coords(reader: TLReader) -> None:
    reader.expect_constructor(0xAED6DBB2)
    reader.read_i32(); reader.read_raw(8); reader.read_raw(8); reader.read_raw(8)


def _parse_document_attributes(reader: TLReader) -> _DocumentAttributeSummary:
    count = _read_vector_count(reader)
    summary = _DocumentAttributeSummary(names=[])
    for _ in range(count):
        constructor = reader.read_u32()
        if constructor == c.DOCUMENT_ATTRIBUTE_IMAGE_SIZE:
            reader.read_i32(); reader.read_i32(); summary.names.append("image_size")
        elif constructor == c.DOCUMENT_ATTRIBUTE_ANIMATED:
            summary.names.append("animated")
        elif constructor == c.DOCUMENT_ATTRIBUTE_FILENAME:
            summary.file_name = reader.read_string(); summary.names.append("filename")
        elif constructor == c.DOCUMENT_ATTRIBUTE_HAS_STICKERS:
            summary.names.append("has_stickers")
        elif constructor == c.DOCUMENT_ATTRIBUTE_VIDEO:
            reader.read_u32(); reader.read_i32(); reader.read_i32(); reader.read_i32()
            summary.has_video = True; summary.names.append("video")
        elif constructor == c.DOCUMENT_ATTRIBUTE_AUDIO:
            flags = reader.read_u32(); reader.read_i32()
            if flags & 1: reader.read_string()
            if flags & 2: reader.read_string()
            if flags & 4: reader.read_bytes()
            summary.has_audio = True; summary.names.append("audio")
        elif constructor == c.DOCUMENT_ATTRIBUTE_STICKER:
            flags = reader.read_u32(); reader.read_string(); _skip_input_sticker_set(reader)
            if flags & 1: _skip_mask_coords(reader)
            summary.has_sticker = True; summary.names.append("sticker")
        else:
            raise UnexpectedConstructorError(
                "Unsupported DocumentAttribute constructor.",
                safe_context={"constructor": hex_constructor(constructor), "offset": reader.offset - 4},
            )
    return summary


def _classify_document(mime_type: str, attributes: _DocumentAttributeSummary) -> MediaType:
    mime = mime_type.lower()
    if attributes.has_sticker:
        return MediaType.STICKER
    if attributes.has_video or mime.startswith("video/"):
        return MediaType.VIDEO
    if attributes.has_audio or mime.startswith("audio/"):
        return MediaType.AUDIO
    if mime.startswith("image/"):
        return MediaType.IMAGE_DOCUMENT
    return MediaType.DOCUMENT


def _parse_photo(reader: TLReader, media_constructor: int) -> MediaReference:
    constructor = reader.read_u32()
    if constructor == c.PHOTO_EMPTY:
        remote_id = reader.read_i64()
        return MediaReference(MediaType.PHOTO, remote_id=remote_id, constructor=media_constructor)
    if constructor != c.PHOTO:
        raise UnexpectedConstructorError(
            "Expected Photo or PhotoEmpty.",
            safe_context={"constructor": hex_constructor(constructor)},
        )
    flags = reader.read_u32()
    remote_id = reader.read_i64(); access_hash = reader.read_i64(); file_reference = reader.read_bytes()
    date = reader.read_i32()
    sizes = tuple(_parse_photo_size(reader) for _ in range(_read_vector_count(reader)))
    if flags & (1 << 1):
        for _ in range(_read_vector_count(reader)):
            _skip_video_size(reader)
    dc_id = reader.read_i32()
    thumb_types = tuple(item.type for item in sizes if item.type)
    return MediaReference(
        MediaType.PHOTO,
        remote_id=remote_id,
        access_hash=access_hash,
        file_reference=file_reference,
        dc_id=dc_id,
        date=date,
        thumb_types=thumb_types,
        photo_sizes=sizes,
        constructor=media_constructor,
    )


def _parse_document(reader: TLReader, media_constructor: int) -> MediaReference:
    constructor = reader.read_u32()
    if constructor == c.DOCUMENT_EMPTY:
        remote_id = reader.read_i64()
        return MediaReference(MediaType.DOCUMENT, remote_id=remote_id, constructor=media_constructor)
    if constructor != c.DOCUMENT:
        raise UnexpectedConstructorError(
            "Expected Document or DocumentEmpty.",
            safe_context={"constructor": hex_constructor(constructor)},
        )
    flags = reader.read_u32()
    remote_id = reader.read_i64(); access_hash = reader.read_i64(); file_reference = reader.read_bytes()
    date = reader.read_i32(); mime_type = reader.read_string(); size = reader.read_i32()
    thumbs: tuple[PhotoSizeReference, ...] = ()
    if flags & 1:
        thumbs = tuple(_parse_photo_size(reader) for _ in range(_read_vector_count(reader)))
    if flags & 2:
        for _ in range(_read_vector_count(reader)):
            _skip_video_size(reader)
    dc_id = reader.read_i32()
    attributes = _parse_document_attributes(reader)
    return MediaReference(
        _classify_document(mime_type, attributes),
        remote_id=remote_id,
        access_hash=access_hash,
        file_reference=file_reference,
        mime_type=mime_type,
        file_name=attributes.file_name,
        size=size,
        dc_id=dc_id,
        date=date,
        thumb_types=tuple(item.type for item in thumbs if item.type),
        photo_sizes=thumbs,
        attributes=tuple(attributes.names),
        constructor=media_constructor,
    )


def parse_message_media(reader: TLReader) -> MediaReference | None:
    """Parse media types required by the local client.

    Unsupported media is returned as ``MediaType.UNKNOWN`` rather than causing
    the entire history page to fail. Since Core 5 independently discovers each
    message constructor, it does not need to skip the unsupported object.
    """
    constructor = reader.read_u32()
    if constructor == c.MESSAGE_MEDIA_EMPTY:
        return None
    if constructor == c.MESSAGE_MEDIA_PHOTO:
        flags = reader.read_u32()
        result = _parse_photo(reader, constructor) if flags & 1 else MediaReference(MediaType.PHOTO, constructor=constructor)
        if flags & 4: reader.read_i32()
        return result
    if constructor == c.MESSAGE_MEDIA_DOCUMENT:
        flags = reader.read_u32()
        result = _parse_document(reader, constructor) if flags & 1 else MediaReference(MediaType.DOCUMENT, constructor=constructor)
        if flags & 4: reader.read_i32()
        return result
    return MediaReference(MediaType.UNKNOWN, constructor=constructor)

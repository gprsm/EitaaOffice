"""Authenticated Eitaa history repository."""

from __future__ import annotations

from ...application.gateway import RpcGateway
from ...domain.enums import EndpointRole
from ...domain.message import HistoryPage, HistoryQuery, ReadHistoryResult
from ...domain.peer import Peer
from ...errors import EitaaCoreError, HistoryParseError
from ..diagnostics import DiagnosticManager
from .request import HistoryRequestCodec
from .response import HistoryResponseCodec
from .read_response import ReadHistoryResponseCodec


class EitaaHistoryRepository:
    """Fetch ``messages.getHistory`` and return domain pages."""

    def __init__(
        self,
        gateway: RpcGateway,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.gateway = gateway
        self.diagnostics = diagnostics

    def get_history(self, peer: Peer, query: HistoryQuery) -> HistoryPage:
        """Fetch one page without writing raw response bytes to disk."""
        request = HistoryRequestCodec.build_get_history(peer, query)
        self._emit(
            "history_fetch_started",
            fields={"peer": peer.safe_summary(), "query": _safe_query(query)},
        )
        try:
            result = self.gateway.invoke(
                request,
                operation="messages.getHistory",
                endpoint_role=EndpointRole.API,
            )
            page = HistoryResponseCodec.parse(result.body, peer)
        except EitaaCoreError as exc:
            debug_file = self._emit(
                "history_fetch_failed",
                level="error",
                fields={
                    "peer": peer.safe_summary(),
                    "query": _safe_query(query),
                    "error_type": type(exc).__name__,
                    "safe_context": exc.safe_context,
                },
            )
            if not exc.debug_file:
                exc.debug_file = debug_file
            raise
        except Exception as exc:
            debug_file = self._emit(
                "history_parse_failed",
                level="error",
                fields={
                    "peer": peer.safe_summary(),
                    "query": _safe_query(query),
                    "error_type": type(exc).__name__,
                },
            )
            raise HistoryParseError(
                "Unexpected failure while parsing history.",
                safe_context={"error_type": type(exc).__name__},
                debug_file=debug_file,
            ) from exc
        self._emit(
            "history_fetch_completed",
            fields={"page": page.safe_summary(), "query": _safe_query(query)},
        )
        if page.parse_errors:
            self._emit(
                "history_parse_warnings",
                level="warning",
                fields={
                    "peer": peer.safe_summary(),
                    "warning_count": len(page.parse_errors),
                    "warnings": list(page.parse_errors[:20]),
                },
            )
        return page


    def mark_read(self, peer: Peer, max_id: int) -> ReadHistoryResult:
        """Mark history read using the peer-appropriate Eitaa method."""
        request = HistoryRequestCodec.build_read_history(peer, max_id)
        operation = "channels.readHistory" if peer.type.value == "channel" else "messages.readHistory"
        self._emit(
            "history_mark_read_started",
            fields={"peer": peer.safe_summary(), "max_id": max_id, "operation": operation},
        )
        try:
            result = self.gateway.invoke(request, operation=operation, endpoint_role=EndpointRole.API)
            parsed = ReadHistoryResponseCodec.parse(result.body, peer, max_id)
        except EitaaCoreError as exc:
            debug_file = self._emit(
                "history_mark_read_failed",
                level="error",
                fields={
                    "peer": peer.safe_summary(),
                    "max_id": max_id,
                    "operation": operation,
                    "error_type": type(exc).__name__,
                    "safe_context": exc.safe_context,
                },
            )
            if not exc.debug_file:
                exc.debug_file = debug_file
            raise
        self._emit("history_mark_read_completed", fields=parsed.safe_summary())
        return parsed

    def _emit(self, event: str, *, level: str = "info", fields=None) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("history", event, level=level, fields=fields)


def _safe_query(query: HistoryQuery) -> dict[str, int]:
    return {
        "limit": query.limit,
        "offset_id": query.offset_id,
        "offset_date": query.offset_date,
        "add_offset": query.add_offset,
        "max_id": query.max_id,
        "min_id": query.min_id,
        "hash_value": query.hash_value,
    }

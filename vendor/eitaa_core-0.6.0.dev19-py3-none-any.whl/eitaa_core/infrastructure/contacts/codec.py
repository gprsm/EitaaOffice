"""TL request builders and response parsers for contact operations.

This module is deliberately free of HTTP and persistence concerns. It can be
regression-tested byte-for-byte and reused by synchronous or asynchronous
transport adapters.
"""

from __future__ import annotations

import secrets
from datetime import datetime, timezone

from ...domain.enums import PeerType, UserStatusKind
from ...domain.peer import Peer
from ...domain.phone import PhoneNumber
from ...domain.user import (
    Contact,
    ContactImportResult,
    ContactSnapshot,
    User,
    UserStatus,
)
from ...errors import TLDecodeError, UnexpectedConstructorError
from ..codec.constructors import BOOL_FALSE, BOOL_TRUE, VECTOR
from ..codec.peer import PeerCodec
from ..codec.tl import TLReader, TLWriter, hex_constructor
from . import constructors as c


def _utc_timestamp(value: int) -> datetime | None:
    """Convert a Unix timestamp while tolerating invalid server values."""
    try:
        return datetime.fromtimestamp(value, timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


class ContactsCodec:
    """Pure serializers and parsers for the supported contact method subset."""

    @staticmethod
    def build_get_contacts(*, hash_value: int = 0) -> bytes:
        """Serialize ``contacts.getContacts``."""
        return (
            TLWriter()
            .write_i32(c.CONTACTS_GET_CONTACTS)
            .write_i64(hash_value)
            .to_bytes()
        )

    @staticmethod
    def build_import_contact(
        phone: PhoneNumber,
        *,
        first_name: str,
        last_name: str = "",
        client_id: int | None = None,
    ) -> tuple[bytes, int]:
        """Serialize one-element ``contacts.importContacts``.

        Returns:
            A tuple containing serialized method bytes and the generated
            ``client_id`` used to correlate the response.
        """
        if client_id is None:
            client_id = secrets.randbits(63) or 1
        contact = (
            TLWriter()
            .write_i32(c.INPUT_PHONE_CONTACT)
            .write_i64(client_id)
            .write_string(str(phone))
            .write_string(first_name)
            .write_string(last_name)
            .to_bytes()
        )
        method = (
            TLWriter()
            .write_i32(c.CONTACTS_IMPORT_CONTACTS)
            .write_vector([contact])
            .to_bytes()
        )
        return method, client_id

    @staticmethod
    def build_delete_by_phone(phone: PhoneNumber) -> bytes:
        """Serialize Eitaa's ``contacts.deleteByPhones`` extension."""
        phone_item = TLWriter().write_string(str(phone)).to_bytes()
        return (
            TLWriter()
            .write_i32(c.CONTACTS_DELETE_BY_PHONES)
            .write_vector([phone_item])
            .to_bytes()
        )

    @staticmethod
    def build_delete_contact(contact: Contact) -> bytes:
        """Serialize standard ``contacts.deleteContacts`` fallback."""
        input_user = PeerCodec.encode_input_user(contact.user.peer)
        return (
            TLWriter()
            .write_i32(c.CONTACTS_DELETE_CONTACTS)
            .write_vector([input_user])
            .to_bytes()
        )

    @staticmethod
    def parse_bool(data: bytes) -> bool:
        """Parse a bare TL Bool response and reject trailing data."""
        reader = TLReader(data)
        constructor = reader.read_u32()
        if constructor == BOOL_TRUE:
            value = True
        elif constructor == BOOL_FALSE:
            value = False
        else:
            raise UnexpectedConstructorError(
                "Expected a TL Bool response.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        ContactsCodec._require_end(reader, "Bool")
        return value

    @staticmethod
    def parse_contacts(data: bytes) -> ContactSnapshot:
        """Parse ``contacts.Contacts`` into immutable domain entities."""
        reader = TLReader(data)
        top = reader.read_u32()
        if top == c.CONTACTS_CONTACTS_NOT_MODIFIED:
            ContactsCodec._require_end(reader, "contacts.contactsNotModified")
            return ContactSnapshot(contacts=(), not_modified=True)
        if top != c.CONTACTS_CONTACTS:
            raise UnexpectedConstructorError(
                "Expected contacts.Contacts.",
                safe_context={"actual_constructor": hex_constructor(top)},
            )

        contact_rows: list[tuple[int, bool]] = []
        for _ in range(ContactsCodec._read_vector_count(reader)):
            constructor = reader.read_u32()
            if constructor != c.CONTACT:
                raise UnexpectedConstructorError(
                    "Expected Contact inside contacts.Contacts.",
                    safe_context={"actual_constructor": hex_constructor(constructor)},
                )
            user_id = reader.read_i64()
            mutual = ContactsCodec._read_bool(reader)
            contact_rows.append((user_id, mutual))

        users = [
            ContactsCodec._parse_user(reader)
            for _ in range(ContactsCodec._read_vector_count(reader))
        ]
        ContactsCodec._require_end(reader, "contacts.Contacts")
        by_id = {user.peer.id: user for user in users}
        contacts = tuple(
            Contact(user=by_id.get(user_id, ContactsCodec._placeholder_user(user_id)), mutual=mutual)
            for user_id, mutual in contact_rows
        )
        return ContactSnapshot(contacts=contacts, not_modified=False)

    @staticmethod
    def parse_imported_contacts(data: bytes, *, client_id: int) -> ContactImportResult:
        """Parse ``contacts.importedContacts``."""
        reader = TLReader(data)
        top = reader.read_u32()
        if top != c.CONTACTS_IMPORTED_CONTACTS:
            raise UnexpectedConstructorError(
                "Expected contacts.importedContacts.",
                safe_context={"actual_constructor": hex_constructor(top)},
            )

        imported_user_ids: list[int] = []
        for _ in range(ContactsCodec._read_vector_count(reader)):
            constructor = reader.read_u32()
            if constructor != c.IMPORTED_CONTACT:
                raise UnexpectedConstructorError(
                    "Expected ImportedContact.",
                    safe_context={"actual_constructor": hex_constructor(constructor)},
                )
            imported_user_ids.append(reader.read_i64())
            reader.read_i64()  # response client_id

        popular_count = 0
        for _ in range(ContactsCodec._read_vector_count(reader)):
            constructor = reader.read_u32()
            if constructor != c.POPULAR_CONTACT:
                raise UnexpectedConstructorError(
                    "Expected PopularContact.",
                    safe_context={"actual_constructor": hex_constructor(constructor)},
                )
            reader.read_i64()  # client_id
            reader.read_i32()  # importers
            popular_count += 1

        retry_ids = tuple(
            reader.read_i64() for _ in range(ContactsCodec._read_vector_count(reader))
        )
        users = tuple(
            ContactsCodec._parse_user(reader)
            for _ in range(ContactsCodec._read_vector_count(reader))
        )
        ContactsCodec._require_end(reader, "contacts.importedContacts")
        return ContactImportResult(
            users=users,
            imported_user_ids=tuple(imported_user_ids),
            retry_client_ids=retry_ids,
            popular_invite_count=popular_count,
            client_id=client_id,
        )

    @staticmethod
    def _parse_user(reader: TLReader) -> User:
        constructor = reader.read_u32()
        if constructor == c.USER_EMPTY:
            return ContactsCodec._placeholder_user(reader.read_i64())
        if constructor != c.USER:
            raise UnexpectedConstructorError(
                "Expected User.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )

        flags = reader.read_u32()
        flags2 = reader.read_u32()
        eflags = reader.read_u32()
        user_id = reader.read_i64()
        access_hash = reader.read_i64() if flags & (1 << 0) else None
        first_name = reader.read_string() if flags & (1 << 1) else None
        last_name = reader.read_string() if flags & (1 << 2) else None
        username = reader.read_string() if flags & (1 << 3) else None
        phone = None
        if flags & (1 << 4):
            phone = PhoneNumber.parse(reader.read_string())
        if flags & (1 << 5):
            ContactsCodec._skip_profile_photo(reader)
        status = ContactsCodec._parse_user_status(reader) if flags & (1 << 6) else None
        if flags & (1 << 14):
            reader.read_i32()  # bot_info_version
        if flags & (1 << 18):
            for _ in range(ContactsCodec._read_vector_count(reader)):
                ContactsCodec._skip_restriction_reason(reader)
        if flags & (1 << 19):
            reader.read_string()  # bot_inline_placeholder
        if flags & (1 << 22):
            reader.read_string()  # lang_code
        if eflags & (1 << 1):
            reader.read_string()  # badge_name
        if flags2 & (1 << 12):
            reader.read_i32()  # bot_active_users

        return User(
            peer=Peer(id=user_id, type=PeerType.USER, access_hash=access_hash),
            first_name=first_name,
            last_name=last_name,
            username=username,
            phone=phone,
            status=status,
            is_contact=bool(flags & (1 << 11)),
            is_mutual_contact=bool(flags & (1 << 12)),
            is_deleted=bool(flags & (1 << 13)),
            is_bot=bool(flags & (1 << 14)),
            is_verified=bool(flags & (1 << 17)),
        )

    @staticmethod
    def _placeholder_user(user_id: int) -> User:
        return User(peer=Peer(id=user_id, type=PeerType.USER, access_hash=None))

    @staticmethod
    def _parse_user_status(reader: TLReader) -> UserStatus:
        constructor = reader.read_u32()
        if constructor == c.USER_STATUS_EMPTY:
            return UserStatus(UserStatusKind.UNKNOWN_OR_HIDDEN)
        if constructor == c.USER_STATUS_ONLINE:
            return UserStatus(
                UserStatusKind.ONLINE,
                expires_at=_utc_timestamp(reader.read_i32()),
            )
        if constructor == c.USER_STATUS_OFFLINE:
            return UserStatus(
                UserStatusKind.OFFLINE,
                was_online_at=_utc_timestamp(reader.read_i32()),
            )
        if constructor == c.USER_STATUS_RECENTLY:
            return UserStatus(UserStatusKind.RECENTLY)
        if constructor == c.USER_STATUS_LAST_WEEK:
            return UserStatus(UserStatusKind.LAST_WEEK)
        if constructor == c.USER_STATUS_LAST_MONTH:
            return UserStatus(UserStatusKind.LAST_MONTH)
        raise UnexpectedConstructorError(
            "Unknown UserStatus constructor.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _skip_profile_photo(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor == c.USER_PROFILE_PHOTO_EMPTY:
            return
        if constructor != c.USER_PROFILE_PHOTO:
            raise UnexpectedConstructorError(
                "Unknown UserProfilePhoto constructor.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        reader.read_u32()  # flags
        reader.read_i64()  # photo_id
        ContactsCodec._skip_file_location(reader)
        ContactsCodec._skip_file_location(reader)
        reader.read_i32()  # dc_id

    @staticmethod
    def _skip_file_location(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor == c.FILE_LOCATION_DEPRECATED:
            reader.read_i64()
            reader.read_i32()
            return
        if constructor == c.FILE_LOCATION:
            reader.read_i32()
            reader.read_i64()
            reader.read_i32()
            reader.read_i64()
            return
        raise UnexpectedConstructorError(
            "Unknown FileLocation constructor.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _skip_restriction_reason(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor != c.RESTRICTION_REASON:
            raise UnexpectedConstructorError(
                "Unknown RestrictionReason constructor.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        reader.read_string()
        reader.read_string()
        reader.read_string()

    @staticmethod
    def _read_vector_count(reader: TLReader) -> int:
        constructor = reader.read_u32()
        if constructor != VECTOR:
            raise UnexpectedConstructorError(
                "Expected a TL vector.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        count = reader.read_i32()
        if count < 0 or count > 1_000_000:
            raise TLDecodeError(
                "TL vector count is outside the safe range.",
                safe_context={"count": count},
            )
        return count

    @staticmethod
    def _read_bool(reader: TLReader) -> bool:
        constructor = reader.read_u32()
        if constructor == BOOL_TRUE:
            return True
        if constructor == BOOL_FALSE:
            return False
        raise UnexpectedConstructorError(
            "Expected TL Bool inside contact response.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _require_end(reader: TLReader, object_name: str) -> None:
        if reader.remaining() != 0:
            raise TLDecodeError(
                f"Trailing bytes remain after parsing {object_name}.",
                safe_context={"remaining": reader.remaining(), "object": object_name},
            )

"""Contact TL codec and RPC repository adapter."""

from .codec import ContactsCodec
from .eitaa_repository import EitaaContactRepository

__all__ = ["ContactsCodec", "EitaaContactRepository"]

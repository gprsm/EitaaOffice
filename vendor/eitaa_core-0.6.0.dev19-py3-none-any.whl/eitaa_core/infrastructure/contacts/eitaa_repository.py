"""RPC-backed implementation of the contact repository port."""

from __future__ import annotations

from ...application.gateway import RpcGateway
from ...domain.enums import EndpointRole
from ...domain.phone import PhoneNumber
from ...domain.user import (
    Contact,
    ContactDeleteResult,
    ContactImportResult,
    ContactSnapshot,
)
from ...errors import EitaaCoreError, RpcError
from ...infrastructure.diagnostics import DiagnosticManager
from ...ports.contact_repository import ContactRepository
from .codec import ContactsCodec


class EitaaContactRepository(ContactRepository):
    """Execute supported contact methods through :class:`RpcGateway`."""

    def __init__(
        self,
        gateway: RpcGateway,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.gateway = gateway
        self.diagnostics = diagnostics

    def list_contacts(self, *, hash_value: int = 0) -> ContactSnapshot:
        """Fetch and parse the current contact list."""
        try:
            result = self.gateway.invoke(
                ContactsCodec.build_get_contacts(hash_value=hash_value),
                operation="contacts.getContacts",
                endpoint_role=EndpointRole.API,
            )
            snapshot = ContactsCodec.parse_contacts(result.body)
        except EitaaCoreError as exc:
            self._attach_error(exc, "contacts_list_failed", {"hash_value": hash_value})
            raise
        self._emit(
            "contacts_list_completed",
            fields={**snapshot.safe_summary(), "was_gzip_packed": result.envelope.was_gzip_packed},
        )
        return snapshot

    def import_contact(
        self,
        phone: PhoneNumber,
        *,
        first_name: str,
        last_name: str = "",
    ) -> ContactImportResult:
        """Import one phone number using a random correlation id."""
        packed, client_id = ContactsCodec.build_import_contact(
            phone,
            first_name=first_name,
            last_name=last_name,
        )
        try:
            result = self.gateway.invoke(
                packed,
                operation="contacts.importContacts",
                endpoint_role=EndpointRole.API,
            )
            parsed = ContactsCodec.parse_imported_contacts(
                result.body,
                client_id=client_id,
            )
        except EitaaCoreError as exc:
            self._attach_error(
                exc,
                "contact_import_failed",
                {"phone": str(phone), "first_name_length": len(first_name)},
            )
            raise
        self._emit(
            "contact_import_completed",
            fields={"phone": str(phone), **parsed.safe_summary()},
        )
        return parsed

    def delete_contact(
        self,
        phone: PhoneNumber,
        *,
        known_contact: Contact | None = None,
    ) -> ContactDeleteResult:
        """Delete by phone and transparently fall back to ``deleteContacts``.

        The Eitaa endpoint has historically rejected ``deleteByPhones`` with
        ``RPC 404 INVALID_CONSTRUCTOR`` on some deployments. Only that exact
        compatibility error triggers the standard ``InputUser`` fallback.
        """
        try:
            result = self.gateway.invoke(
                ContactsCodec.build_delete_by_phone(phone),
                operation="contacts.deleteByPhones",
                endpoint_role=EndpointRole.API,
            )
            ok = ContactsCodec.parse_bool(result.body)
            response = ContactDeleteResult(
                ok=ok,
                method="contacts.deleteByPhones",
                contact_was_known=known_contact is not None,
            )
            self._emit(
                "contact_delete_completed",
                fields={"phone": str(phone), **response.safe_summary()},
            )
            return response
        except RpcError as exc:
            if not self._is_invalid_constructor(exc):
                self._attach_error(exc, "contact_delete_failed", {"phone": str(phone)})
                raise
            if known_contact is None or known_contact.user.peer.access_hash is None:
                self._attach_error(
                    exc,
                    "contact_delete_fallback_missing_peer",
                    {"phone": str(phone), "known_contact": known_contact is not None},
                )
                raise
            self._emit(
                "contact_delete_fallback_started",
                fields={"phone": str(phone), "reason": "INVALID_CONSTRUCTOR"},
            )

        try:
            result = self.gateway.invoke(
                ContactsCodec.build_delete_contact(known_contact),
                operation="contacts.deleteContacts",
                endpoint_role=EndpointRole.API,
            )
        except EitaaCoreError as exc:
            self._attach_error(
                exc,
                "contact_delete_fallback_failed",
                {"phone": str(phone)},
            )
            raise
        response = ContactDeleteResult(
            ok=True,
            method="contacts.deleteContacts",
            contact_was_known=True,
        )
        self._emit(
            "contact_delete_fallback_completed",
            fields={
                "phone": str(phone),
                "response_constructor": result.envelope.constructor_name,
                **response.safe_summary(),
            },
        )
        return response

    @staticmethod
    def _is_invalid_constructor(error: RpcError) -> bool:
        return error.code == 404 and "INVALID_CONSTRUCTOR" in error.text.upper()

    def _attach_error(
        self,
        error: EitaaCoreError,
        event: str,
        fields: dict[str, object],
    ) -> None:
        debug_file = self._emit(
            event,
            level="error",
            fields={**fields, "error_type": type(error).__name__},
        )
        if not error.debug_file:
            error.debug_file = debug_file

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("contacts", event, level=level, fields=fields)

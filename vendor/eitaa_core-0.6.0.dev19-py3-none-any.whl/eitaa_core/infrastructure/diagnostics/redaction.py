"""Recursive redaction and summarization helpers for diagnostics."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any


SECRET_KEYS = {
    "token",
    "eitaa_token",
    "imei",
    "device_id",
    "password",
    "phone_code",
    "phone_code_hash",
    "access_hash",
    "auth_key",
    "server_salt",
    "session_id",
    "cookie",
    "authorization",
}

CONTENT_KEYS = {
    "text",
    "message",
    "caption",
    "body",
    "bytes",
    "payload",
    "packed_data",
    "raw_request",
    "raw_response",
}

PHONE_KEYS = {"phone", "phone_number", "recipient_phone"}


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def mask_phone(value: str) -> str:
    """Mask a phone number while preserving enough format for diagnostics."""
    prefix = "+" if value.strip().startswith("+") else ""
    digits = "".join(ch for ch in value if ch.isdigit())
    if len(digits) <= 6:
        return prefix + "***"
    return prefix + digits[:3] + "*" * max(4, len(digits) - 7) + digits[-4:]


def summarize_bytes(value: bytes | bytearray | memoryview) -> dict[str, object]:
    """Represent binary data without retaining its contents."""
    data = bytes(value)
    return {
        "type": type(value).__name__,
        "length": len(data),
        "sha256": _sha256(data),
        "content_stored": False,
    }


def redact(value: Any, *, key: str | None = None, depth: int = 0) -> Any:
    """Recursively transform an object into a JSON-safe, redacted structure.

    The function never stores raw binary values, authentication secrets, phone
    numbers, message text, captions, or payload bodies.
    """
    normalized_key = (key or "").lower()
    if normalized_key in SECRET_KEYS:
        if isinstance(value, str):
            return {"redacted": True, "present": bool(value), "length": len(value)}
        return {"redacted": True, "present": value is not None}
    if normalized_key in PHONE_KEYS and isinstance(value, str):
        return mask_phone(value)
    if normalized_key in CONTENT_KEYS:
        if isinstance(value, (bytes, bytearray, memoryview)):
            return summarize_bytes(value)
        if isinstance(value, str):
            return {
                "redacted": True,
                "present": bool(value),
                "length": len(value),
                "sha256": _sha256(value.encode("utf-8")),
            }
        return {"redacted": True, "present": value is not None}

    if depth > 10:
        return {"truncated": True, "reason": "maximum_depth"}
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return summarize_bytes(value)
    if isinstance(value, Mapping):
        return {
            str(item_key): redact(item_value, key=str(item_key), depth=depth + 1)
            for item_key, item_value in value.items()
        }
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [redact(item, depth=depth + 1) for item in value]
    return {"type": type(value).__name__, "repr_stored": False}

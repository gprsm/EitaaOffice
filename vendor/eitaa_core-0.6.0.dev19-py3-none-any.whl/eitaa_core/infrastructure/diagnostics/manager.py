"""Component-oriented, safe diagnostic event storage."""

from __future__ import annotations

import json
import re
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .redaction import redact

_COMPONENT_PATTERN = re.compile(r"^[a-z][a-z0-9_\-]{0,63}$")


def utc_now() -> str:
    """Return an ISO 8601 timestamp with explicit UTC offset."""
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


@dataclass(slots=True)
class DiagnosticManager:
    """Write one sanitized JSONL file per component.

    A single runtime receives a unique ``run_id`` and directory. When an error
    occurs, the caller can share only the component file named in the exception
    instead of the complete project or all logs.
    """

    root: Path
    enabled: bool = True
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)
    _components: set[str] = field(default_factory=set, init=False, repr=False)

    def __post_init__(self) -> None:
        self.root = Path(self.root)
        if self.enabled:
            self.run_dir.mkdir(parents=True, exist_ok=True)
            self._write_manifest()

    @property
    def run_dir(self) -> Path:
        """Directory containing this runtime's diagnostic files."""
        return self.root / self.run_id

    def file_for(self, component: str) -> Path:
        """Return the exact shareable log path for a component."""
        self._validate_component(component)
        return self.run_dir / f"{component}.jsonl"

    def emit(
        self,
        component: str,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, Any] | None = None,
    ) -> str | None:
        """Append one redacted diagnostic event and return its file path."""
        if not self.enabled:
            return None
        self._validate_component(component)
        record = {
            "at": utc_now(),
            "run_id": self.run_id,
            "component": component,
            "level": level,
            "event": event,
            "fields": redact(fields or {}),
        }
        path = self.file_for(component)
        with self._lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
            self._components.add(component)
            self._write_manifest()
        return str(path)

    def write_report(self, name: str, payload: dict[str, Any]) -> Path | None:
        """Write a redacted one-off JSON report inside the current run."""
        if not self.enabled:
            return None
        self._validate_component(name)
        path = self.run_dir / f"{name}.json"
        with self._lock:
            path.write_text(
                json.dumps(redact(payload), ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8",
            )
            self._components.add(name)
            self._write_manifest()
        return path

    def share_hint(self, component: str) -> str:
        """Return a human-readable instruction naming one exact file."""
        return f"برای عیب‌یابی فقط این فایل را بفرست: {self.file_for(component)}"

    def _write_manifest(self) -> None:
        if not self.enabled:
            return
        manifest = {
            "schema_version": 1,
            "run_id": self.run_id,
            "security": {
                "raw_requests_written": False,
                "raw_responses_written": False,
                "tokens_written": False,
                "imeis_written": False,
                "access_hashes_written": False,
                "file_references_written": False,
                "media_file_names_written": False,
                "message_text_written": False,
                "media_bytes_written": False,
            },
            "component_files": {
                name: f"{name}.jsonl" for name in sorted(self._components)
            },
            "sharing_rule": "Share only the component file named by the error.",
        }
        (self.run_dir / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    @staticmethod
    def _validate_component(component: str) -> None:
        if not _COMPONENT_PATTERN.fullmatch(component):
            raise ValueError(f"Invalid diagnostic component name: {component!r}")

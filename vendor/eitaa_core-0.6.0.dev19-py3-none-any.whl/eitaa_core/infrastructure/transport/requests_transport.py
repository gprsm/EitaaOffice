"""Synchronous ``requests`` implementation of the binary transport port."""

from __future__ import annotations

import time
from typing import Any

import requests

from ...errors import HttpStatusError, NetworkError
from ...ports.transport import TransportRequest, TransportResponse
from ..diagnostics import DiagnosticManager
from ..codec.response import inspect_constructor
from ..codec.tl import hex_constructor


class RequestsBinaryTransport:
    """Send binary POST requests without persisting raw bodies or headers."""

    def __init__(
        self,
        *,
        timeout_seconds: float,
        user_agent: str,
        diagnostics: DiagnosticManager | None = None,
        session: requests.Session | None = None,
    ) -> None:
        self.timeout_seconds = timeout_seconds
        self.user_agent = user_agent
        self.diagnostics = diagnostics
        self._session = session or requests.Session()

    def send(self, request: TransportRequest) -> TransportResponse:
        """Send one binary POST and return normalized metadata and body."""
        request_constructor, request_name = inspect_constructor(request.body)
        safe_request = {
            "operation": request.operation,
            "endpoint": request.endpoint,
            "request_length": len(request.body),
            "request_constructor": (
                hex_constructor(request_constructor) if request_constructor is not None else None
            ),
            "request_constructor_name": request_name,
        }
        self._emit("request_started", fields=safe_request)
        started = time.perf_counter()
        headers = {
            "Content-Type": "application/octet-stream",
            "User-Agent": self.user_agent,
            **dict(request.headers),
        }
        try:
            response = self._session.post(
                request.endpoint,
                data=request.body,
                headers=headers,
                timeout=self.timeout_seconds,
            )
        except requests.RequestException as exc:
            elapsed = time.perf_counter() - started
            debug_file = self._emit(
                "request_network_failed",
                level="error",
                fields={
                    **safe_request,
                    "elapsed_seconds": round(elapsed, 6),
                    "error_type": type(exc).__name__,
                },
            )
            raise NetworkError(
                "The Eitaa endpoint could not be reached.",
                safe_context={
                    "endpoint": request.endpoint,
                    "operation": request.operation,
                    "error_type": type(exc).__name__,
                },
                debug_file=debug_file,
            ) from exc

        elapsed = time.perf_counter() - started
        response_constructor, response_name = inspect_constructor(response.content)
        safe_response: dict[str, Any] = {
            **safe_request,
            "http_status": response.status_code,
            "response_length": len(response.content),
            "response_constructor": (
                hex_constructor(response_constructor) if response_constructor is not None else None
            ),
            "response_constructor_name": response_name,
            "elapsed_seconds": round(elapsed, 6),
            "content_type": response.headers.get("Content-Type"),
        }
        if not 200 <= response.status_code < 300:
            debug_file = self._emit(
                "request_http_failed",
                level="error",
                fields=safe_response,
            )
            raise HttpStatusError(
                f"Eitaa endpoint returned HTTP {response.status_code}.",
                safe_context=safe_response,
                debug_file=debug_file,
            )
        self._emit("request_completed", fields=safe_response)
        return TransportResponse(
            status_code=response.status_code,
            body=response.content,
            endpoint=request.endpoint,
            elapsed_seconds=elapsed,
            content_type=response.headers.get("Content-Type"),
        )

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._session.close()

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, Any] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("transport", event, level=level, fields=fields)

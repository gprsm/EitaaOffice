"""Logical endpoint routing isolated from feature services."""

from __future__ import annotations

from dataclasses import dataclass

from ...config import EitaaCoreConfig
from ...domain.enums import EndpointRole
from ...errors import EndpointRoutingError


@dataclass(slots=True, frozen=True)
class EndpointSelection:
    """Resolved endpoint and its logical role."""

    role: EndpointRole
    url: str
    fallback_index: int | None = None


class EndpointRouter:
    """Map method categories to endpoints proven by the project tests."""

    def __init__(self, config: EitaaCoreConfig) -> None:
        self.config = config

    def resolve(
        self,
        role: EndpointRole,
        *,
        fallback_index: int = 0,
    ) -> EndpointSelection:
        """Resolve an endpoint role into an absolute URL."""
        if role in {EndpointRole.API, EndpointRole.AUTH}:
            return EndpointSelection(role, self.config.api_endpoint)
        if role is EndpointRole.MEDIA:
            return EndpointSelection(role, self.config.media_endpoint)
        if role is EndpointRole.DOWNLOAD:
            if not self.config.download_endpoints:
                raise EndpointRoutingError("No download endpoints are configured.")
            if not 0 <= fallback_index < len(self.config.download_endpoints):
                raise EndpointRoutingError(
                    "Download fallback index is outside the configured endpoint list.",
                    safe_context={
                        "fallback_index": fallback_index,
                        "endpoint_count": len(self.config.download_endpoints),
                    },
                )
            return EndpointSelection(
                role,
                self.config.download_endpoints[fallback_index],
                fallback_index=fallback_index,
            )
        raise EndpointRoutingError(
            "Unsupported endpoint role.",
            safe_context={"role": str(role)},
        )

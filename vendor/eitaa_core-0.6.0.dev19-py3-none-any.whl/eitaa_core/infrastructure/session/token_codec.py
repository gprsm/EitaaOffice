"""TL serialization and parsing for the Eitaa token-refresh method."""

from __future__ import annotations

from dataclasses import dataclass

from ...domain.session import EitaaAppInfo
from ...errors import TLDecodeError, UnexpectedConstructorError
from ..codec.tl import TLReader, TLWriter, hex_constructor
from .constructors import (
    EITAA_APP_INFO,
    EITAA_REFRESH_TOKEN,
    EITAA_UPDATES_TOKEN,
)


@dataclass(slots=True, frozen=True)
class RefreshedToken:
    """Secret-bearing parsed refresh result.

    The token is intentionally excluded from ``repr``. Callers must never place
    the object in diagnostics or serialize it through a generic dataclass helper.
    """

    token: str
    expire: int
    date: int

    def __repr__(self) -> str:
        return (
            "RefreshedToken(token=<redacted>, "
            f"expire={self.expire!r}, date={self.date!r})"
        )


def build_refresh_token_request(app_info: EitaaAppInfo) -> bytes:
    """Serialize ``eitaaRefreshToken(eitaaAppInfo(...))``.

    Args:
        app_info: Non-secret client identity fields expected by the web schema.

    Returns:
        A complete packed TL method ready for the outer ``eitaaObject`` wrapper.
    """
    app_info.validate()
    return (
        TLWriter()
        .write_i32(EITAA_REFRESH_TOKEN)
        .write_i32(EITAA_APP_INFO)
        .write_i32(app_info.build_version)
        .write_string(app_info.device_model)
        .write_string(app_info.system_version)
        .write_string(app_info.app_version)
        .write_string(app_info.lang_code)
        .write_string(app_info.sign)
        .to_bytes()
    )


def parse_refreshed_token(data: bytes) -> RefreshedToken:
    """Parse the stable prefix of an ``eitaa_updates_token`` response.

    Eitaa may append forward-compatible fields after ``token``, ``expire``,
    and ``date``. Unknown trailing bytes are intentionally ignored after the
    complete known prefix has been decoded.
    """
    reader = TLReader(data)
    constructor = reader.read_u32()
    if constructor != EITAA_UPDATES_TOKEN:
        raise UnexpectedConstructorError(
            "Response is not eitaa_updates_token.",
            safe_context={
                "expected_constructor": hex_constructor(EITAA_UPDATES_TOKEN),
                "actual_constructor": hex_constructor(constructor),
                "response_length": len(data),
            },
        )
    try:
        token = reader.read_string()
        expire = reader.read_i32()
        date = reader.read_i32()
    except TLDecodeError as exc:
        raise TLDecodeError(
            "eitaa_updates_token response is truncated.",
            safe_context={"response_length": len(data)},
        ) from exc
    if not token:
        raise TLDecodeError("eitaa_updates_token contains an empty token.")
    return RefreshedToken(token=token, expire=expire, date=date)

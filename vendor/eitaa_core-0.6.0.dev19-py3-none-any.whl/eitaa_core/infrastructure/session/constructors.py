"""Constructors used by the Eitaa token-refresh lifecycle.

The values are taken from the same web schema already used by the project.
They live beside the session adapter so token lifecycle details do not leak into
feature repositories such as History or Media.
"""

EITAA_REFRESH_TOKEN = 0xDC452369
EITAA_APP_INFO = 0x61796DE9
EITAA_UPDATES_EXPIRE_TOKEN = 0xDC252379
EITAA_UPDATES_TOKEN = 0xA56C1A31
EITAA_TOKEN_UPDATING = 0xDC252375

TOKEN_REFRESH_SIGNALS = {
    EITAA_UPDATES_EXPIRE_TOKEN,
    EITAA_TOKEN_UPDATING,
}

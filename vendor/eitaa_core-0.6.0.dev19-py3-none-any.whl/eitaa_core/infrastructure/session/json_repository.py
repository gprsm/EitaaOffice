"""Backward-compatible JSON session repository."""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ...domain.session import Session
from ...errors import (
    SessionDecodeError,
    SessionNotFoundError,
    SessionValidationError,
)
from ..diagnostics import DiagnosticManager


_SECRET_ALIASES = {
    "token": ("token", "eitaa_token"),
    "imei": ("imei", "device_id"),
    "dc": ("dc", "data_center"),
}
_NESTED_CONTAINERS = ("session", "auth", "config", "data")


def _normalize_storage_string(value: str) -> str:
    """Decode values that were copied from browser localStorage JSON."""
    text = value.strip()
    try:
        decoded = json.loads(text)
    except json.JSONDecodeError:
        decoded = None
    if isinstance(decoded, str):
        return decoded
    return text.strip('"')


def _find_first(mapping: dict[str, Any], aliases: tuple[str, ...]) -> Any:
    for key in aliases:
        if mapping.get(key) not in (None, ""):
            return mapping[key]
    for container_name in _NESTED_CONTAINERS:
        nested = mapping.get(container_name)
        if isinstance(nested, dict):
            found = _find_first(nested, aliases)
            if found not in (None, ""):
                return found
    return None


class JsonSessionRepository:
    """Load and atomically save the project's ``.eitaa_session.json`` format.

    The loader accepts both the new versioned schema and older files containing
    top-level or nested ``token`` and ``imei`` values. Saving always writes the
    stable versioned schema while preserving compatibility with prior clients.
    """

    def __init__(
        self,
        path: Path,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.path = Path(path)
        self.diagnostics = diagnostics

    def exists(self) -> bool:
        """Return whether the configured session file exists."""
        return self.path.is_file()

    def peek_imei(self) -> str | None:
        """Return an existing IMEI without requiring a valid token.

        This helper is used only by the native-login facade so a renewed
        login can preserve the same web device identifier. It never emits or
        returns the token. Invalid or absent files simply return ``None``.
        """
        try:
            if not self.path.exists():
                return None
            data = json.loads(self.path.read_text(encoding="utf-8-sig"))
            if not isinstance(data, dict):
                return None
            value = _find_first(data, _SECRET_ALIASES["imei"])
            if not isinstance(value, str):
                return None
            normalized = _normalize_storage_string(value)
            return normalized if normalized.strip() else None
        except (OSError, UnicodeError, json.JSONDecodeError):
            return None

    def archive(self, reason: str = "archived") -> str | None:
        """Atomically move the session file to a timestamped private backup."""
        if not self.path.exists():
            return None
        safe_reason = "".join(
            character if character.isalnum() or character in {"-", "_"} else "_"
            for character in reason
        ).strip("_") or "archived"
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
        destination = self.path.with_name(
            f"{self.path.name}.{safe_reason}.{timestamp}.bak"
        )
        try:
            os.replace(self.path, destination)
            try:
                os.chmod(destination, 0o600)
            except OSError:
                pass
        except OSError as exc:
            debug_file = self._emit(
                "session_archive_failed",
                level="error",
                fields={
                    "path": self.path,
                    "archive_path": destination,
                    "reason": safe_reason,
                    "error_type": type(exc).__name__,
                },
            )
            raise SessionDecodeError(
                "Session file could not be archived after logout.",
                safe_context={
                    "path": str(self.path),
                    "archive_path": str(destination),
                    "error_type": type(exc).__name__,
                },
                debug_file=debug_file,
            ) from exc
        self._emit(
            "session_archived",
            fields={
                "path": self.path,
                "archive_path": destination,
                "reason": safe_reason,
            },
        )
        return str(destination)

    def load(self) -> Session:
        """Load a session without exposing its secrets in exceptions or logs."""
        if not self.path.exists():
            debug_file = self._emit(
                "session_not_found",
                level="error",
                fields={"path": self.path},
            )
            raise SessionNotFoundError(
                f"Session file was not found: {self.path}",
                safe_context={"path": str(self.path)},
                debug_file=debug_file,
            )
        try:
            raw = self.path.read_text(encoding="utf-8-sig")
            data = json.loads(raw)
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            debug_file = self._emit(
                "session_decode_failed",
                level="error",
                fields={"path": self.path, "error_type": type(exc).__name__},
            )
            raise SessionDecodeError(
                "Session file is not valid UTF-8 JSON.",
                safe_context={
                    "path": str(self.path),
                    "error_type": type(exc).__name__,
                },
                debug_file=debug_file,
            ) from exc
        if not isinstance(data, dict):
            debug_file = self._emit(
                "session_root_invalid",
                level="error",
                fields={"path": self.path, "root_type": type(data).__name__},
            )
            raise SessionDecodeError(
                "Session JSON root must be an object.",
                safe_context={"root_type": type(data).__name__},
                debug_file=debug_file,
            )

        token = _find_first(data, _SECRET_ALIASES["token"])
        imei = _find_first(data, _SECRET_ALIASES["imei"])
        dc = _find_first(data, _SECRET_ALIASES["dc"])
        if not isinstance(token, str) or not isinstance(imei, str):
            debug_file = self._emit(
                "session_fields_missing",
                level="error",
                fields={
                    "path": self.path,
                    "token_present": isinstance(token, str) and bool(token),
                    "imei_present": isinstance(imei, str) and bool(imei),
                    "available_top_level_keys": sorted(data.keys()),
                },
            )
            raise SessionValidationError(
                "Session must contain string token and imei values.",
                safe_context={"path": str(self.path)},
                debug_file=debug_file,
            )

        created_at = None
        created_raw = data.get("created_at")
        if isinstance(created_raw, str):
            try:
                created_at = datetime.fromisoformat(created_raw.replace("Z", "+00:00"))
            except ValueError:
                created_at = None
        if dc not in (None, ""):
            try:
                dc = int(dc)
            except (TypeError, ValueError):
                dc = None

        metadata = data.get("metadata") if isinstance(data.get("metadata"), dict) else {}
        session = Session(
            token=_normalize_storage_string(token),
            imei=_normalize_storage_string(imei),
            dc=dc,
            created_at=created_at,
            metadata=dict(metadata),
        )
        try:
            session.validate()
        except SessionValidationError as exc:
            debug_file = self._emit(
                "session_validation_failed",
                level="error",
                fields={"path": self.path, **session.safe_summary()},
            )
            exc.debug_file = debug_file
            raise

        self._emit(
            "session_loaded",
            fields={"path": self.path, **session.safe_summary()},
        )
        return session

    def save(self, session: Session) -> None:
        """Atomically save a session and create a timestamped backup if needed."""
        session.validate()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        backup_path = None
        if self.path.exists():
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
            backup_path = self.path.with_name(f"{self.path.name}.bak.{timestamp}")
            try:
                backup_path.write_bytes(self.path.read_bytes())
            except OSError as exc:
                debug_file = self._emit(
                    "session_backup_failed",
                    level="error",
                    fields={
                        "path": self.path,
                        "backup_path": backup_path,
                        "error_type": type(exc).__name__,
                    },
                )
                raise SessionDecodeError(
                    "Existing session could not be backed up before replacement.",
                    safe_context={
                        "path": str(self.path),
                        "backup_path": str(backup_path),
                        "error_type": type(exc).__name__,
                    },
                    debug_file=debug_file,
                ) from exc

        document = {
            "schema_version": 1,
            "token": session.token,
            "imei": session.imei,
            "dc": session.dc,
            "created_at": (
                session.created_at.isoformat()
                if session.created_at
                else datetime.now(timezone.utc).isoformat()
            ),
            "client": "web",
            "metadata": session.metadata,
        }
        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                "w",
                encoding="utf-8",
                dir=self.path.parent,
                prefix=f".{self.path.name}.",
                suffix=".tmp",
                delete=False,
            ) as handle:
                json.dump(document, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
                temporary_path = Path(handle.name)
            os.replace(temporary_path, self.path)
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass
        except OSError as exc:
            if temporary_path and temporary_path.exists():
                temporary_path.unlink(missing_ok=True)
            debug_file = self._emit(
                "session_save_failed",
                level="error",
                fields={
                    "path": self.path,
                    "error_type": type(exc).__name__,
                    **session.safe_summary(),
                },
            )
            raise SessionDecodeError(
                "Session could not be saved atomically.",
                safe_context={
                    "path": str(self.path),
                    "error_type": type(exc).__name__,
                },
                debug_file=debug_file,
            ) from exc

        self._emit(
            "session_saved",
            fields={
                "path": self.path,
                "backup_created": backup_path is not None,
                "backup_path": backup_path,
                **session.safe_summary(),
            },
        )

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, Any] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("session", event, level=level, fields=fields)

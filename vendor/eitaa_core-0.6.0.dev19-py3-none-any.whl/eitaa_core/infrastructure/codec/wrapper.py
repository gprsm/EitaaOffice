"""Eitaa web wrapper codec."""

from __future__ import annotations

from dataclasses import dataclass

from ...domain.session import Session
from ...errors import UnexpectedConstructorError
from .constructors import EITAA_OBJECT
from .tl import TLReader, TLWriter, hex_constructor


@dataclass(slots=True, frozen=True)
class DecodedEitaaObject:
    """Decoded outer wrapper, primarily used by tests and diagnostics."""

    token: str
    imei: str
    packed_data: bytes
    layer: int
    flags: int


class EitaaObjectCodec:
    """Encode and decode the observed ``eitaaObject`` web wrapper."""

    @staticmethod
    def encode(session: Session, packed_data: bytes, *, layer: int, flags: int) -> bytes:
        """Wrap one serialized API method in the authenticated web envelope."""
        session.validate()
        return (
            TLWriter()
            .write_i32(EITAA_OBJECT)
            .write_string(session.token)
            .write_string(session.imei)
            .write_bytes(packed_data)
            .write_i32(layer)
            .write_i32(flags)
            .to_bytes()
        )

    @staticmethod
    def decode(data: bytes) -> DecodedEitaaObject:
        """Decode a wrapper for deterministic tests; never log the result."""
        reader = TLReader(data)
        constructor = reader.read_u32()
        if constructor != EITAA_OBJECT:
            raise UnexpectedConstructorError(
                "Payload is not an eitaaObject wrapper.",
                safe_context={
                    "expected_constructor": hex_constructor(EITAA_OBJECT),
                    "actual_constructor": hex_constructor(constructor),
                },
            )
        result = DecodedEitaaObject(
            token=reader.read_string(),
            imei=reader.read_string(),
            packed_data=reader.read_bytes(),
            layer=reader.read_i32(),
            flags=reader.read_i32(),
        )
        if reader.remaining() != 0:
            raise UnexpectedConstructorError(
                "Trailing bytes remain after decoding eitaaObject.",
                safe_context={"remaining": reader.remaining()},
            )
        return result

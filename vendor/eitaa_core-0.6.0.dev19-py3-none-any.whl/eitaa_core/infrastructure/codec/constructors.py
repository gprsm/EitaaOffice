"""Constructor registry for the stable Core 1 transport layer.

The registry intentionally contains only constructors required by the common
wrapper and generic response handling. Feature-specific constructors are added
in later core phases beside their serializers and parsers.
"""

from __future__ import annotations

from dataclasses import dataclass


EITAA_OBJECT = 0x7ABE77ED
RPC_ERROR = 0xC4B9F9BB
GZIP_PACKED = 0x3072CFA1
VECTOR = 0x1CB5C415
BOOL_TRUE = 0x997275B5
BOOL_FALSE = 0xBC799737
EITAA_UPDATES_EXPIRE_TOKEN = 0xDC252379
EITAA_UPDATES_TOKEN = 0xA56C1A31
EITAA_TOKEN_UPDATING = 0xDC252375


@dataclass(slots=True, frozen=True)
class ConstructorInfo:
    """Human-readable constructor metadata."""

    id: int
    name: str

    @property
    def hex_id(self) -> str:
        """Return an unsigned, zero-padded constructor identifier."""
        return f"0x{self.id & 0xFFFFFFFF:08x}"


_REGISTRY = {
    EITAA_OBJECT: ConstructorInfo(EITAA_OBJECT, "eitaaObject"),
    RPC_ERROR: ConstructorInfo(RPC_ERROR, "error"),
    GZIP_PACKED: ConstructorInfo(GZIP_PACKED, "gzip_packed"),
    VECTOR: ConstructorInfo(VECTOR, "vector"),
    BOOL_TRUE: ConstructorInfo(BOOL_TRUE, "boolTrue"),
    BOOL_FALSE: ConstructorInfo(BOOL_FALSE, "boolFalse"),
    EITAA_UPDATES_EXPIRE_TOKEN: ConstructorInfo(
        EITAA_UPDATES_EXPIRE_TOKEN, "eitaa_updates_expire_token"
    ),
    EITAA_UPDATES_TOKEN: ConstructorInfo(
        EITAA_UPDATES_TOKEN, "eitaa_updates_token"
    ),
    EITAA_TOKEN_UPDATING: ConstructorInfo(
        EITAA_TOKEN_UPDATING, "eitaa_token_updating"
    ),
}


def lookup(constructor_id: int) -> ConstructorInfo:
    """Return known metadata or a stable ``unknown`` placeholder."""
    unsigned = constructor_id & 0xFFFFFFFF
    return _REGISTRY.get(
        unsigned,
        ConstructorInfo(unsigned, f"unknown_{unsigned:08x}"),
    )

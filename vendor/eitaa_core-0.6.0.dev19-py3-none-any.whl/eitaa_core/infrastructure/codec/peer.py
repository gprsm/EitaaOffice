"""TL serializers for normalized :class:`~eitaa_core.domain.peer.Peer` values."""

from __future__ import annotations

from ...domain.enums import PeerType
from ...domain.peer import Peer
from ...errors import DomainValidationError
from .tl import TLWriter

# InputPeer constructors used by messages and other authenticated API methods.
INPUT_PEER_USER = 0xDDE8A54C
INPUT_PEER_CHAT = 0x35A95CB9
INPUT_PEER_CHANNEL = 0x27BCBBFC

# Peer constructors used by Eitaa's upload.saveFilePart extension.
PEER_USER = 0x59511722
PEER_CHAT = 0x36C6019A
PEER_CHANNEL = 0xA2A5371E

# InputUser constructor used by contacts.deleteContacts.
INPUT_USER = 0xF21158C6


class PeerCodec:
    """Serialize domain peers without exposing constructor details to services."""

    @staticmethod
    def encode_input_peer(peer: Peer) -> bytes:
        """Encode ``InputPeerUser``, ``InputPeerChat`` or ``InputPeerChannel``."""
        peer.validate()
        writer = TLWriter()
        if peer.type is PeerType.USER:
            return (
                writer.write_i32(INPUT_PEER_USER)
                .write_i64(peer.id)
                .write_i64(PeerCodec._required_hash(peer))
                .to_bytes()
            )
        if peer.type is PeerType.CHAT:
            return writer.write_i32(INPUT_PEER_CHAT).write_i64(peer.id).to_bytes()
        if peer.type is PeerType.CHANNEL:
            return (
                writer.write_i32(INPUT_PEER_CHANNEL)
                .write_i64(peer.id)
                .write_i64(PeerCodec._required_hash(peer))
                .to_bytes()
            )
        raise DomainValidationError(
            "Unsupported peer type for InputPeer.",
            safe_context={"peer_type": str(peer.type)},
        )

    @staticmethod
    def encode_upload_peer(peer: Peer) -> bytes:
        """Encode the access-hash-free ``Peer`` object expected during upload."""
        if not isinstance(peer.id, int):
            raise DomainValidationError("Peer id must be an integer.")
        constructor = {
            PeerType.USER: PEER_USER,
            PeerType.CHAT: PEER_CHAT,
            PeerType.CHANNEL: PEER_CHANNEL,
        }.get(peer.type)
        if constructor is None:
            raise DomainValidationError(
                "Unsupported peer type for upload.",
                safe_context={"peer_type": str(peer.type)},
            )
        return TLWriter().write_i32(constructor).write_i64(peer.id).to_bytes()

    @staticmethod
    def encode_input_user(peer: Peer) -> bytes:
        """Encode an ``InputUser`` from a user peer."""
        if peer.type is not PeerType.USER:
            raise DomainValidationError(
                "InputUser requires a user peer.",
                safe_context={"peer_type": peer.type.value},
            )
        peer.validate()
        return (
            TLWriter()
            .write_i32(INPUT_USER)
            .write_i64(peer.id)
            .write_i64(PeerCodec._required_hash(peer))
            .to_bytes()
        )

    @staticmethod
    def _required_hash(peer: Peer) -> int:
        if peer.access_hash is None:
            raise DomainValidationError(
                "Peer access_hash is required for this TL object.",
                safe_context={"peer_type": peer.type.value, "peer_id": peer.id},
            )
        return peer.access_hash

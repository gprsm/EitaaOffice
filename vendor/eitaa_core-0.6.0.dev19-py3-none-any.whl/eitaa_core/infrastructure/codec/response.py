"""Generic response inspection, RPC error parsing, and gzip handling."""

from __future__ import annotations

import gzip
from dataclasses import dataclass

from ...errors import RpcError, TLDecodeError
from .constructors import GZIP_PACKED, RPC_ERROR, lookup
from .tl import TLReader, hex_constructor


@dataclass(slots=True, frozen=True)
class ResponseEnvelope:
    """Normalized binary RPC response."""

    body: bytes
    was_gzip_packed: bool
    constructor: int | None
    constructor_name: str | None


def inspect_constructor(data: bytes) -> tuple[int | None, str | None]:
    """Return the top constructor and known name without consuming a parser."""
    if len(data) < 4:
        return None, None
    constructor = TLReader(data).read_u32()
    return constructor, lookup(constructor).name


def parse_rpc_error(data: bytes) -> RpcError | None:
    """Parse an RPC error or return ``None`` when the payload is not one."""
    if len(data) < 4:
        return None
    reader = TLReader(data)
    if reader.read_u32() != RPC_ERROR:
        return None
    try:
        code = reader.read_i32()
        text = reader.read_string()
    except TLDecodeError as exc:
        raise TLDecodeError(
            "RPC error response is truncated.",
            safe_context={"response_length": len(data)},
        ) from exc
    return RpcError(code, text)


def normalize_response(data: bytes, *, max_gzip_depth: int = 3) -> ResponseEnvelope:
    """Raise RPC errors and recursively unpack ``gzip_packed`` responses."""
    current = bytes(data)
    was_gzip = False
    for depth in range(max_gzip_depth + 1):
        rpc_error = parse_rpc_error(current)
        if rpc_error:
            raise rpc_error
        constructor, name = inspect_constructor(current)
        if constructor != GZIP_PACKED:
            return ResponseEnvelope(current, was_gzip, constructor, name)
        if depth == max_gzip_depth:
            raise TLDecodeError(
                "gzip_packed nesting exceeds the configured limit.",
                safe_context={"max_gzip_depth": max_gzip_depth},
            )
        reader = TLReader(current)
        reader.read_u32()
        packed = reader.read_bytes()
        try:
            current = gzip.decompress(packed)
        except (OSError, EOFError) as exc:
            raise TLDecodeError(
                "gzip_packed payload cannot be decompressed.",
                safe_context={
                    "packed_length": len(packed),
                    "constructor": hex_constructor(constructor),
                },
            ) from exc
        was_gzip = True
    raise AssertionError("unreachable")

"""Bounds-checked TL primitive writer and reader.

The implementation is intentionally small and dependency-free. All methods are
fully deterministic, making the module suitable for byte-for-byte regression
tests against previously captured successful requests.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import Iterable

from ...errors import TLDecodeError, TLEncodeError, UnexpectedConstructorError
from .constructors import BOOL_FALSE, BOOL_TRUE, VECTOR


def to_signed_i32(value: int) -> int:
    """Normalize an integer to the signed 32-bit representation used by TL."""
    value &= 0xFFFFFFFF
    return value - 0x100000000 if value >= 0x80000000 else value


def hex_constructor(value: int) -> str:
    """Format a constructor as unsigned hexadecimal."""
    return f"0x{value & 0xFFFFFFFF:08x}"


class TLWriter:
    """Incrementally serialize TL primitives into an internal byte buffer."""

    def __init__(self) -> None:
        self._buffer = bytearray()

    def write_i32(self, value: int) -> "TLWriter":
        """Append a signed 32-bit integer."""
        try:
            self._buffer.extend(struct.pack("<i", to_signed_i32(value)))
        except (OverflowError, struct.error) as exc:
            raise TLEncodeError(
                "Value cannot be encoded as TL int32.",
                safe_context={"value_type": type(value).__name__},
            ) from exc
        return self

    def write_i64(self, value: int) -> "TLWriter":
        """Append a signed 64-bit integer."""
        try:
            self._buffer.extend(struct.pack("<q", int(value)))
        except (OverflowError, ValueError, struct.error) as exc:
            raise TLEncodeError(
                "Value cannot be encoded as TL int64.",
                safe_context={"value_type": type(value).__name__},
            ) from exc
        return self

    def write_bool(self, value: bool) -> "TLWriter":
        """Append a TL boolean constructor."""
        return self.write_i32(BOOL_TRUE if value else BOOL_FALSE)

    def write_bytes(self, value: bytes | bytearray | memoryview) -> "TLWriter":
        """Append TL ``bytes`` with the required four-byte alignment."""
        raw = bytes(value)
        length = len(raw)
        if length >= 1 << 24:
            raise TLEncodeError(
                "TL bytes payload is too large for the 24-bit length prefix.",
                safe_context={"length": length},
            )
        if length < 254:
            self._buffer.append(length)
            header_length = 1
        else:
            self._buffer.extend(
                (254, length & 0xFF, (length >> 8) & 0xFF, (length >> 16) & 0xFF)
            )
            header_length = 4
        self._buffer.extend(raw)
        padding = (-header_length - length) % 4
        self._buffer.extend(b"\x00" * padding)
        return self

    def write_string(self, value: str) -> "TLWriter":
        """Append a UTF-8 TL string."""
        if not isinstance(value, str):
            raise TLEncodeError(
                "TL string value must be str.",
                safe_context={"value_type": type(value).__name__},
            )
        return self.write_bytes(value.encode("utf-8"))

    def write_raw(self, value: bytes | bytearray | memoryview) -> "TLWriter":
        """Append already-serialized TL bytes without an additional prefix."""
        self._buffer.extend(bytes(value))
        return self

    def write_vector(self, items: Iterable[bytes]) -> "TLWriter":
        """Append a TL vector of already-serialized objects."""
        materialized = [bytes(item) for item in items]
        self.write_i32(VECTOR)
        self.write_i32(len(materialized))
        for item in materialized:
            self.write_raw(item)
        return self

    def to_bytes(self) -> bytes:
        """Return an immutable copy of the serialized buffer."""
        return bytes(self._buffer)


@dataclass(slots=True, frozen=True)
class TLBytesSlice:
    """Decoded TL byte field with source offsets for diagnostics."""

    value: bytes
    start: int
    end: int
    payload_start: int
    payload_end: int


class TLReader:
    """Bounds-checked reader for TL primitives."""

    def __init__(self, data: bytes | bytearray | memoryview, offset: int = 0):
        self._data = bytes(data)
        self._offset = offset
        if not 0 <= offset <= len(self._data):
            raise TLDecodeError(
                "Initial TL offset is outside the payload.",
                safe_context={"offset": offset, "payload_length": len(self._data)},
            )

    @property
    def offset(self) -> int:
        """Current read offset."""
        return self._offset

    @property
    def length(self) -> int:
        """Total payload length."""
        return len(self._data)

    def remaining(self) -> int:
        """Return unread bytes."""
        return len(self._data) - self._offset

    def clone(self) -> "TLReader":
        """Return an independent reader at the same offset."""
        return TLReader(self._data, self._offset)

    def read_i32(self) -> int:
        """Read a signed 32-bit integer."""
        self._need(4)
        value = struct.unpack_from("<i", self._data, self._offset)[0]
        self._offset += 4
        return value

    def read_u32(self) -> int:
        """Read an unsigned 32-bit integer."""
        self._need(4)
        value = struct.unpack_from("<I", self._data, self._offset)[0]
        self._offset += 4
        return value

    def read_i64(self) -> int:
        """Read a signed 64-bit integer."""
        self._need(8)
        value = struct.unpack_from("<q", self._data, self._offset)[0]
        self._offset += 8
        return value

    def read_raw(self, length: int) -> bytes:
        """Read an exact number of raw bytes."""
        if length < 0:
            raise TLDecodeError("Cannot read a negative byte length.")
        self._need(length)
        result = self._data[self._offset : self._offset + length]
        self._offset += length
        return result

    def read_bytes_slice(self) -> TLBytesSlice:
        """Read TL bytes and preserve source offsets."""
        start = self._offset
        self._need(1)
        first = self._data[self._offset]
        self._offset += 1
        if first == 254:
            self._need(3)
            length = (
                self._data[self._offset]
                | (self._data[self._offset + 1] << 8)
                | (self._data[self._offset + 2] << 16)
            )
            self._offset += 3
            header_length = 4
        else:
            length = first
            header_length = 1
        payload_start = self._offset
        value = self.read_raw(length)
        payload_end = self._offset
        padding = (-header_length - length) % 4
        if padding:
            pad = self.read_raw(padding)
            if any(pad):
                raise TLDecodeError(
                    "TL bytes padding contains non-zero data.",
                    safe_context={"padding_length": padding, "start": start},
                )
        return TLBytesSlice(
            value=value,
            start=start,
            end=self._offset,
            payload_start=payload_start,
            payload_end=payload_end,
        )

    def read_bytes(self) -> bytes:
        """Read TL bytes."""
        return self.read_bytes_slice().value

    def read_string(self) -> str:
        """Read a UTF-8 TL string, replacing invalid sequences."""
        return self.read_bytes().decode("utf-8", errors="replace")

    def read_bool(self) -> bool:
        """Read a TL boolean constructor."""
        constructor = self.read_u32()
        if constructor == BOOL_TRUE:
            return True
        if constructor == BOOL_FALSE:
            return False
        raise UnexpectedConstructorError(
            "Expected a TL boolean constructor.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    def expect_constructor(self, expected: int) -> int:
        """Read and verify one constructor, returning its unsigned value."""
        actual = self.read_u32()
        if actual != (expected & 0xFFFFFFFF):
            raise UnexpectedConstructorError(
                "Unexpected TL constructor.",
                safe_context={
                    "expected_constructor": hex_constructor(expected),
                    "actual_constructor": hex_constructor(actual),
                },
            )
        return actual

    def _need(self, length: int) -> None:
        if self._offset + length > len(self._data):
            raise TLDecodeError(
                "TL payload is truncated.",
                safe_context={
                    "offset": self._offset,
                    "need": length,
                    "payload_length": len(self._data),
                },
            )


def encode_i32(value: int) -> bytes:
    """Serialize one TL int32."""
    return TLWriter().write_i32(value).to_bytes()


def encode_i64(value: int) -> bytes:
    """Serialize one TL int64."""
    return TLWriter().write_i64(value).to_bytes()


def encode_bytes(value: bytes) -> bytes:
    """Serialize one TL bytes field."""
    return TLWriter().write_bytes(value).to_bytes()


def encode_string(value: str) -> bytes:
    """Serialize one TL string."""
    return TLWriter().write_string(value).to_bytes()

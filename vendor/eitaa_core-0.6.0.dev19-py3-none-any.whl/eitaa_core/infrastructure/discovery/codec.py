"""TL codec for dialog listing and public-username resolution.

The dialog parser intentionally reads only the stable dialog vector and then
uses conservative, aligned scans to enrich peers with titles, usernames, and
access hashes from the trailing Chat/User vectors. This keeps the module
resilient when unrelated message constructors gain new optional fields.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from ...domain.discovery import (
    DialogCursor, DialogEntry, DialogPage, PeerPhotoReference,
    PhotoLocationReference, UsernameResolution,
)
from ...domain.enums import DialogKind, PeerType
from ...domain.media import MediaReference
from ...domain.peer import Peer
from ...errors import DiscoveryError, TLDecodeError, UnexpectedConstructorError, UsernameResolveError
from ..codec.constructors import BOOL_FALSE, BOOL_TRUE, VECTOR
from ..codec.peer import PEER_CHANNEL, PEER_CHAT, PEER_USER, PeerCodec
from ..codec.tl import TLReader, TLWriter, hex_constructor
from ..contacts.codec import ContactsCodec
from ..history import constructors as history_c
from ..history.media_codec import _parse_photo
from . import constructors as c

_SIMPLE_ENTITY_CONSTRUCTORS = {
    0xBB92BA95, 0xFA04579D, 0x6F635B0D, 0x6CEF8AC7,
    0x6ED02538, 0x64E475C2, 0xBD610BC9, 0x826F8B60,
    0x28A20571, 0x9B69E34B, 0x4C4E743F, 0x9C4E7E8B,
    0xBF0693D4, 0x020DF5D0, 0x761E6AF4,
}
ENTITY_PRE = 0x73924BE0
ENTITY_TEXT_URL = 0x76A6D327
ENTITY_MENTION_NAME = 0xDC7B1140


@dataclass(slots=True, frozen=True)
class _PeerMetadata:
    peer: Peer
    kind: DialogKind
    broadcast: bool = False
    megagroup: bool = False
    participants_count: int | None = None
    photo: PeerPhotoReference | None = None


class DiscoveryCodec:
    """Pure request and response codec for discovery operations."""

    @staticmethod
    def build_get_dialogs(
        *,
        limit: int,
        offset_date: int = 0,
        offset_id: int = 0,
        offset_peer: Peer | None = None,
        exclude_pinned: bool = False,
        folder_id: int | None = None,
        hash_value: int = 0,
    ) -> bytes:
        if not 1 <= limit <= 100:
            raise DiscoveryError(
                "Dialog limit must be between 1 and 100.",
                safe_context={"limit": limit},
            )
        flags = 0
        if exclude_pinned:
            flags |= 1 << 0
        if folder_id is not None:
            flags |= 1 << 1
        peer_bytes = (
            PeerCodec.encode_input_peer(offset_peer)
            if offset_peer is not None
            else TLWriter().write_i32(c.INPUT_PEER_EMPTY).to_bytes()
        )
        writer = (
            TLWriter()
            .write_i32(c.MESSAGES_GET_DIALOGS)
            .write_i32(flags)
        )
        if folder_id is not None:
            writer.write_i32(folder_id)
        return (
            writer
            .write_i32(offset_date)
            .write_i32(offset_id)
            .write_raw(peer_bytes)
            .write_i32(limit)
            .write_i64(hash_value)
            .to_bytes()
        )

    @staticmethod
    def build_resolve_username(username: str) -> bytes:
        normalized = username.strip().lstrip("@").strip()
        if not normalized or len(normalized) > 64:
            raise UsernameResolveError(
                "Username is empty or outside the supported length.",
                safe_context={"username_length": len(normalized)},
            )
        return (
            TLWriter()
            .write_i32(c.CONTACTS_RESOLVE_USERNAME)
            .write_string(normalized)
            .to_bytes()
        )

    @staticmethod
    def build_get_full_peer(peer: Peer) -> tuple[bytes, str]:
        """Build the full-peer request needed for a downloadable Photo object."""
        peer.validate()
        if peer.type is PeerType.CHANNEL:
            assert peer.access_hash is not None
            payload = (
                TLWriter().write_i32(c.CHANNELS_GET_FULL_CHANNEL)
                .write_i32(c.INPUT_CHANNEL).write_i64(peer.id)
                .write_i64(peer.access_hash).to_bytes()
            )
            return payload, "channels.getFullChannel"
        if peer.type is PeerType.CHAT:
            return (
                TLWriter().write_i32(c.MESSAGES_GET_FULL_CHAT).write_i64(peer.id).to_bytes(),
                "messages.getFullChat",
            )
        assert peer.access_hash is not None
        payload = (
            TLWriter().write_i32(c.USERS_GET_FULL_USER)
            .write_i32(c.INPUT_USER).write_i64(peer.id).write_i64(peer.access_hash).to_bytes()
        )
        return payload, "users.getFullUser"

    @staticmethod
    def parse_full_peer_photo(data: bytes, *, expected_photo_id: int) -> MediaReference:
        """Find and validate the full ``Photo`` matching a dialog photo id."""
        needle = history_c.PHOTO.to_bytes(4, "little")
        position = 0
        candidates = 0
        parsed_photo_ids: list[int] = []
        parse_failures: list[str] = []
        valid_photos: list[MediaReference] = []
        while (position := data.find(needle, position)) >= 0:
            candidates += 1
            try:
                media = _parse_photo(TLReader(data, position), 0)
                if media.remote_id is not None:
                    parsed_photo_ids.append(media.remote_id)
                if media.access_hash is not None and media.file_reference is not None:
                    valid_photos.append(media)
                    if media.remote_id == expected_photo_id:
                        return media
            except Exception as exc:
                parse_failures.append(type(exc).__name__)
            position += 4
        # In Eitaa layer 135, ChatPhoto.photo_id and the single full Photo.id
        # may differ even though both represent the current avatar. A unique
        # valid Photo in getFullChannel/getFullChat/getFullUser is unambiguous.
        if len(valid_photos) == 1:
            return valid_photos[0]
        raise DiscoveryError(
            "The full peer response did not contain the expected downloadable photo.",
            safe_context={
                "expected_photo_id": expected_photo_id,
                "candidate_count": candidates,
                "parsed_photo_ids": parsed_photo_ids[:10],
                "parse_failures": parse_failures[:10],
            },
        )

    @staticmethod
    def parse_dialogs(data: bytes) -> DialogPage:
        reader = TLReader(data)
        top = reader.read_u32()
        total_count: int | None = None
        response_type = "messages.dialogs"
        if top == c.MESSAGES_DIALOGS_SLICE:
            response_type = "messages.dialogsSlice"
            total_count = reader.read_i32()
        elif top == c.MESSAGES_DIALOGS:
            response_type = "messages.dialogs"
        elif top == c.MESSAGES_DIALOGS_NOT_MODIFIED:
            count = reader.read_i32()
            return DialogPage((), total_count=count, response_type="messages.dialogsNotModified")
        else:
            raise UnexpectedConstructorError(
                "Unsupported messages.getDialogs response constructor.",
                safe_context={
                    "actual_constructor": hex_constructor(top),
                    "response_length": len(data),
                },
            )

        count = DiscoveryCodec._read_vector_count(reader)
        raw_dialogs: list[DialogEntry] = []
        warnings: list[str] = []
        for index in range(count):
            constructor = reader.read_u32()
            if constructor == c.DIALOG:
                raw_dialogs.append(DiscoveryCodec._parse_dialog(reader))
            elif constructor == c.DIALOG_FOLDER:
                DiscoveryCodec._skip_dialog_folder(reader)
                warnings.append(f"dialog_folder_omitted:{index}")
            else:
                raise UnexpectedConstructorError(
                    "Unsupported Dialog constructor.",
                    safe_context={
                        "actual_constructor": hex_constructor(constructor),
                        "dialog_index": index,
                    },
                )

        message_dates = DiscoveryCodec._scan_message_dates(data, reader.offset)
        metadata = DiscoveryCodec._scan_peer_metadata(data)
        enriched: list[DialogEntry] = []
        for item in raw_dialogs:
            candidate = metadata.get((item.peer.type, item.peer.id))
            peer = candidate.peer if candidate else item.peer
            date = message_dates.get((item.peer.type, item.peer.id, item.top_message_id))
            if candidate:
                enriched.append(replace(
                    item,
                    peer=peer,
                    top_message_date=date,
                    kind=candidate.kind,
                    broadcast=candidate.broadcast,
                    megagroup=candidate.megagroup,
                    participants_count=candidate.participants_count,
                    photo=replace(candidate.photo, peer=peer) if candidate.photo else None,
                ))
            else:
                enriched.append(replace(
                    item,
                    peer=peer,
                    top_message_date=date,
                    kind=DiscoveryCodec._kind_for_peer(peer),
                ))
        next_cursor = None
        for item in reversed(enriched):
            if item.top_message_date is not None:
                try:
                    item.peer.validate()
                except Exception:
                    continue
                next_cursor = DialogCursor(item.top_message_date, item.top_message_id, item.peer)
                break
        if enriched and next_cursor is None and response_type == "messages.dialogsSlice":
            warnings.append("last_dialog_cursor_date_not_found")
        return DialogPage(
            dialogs=tuple(enriched),
            total_count=total_count if total_count is not None else len(enriched),
            response_type=response_type,
            parse_warnings=tuple(warnings),
            next_cursor=next_cursor,
        )

    @staticmethod
    def parse_resolved_username(data: bytes, username: str) -> UsernameResolution:
        reader = TLReader(data)
        top = reader.read_u32()
        if top != c.CONTACTS_RESOLVED_PEER:
            raise UnexpectedConstructorError(
                "Expected contacts.resolvedPeer.",
                safe_context={"actual_constructor": hex_constructor(top)},
            )
        peer = DiscoveryCodec._read_peer(reader)
        metadata = DiscoveryCodec._scan_peer_metadata(data)
        resolved_metadata = metadata.get((peer.type, peer.id))
        resolved = resolved_metadata.peer if resolved_metadata else peer
        if resolved.type in {PeerType.USER, PeerType.CHANNEL} and resolved.access_hash is None:
            raise UsernameResolveError(
                "The username resolved, but Eitaa did not return a sendable access hash.",
                safe_context={"peer": resolved.safe_summary()},
            )
        normalized = username.strip().lstrip("@").strip()
        if not resolved.username:
            resolved = replace(resolved, username=normalized)
        return UsernameResolution(username=normalized, peer=resolved)

    @staticmethod
    def _parse_dialog(reader: TLReader) -> DialogEntry:
        flags = reader.read_u32()
        peer = DiscoveryCodec._read_peer(reader)
        top_message = reader.read_i32()
        read_inbox = reader.read_i32()
        read_outbox = reader.read_i32()
        unread_count = reader.read_i32()
        unread_mentions = reader.read_i32()
        DiscoveryCodec._skip_notify_settings(reader)
        if flags & (1 << 0):
            reader.read_i32()  # pts
        if flags & (1 << 1):
            DiscoveryCodec._skip_draft(reader)
        folder_id = reader.read_i32() if flags & (1 << 4) else None
        return DialogEntry(
            peer=peer,
            top_message_id=top_message,
            unread_count=unread_count,
            unread_mentions_count=unread_mentions,
            read_inbox_max_id=read_inbox,
            read_outbox_max_id=read_outbox,
            pinned=bool(flags & (1 << 2)),
            unread_mark=bool(flags & (1 << 3)),
            folder_id=folder_id,
        )

    @staticmethod
    def _read_peer(reader: TLReader) -> Peer:
        constructor = reader.read_u32()
        peer_id = reader.read_i64()
        if constructor == PEER_USER:
            return Peer(peer_id, PeerType.USER)
        if constructor == PEER_CHAT:
            return Peer(peer_id, PeerType.CHAT)
        if constructor == PEER_CHANNEL:
            return Peer(peer_id, PeerType.CHANNEL)
        raise UnexpectedConstructorError(
            "Unsupported Peer constructor in discovery response.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _skip_notify_settings(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor != c.PEER_NOTIFY_SETTINGS:
            raise UnexpectedConstructorError(
                "Unsupported PeerNotifySettings constructor.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        flags = reader.read_u32()
        if flags & 1:
            DiscoveryCodec._read_bool(reader)
        if flags & 2:
            DiscoveryCodec._read_bool(reader)
        if flags & 4:
            reader.read_i32()
        if flags & 8:
            reader.read_string()

    @staticmethod
    def _skip_draft(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor == c.DRAFT_MESSAGE_EMPTY:
            flags = reader.read_u32()
            if flags & 1:
                reader.read_i32()
            return
        if constructor != c.DRAFT_MESSAGE:
            raise UnexpectedConstructorError(
                "Unsupported DraftMessage constructor.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        flags = reader.read_u32()
        if flags & 1:
            reader.read_i32()
        reader.read_string()
        if flags & (1 << 3):
            for _ in range(DiscoveryCodec._read_vector_count(reader)):
                DiscoveryCodec._skip_message_entity(reader)
        reader.read_i32()

    @staticmethod
    def _skip_message_entity(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor in _SIMPLE_ENTITY_CONSTRUCTORS:
            reader.read_i32(); reader.read_i32(); return
        if constructor == ENTITY_PRE:
            reader.read_i32(); reader.read_i32(); reader.read_string(); return
        if constructor == ENTITY_TEXT_URL:
            reader.read_i32(); reader.read_i32(); reader.read_string(); return
        if constructor == ENTITY_MENTION_NAME:
            reader.read_i32(); reader.read_i32(); reader.read_i64(); return
        raise UnexpectedConstructorError(
            "Unsupported MessageEntity inside DraftMessage.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _skip_dialog_folder(reader: TLReader) -> None:
        reader.read_u32()  # flags
        folder_constructor = reader.read_u32()
        if folder_constructor != c.FOLDER:
            raise UnexpectedConstructorError(
                "Unsupported Folder constructor.",
                safe_context={"actual_constructor": hex_constructor(folder_constructor)},
            )
        folder_flags = reader.read_u32()
        reader.read_i32()
        reader.read_string()
        if folder_flags & (1 << 3):
            DiscoveryCodec._skip_chat_photo(reader)
        DiscoveryCodec._read_peer(reader)
        reader.read_i32()
        reader.read_i32(); reader.read_i32(); reader.read_i32(); reader.read_i32()

    @staticmethod
    def _skip_chat_photo(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor == c.CHAT_PHOTO_EMPTY:
            return
        if constructor != c.CHAT_PHOTO:
            raise UnexpectedConstructorError(
                "Unsupported ChatPhoto constructor.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        reader.read_u32()
        reader.read_i64()
        ContactsCodec._skip_file_location(reader)
        ContactsCodec._skip_file_location(reader)
        reader.read_i32()

    @staticmethod
    def _scan_peer_metadata(data: bytes) -> dict[tuple[PeerType, int], _PeerMetadata]:
        found: dict[tuple[PeerType, int], _PeerMetadata] = {}
        constructors = {
            c.CHAT_EMPTY, c.CHAT, c.CHAT_FORBIDDEN,
            c.CHANNEL, c.CHANNEL_FORBIDDEN,
            0xD3BC4B7A, 0xECD26DCB,
        }
        for offset in range(0, max(0, len(data) - 4) + 1, 4):
            constructor = int.from_bytes(data[offset:offset+4], "little", signed=False)
            if constructor not in constructors:
                continue
            try:
                metadata = DiscoveryCodec._parse_peer_metadata(TLReader(data, offset))
            except Exception:
                continue
            if metadata.peer.id > 0:
                found[(metadata.peer.type, metadata.peer.id)] = metadata
        return found

    @staticmethod
    def _parse_peer_metadata(reader: TLReader) -> _PeerMetadata:
        constructor = reader.read_u32()
        if constructor == 0xD3BC4B7A:
            return _PeerMetadata(Peer(reader.read_i64(), PeerType.USER), DialogKind.PRIVATE)
        if constructor == 0xECD26DCB:
            flags = reader.read_u32(); reader.read_u32(); reader.read_u32()
            peer_id = reader.read_i64()
            access_hash = reader.read_i64() if flags & 1 else None
            first = reader.read_string() if flags & 2 else None
            last = reader.read_string() if flags & 4 else None
            username = reader.read_string() if flags & 8 else None
            if flags & (1 << 4): reader.read_string()
            title = " ".join(part for part in (first, last) if part).strip() or None
            peer = Peer(peer_id, PeerType.USER, access_hash, username, title)
            photo = DiscoveryCodec._parse_profile_photo(reader, peer) if flags & (1 << 5) else None
            return _PeerMetadata(peer, DialogKind.PRIVATE, photo=photo)
        if constructor == c.CHAT_EMPTY:
            return _PeerMetadata(Peer(reader.read_i64(), PeerType.CHAT), DialogKind.BASIC_GROUP)
        if constructor == c.CHAT_FORBIDDEN:
            return _PeerMetadata(
                Peer(reader.read_i64(), PeerType.CHAT, title=reader.read_string()),
                DialogKind.BASIC_GROUP,
            )
        if constructor == c.CHAT:
            reader.read_u32()
            peer_id = reader.read_i64()
            peer = Peer(peer_id, PeerType.CHAT, title=reader.read_string())
            if reader.remaining() < 4:
                return _PeerMetadata(peer, DialogKind.BASIC_GROUP)
            photo = DiscoveryCodec._parse_chat_photo(reader, peer)
            participants_count = reader.read_i32()
            return _PeerMetadata(
                peer, DialogKind.BASIC_GROUP,
                participants_count=participants_count,
                photo=photo,
            )
        if constructor == c.CHANNEL_FORBIDDEN:
            flags = reader.read_u32()
            peer_id = reader.read_i64()
            access_hash = reader.read_i64()
            title = reader.read_string()
            broadcast = bool(flags & (1 << 5))
            megagroup = bool(flags & (1 << 8))
            kind = DialogKind.SUPERGROUP if megagroup else DialogKind.CHANNEL
            return _PeerMetadata(
                Peer(peer_id, PeerType.CHANNEL, access_hash, title=title),
                kind,
                broadcast=broadcast,
                megagroup=megagroup,
            )
        if constructor == c.CHANNEL:
            flags = reader.read_u32()
            peer_id = reader.read_i64()
            access_hash = reader.read_i64() if flags & (1 << 13) else None
            title = reader.read_string()
            username = reader.read_string() if flags & (1 << 6) else None
            peer = Peer(peer_id, PeerType.CHANNEL, access_hash, username, title)
            broadcast = bool(flags & (1 << 5))
            megagroup = bool(flags & (1 << 8))
            kind = DialogKind.SUPERGROUP if megagroup else DialogKind.CHANNEL
            if reader.remaining() < 4:
                return _PeerMetadata(peer, kind, broadcast=broadcast, megagroup=megagroup)
            photo = DiscoveryCodec._parse_chat_photo(reader, peer)
            reader.read_i32()  # date
            if flags & (1 << 9):
                for _ in range(DiscoveryCodec._read_vector_count(reader)):
                    DiscoveryCodec._skip_restriction_reason(reader)
            if flags & (1 << 14): DiscoveryCodec._skip_admin_rights(reader)
            if flags & (1 << 15): DiscoveryCodec._skip_banned_rights(reader)
            if flags & (1 << 18): DiscoveryCodec._skip_banned_rights(reader)
            participants_count = reader.read_i32() if flags & (1 << 17) else None
            return _PeerMetadata(
                peer, kind,
                broadcast=broadcast,
                megagroup=megagroup,
                participants_count=participants_count,
                photo=photo,
            )
        raise UnexpectedConstructorError("Not a peer metadata constructor.")

    @staticmethod
    def _kind_for_peer(peer: Peer) -> DialogKind:
        if peer.type is PeerType.USER:
            return DialogKind.PRIVATE
        if peer.type is PeerType.CHAT:
            return DialogKind.BASIC_GROUP
        return DialogKind.UNKNOWN

    @staticmethod
    def _parse_file_location(reader: TLReader) -> PhotoLocationReference:
        constructor = reader.read_u32()
        if constructor == c.FILE_LOCATION_DEPRECATED:
            return PhotoLocationReference(
                constructor=constructor,
                volume_id=reader.read_i64(),
                local_id=reader.read_i32(),
            )
        if constructor == c.FILE_LOCATION:
            return PhotoLocationReference(
                constructor=constructor,
                dc_id=reader.read_i32(),
                volume_id=reader.read_i64(),
                local_id=reader.read_i32(),
                secret=reader.read_i64(),
            )
        raise UnexpectedConstructorError(
            "Unsupported FileLocation constructor.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _parse_chat_photo(reader: TLReader, peer: Peer) -> PeerPhotoReference | None:
        constructor = reader.read_u32()
        if constructor == c.CHAT_PHOTO_EMPTY:
            return None
        if constructor != c.CHAT_PHOTO:
            raise UnexpectedConstructorError(
                "Unsupported ChatPhoto constructor.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        flags = reader.read_u32()
        photo_id = reader.read_i64()
        small = DiscoveryCodec._parse_file_location(reader)
        big = DiscoveryCodec._parse_file_location(reader)
        dc_id = reader.read_i32()
        return PeerPhotoReference(
            peer=peer, photo_id=photo_id, dc_id=dc_id,
            small=small, big=big, has_video=bool(flags & 1),
        )

    @staticmethod
    def _parse_profile_photo(reader: TLReader, peer: Peer) -> PeerPhotoReference | None:
        constructor = reader.read_u32()
        if constructor == c.USER_PHOTO_EMPTY:
            return None
        if constructor != c.USER_PHOTO:
            raise UnexpectedConstructorError(
                "Unsupported UserProfilePhoto constructor.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        flags = reader.read_u32()
        photo_id = reader.read_i64()
        small = DiscoveryCodec._parse_file_location(reader)
        big = DiscoveryCodec._parse_file_location(reader)
        dc_id = reader.read_i32()
        return PeerPhotoReference(
            peer=peer, photo_id=photo_id, dc_id=dc_id,
            small=small, big=big, has_video=bool(flags & 1),
        )

    @staticmethod
    def _skip_restriction_reason(reader: TLReader) -> None:
        reader.read_u32(); reader.read_string(); reader.read_string(); reader.read_string()

    @staticmethod
    def _skip_admin_rights(reader: TLReader) -> None:
        reader.expect_constructor(c.CHAT_ADMIN_RIGHTS); reader.read_u32()

    @staticmethod
    def _skip_banned_rights(reader: TLReader) -> None:
        reader.expect_constructor(c.CHAT_BANNED_RIGHTS); reader.read_u32(); reader.read_i32()

    @staticmethod
    def _scan_message_dates(data: bytes, start: int) -> dict[tuple[PeerType, int, int], int]:
        found: dict[tuple[PeerType, int, int], int] = {}
        needles = (c.MESSAGE, c.MESSAGE_SERVICE)
        for constructor in needles:
            needle = constructor.to_bytes(4, "little")
            position = max(0, start)
            while (position := data.find(needle, position)) >= 0:
                try:
                    peer, message_id, date = DiscoveryCodec._parse_message_cursor_at(data, position)
                    if message_id > 0 and 500_000_000 <= date <= 2_147_483_647:
                        found[(peer.type, peer.id, message_id)] = date
                except Exception:
                    pass
                position += 4
        return found

    @staticmethod
    def _parse_message_cursor_at(data: bytes, offset: int) -> tuple[Peer, int, int]:
        reader = TLReader(data, offset)
        constructor = reader.read_u32()
        flags = reader.read_u32()
        message_id = reader.read_i32()
        if flags & (1 << 8): DiscoveryCodec._read_peer(reader)
        peer = DiscoveryCodec._read_peer(reader)
        if constructor == c.MESSAGE:
            if flags & (1 << 2): DiscoveryCodec._skip_fwd_header(reader)
            if flags & (1 << 11): reader.read_i64()
        if flags & (1 << 3): DiscoveryCodec._skip_reply_header(reader)
        return peer, message_id, reader.read_i32()

    @staticmethod
    def _skip_fwd_header(reader: TLReader) -> None:
        reader.expect_constructor(c.MESSAGE_FWD_HEADER)
        flags = reader.read_u32()
        if flags & 1: DiscoveryCodec._read_peer(reader)
        if flags & (1 << 5): reader.read_string()
        reader.read_i32()
        if flags & (1 << 2): reader.read_i32()
        if flags & (1 << 3): reader.read_string()
        if flags & (1 << 4): DiscoveryCodec._read_peer(reader); reader.read_i32()
        if flags & (1 << 6): reader.read_string()

    @staticmethod
    def _skip_reply_header(reader: TLReader) -> None:
        reader.expect_constructor(c.MESSAGE_REPLY_HEADER)
        flags = reader.read_u32(); reader.read_i32()
        if flags & 1: DiscoveryCodec._read_peer(reader)
        if flags & 2: reader.read_i32()

    @staticmethod
    def _read_vector_count(reader: TLReader) -> int:
        constructor = reader.read_u32()
        if constructor != VECTOR:
            raise UnexpectedConstructorError(
                "Expected TL vector.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        count = reader.read_i32()
        if count < 0 or count > 1_000_000:
            raise TLDecodeError("Vector count is outside the safe range.", safe_context={"count": count})
        return count

    @staticmethod
    def _read_bool(reader: TLReader) -> bool:
        constructor = reader.read_u32()
        if constructor == BOOL_TRUE:
            return True
        if constructor == BOOL_FALSE:
            return False
        raise UnexpectedConstructorError(
            "Expected TL Bool.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

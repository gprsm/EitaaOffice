"""Authenticated Eitaa discovery repository."""

from __future__ import annotations

from ...application.gateway import RpcGateway
from ...domain.discovery import DialogPage, PeerPhotoReference, UsernameResolution
from ...domain.enums import EndpointRole
from ...domain.media import MediaReference
from ...domain.peer import Peer
from ...infrastructure.diagnostics import DiagnosticManager
from ...ports.discovery_repository import DiscoveryRepository
from .codec import DiscoveryCodec


class EitaaDiscoveryRepository(DiscoveryRepository):
    """Execute dialog and username discovery through the shared gateway."""

    def __init__(self, gateway: RpcGateway, diagnostics: DiagnosticManager | None = None) -> None:
        self.gateway = gateway
        self.diagnostics = diagnostics

    def get_dialogs(self, **kwargs) -> DialogPage:
        method = DiscoveryCodec.build_get_dialogs(**kwargs)
        result = self.gateway.invoke(
            method,
            operation="messages.getDialogs",
            endpoint_role=EndpointRole.API,
        )
        page = DiscoveryCodec.parse_dialogs(result.body)
        self._emit("dialogs_received", fields=page.safe_summary())
        return page

    def resolve_username(self, username: str) -> UsernameResolution:
        method = DiscoveryCodec.build_resolve_username(username)
        result = self.gateway.invoke(
            method,
            operation="contacts.resolveUsername",
            endpoint_role=EndpointRole.API,
        )
        resolution = DiscoveryCodec.parse_resolved_username(result.body, username)
        self._emit("username_resolved", fields=resolution.safe_summary())
        return resolution

    def resolve_peer_photo(self, photo: PeerPhotoReference) -> MediaReference:
        method, operation = DiscoveryCodec.build_get_full_peer(photo.peer)
        result = self.gateway.invoke(method, operation=operation, endpoint_role=EndpointRole.API)
        resolved = DiscoveryCodec.parse_full_peer_photo(
            result.body, expected_photo_id=photo.photo_id
        )
        self._emit(
            "peer_photo_resolved",
            fields={"photo": photo.safe_summary(), "media": resolved.safe_summary()},
        )
        return resolved

    def _emit(self, event: str, *, level: str = "info", fields=None) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("discovery", event, level=level, fields=fields)

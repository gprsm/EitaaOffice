"""Native remote media repository using the common RPC gateway."""

from __future__ import annotations

from ...application.gateway import RpcGateway
from ...domain.enums import EndpointRole, MediaDownloadMethod
from ...domain.media import MediaChunk, RemoteMediaReference
from ...errors import EitaaCoreError, MediaDownloadError
from ..diagnostics import DiagnosticManager
from .request import MediaRequestCodec
from .response import MediaResponseCodec


class EitaaMediaRepository:
    """Fetch photo/document chunks from configured Eitaa download endpoints."""

    def __init__(self, gateway: RpcGateway, diagnostics: DiagnosticManager | None = None) -> None:
        self.gateway = gateway
        self.diagnostics = diagnostics

    def fetch_chunk(
        self,
        media: RemoteMediaReference,
        *,
        offset: int,
        limit: int,
        method: MediaDownloadMethod,
        thumb_type: str | None = None,
        endpoint_index: int | None = None,
    ) -> MediaChunk:
        plan = MediaRequestCodec.build(
            media,
            offset=offset,
            limit=limit,
            method=method,
            thumb_type=thumb_type,
        )
        indexes = (
            [endpoint_index]
            if endpoint_index is not None
            else self._endpoint_order(media)
        )
        failures: list[dict[str, object]] = []
        for index in indexes:
            try:
                result = self.gateway.invoke(
                    plan.payload,
                    operation=f"media.download.{method.value}",
                    endpoint_role=EndpointRole.DOWNLOAD,
                    fallback_index=int(index),
                )
                chunk = MediaResponseCodec.parse(
                    result.body,
                    offset=offset,
                    requested_limit=limit,
                )
                chunk = chunk.with_transport(
                    endpoint=result.transport.endpoint,
                    endpoint_index=int(index),
                    method=method,
                    thumb_type=plan.thumb_type,
                    location_kind=plan.location_kind,
                    expected_size=plan.expected_size,
                )
                self._emit(
                    "chunk_fetched",
                    fields={
                        "media": media.safe_summary(),
                        "offset": offset,
                        "requested_limit": limit,
                        "received_length": len(chunk.data),
                        "method": method.value,
                        "endpoint_index": index,
                        "file_type": chunk.file_type,
                        "extension": chunk.extension,
                        "location_kind": plan.location_kind,
                        "thumb_type": plan.thumb_type,
                    },
                )
                return chunk
            except EitaaCoreError as exc:
                failures.append({
                    "endpoint_index": index,
                    "error_type": type(exc).__name__,
                    "rpc_code": getattr(exc, "code", None),
                })
        debug_file = self._emit(
            "chunk_fetch_failed",
            level="error",
            fields={
                "media": media.safe_summary(),
                "offset": offset,
                "requested_limit": limit,
                "method": method.value,
                "failure_count": len(failures),
                "failures": failures,
            },
        )
        raise MediaDownloadError(
            "No configured download endpoint returned a usable media chunk.",
            safe_context={
                "media_type": getattr(getattr(media, "type", None), "value", "peer_photo"),
                "offset": offset,
                "method": method.value,
                "failure_count": len(failures),
            },
            debug_file=debug_file,
        )

    def _endpoint_order(self, media: RemoteMediaReference) -> list[int]:
        count = len(self.gateway.config.download_endpoints)
        dc_id = getattr(media, "dc_id", None)
        preferred = dc_id - 1 if isinstance(dc_id, int) and 1 <= dc_id <= count else None
        return ([preferred] if preferred is not None else []) + [
            index for index in range(count) if index != preferred
        ]

    def _emit(self, event: str, *, level: str = "info", fields: dict[str, object]) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("media", event, level=level, fields=fields)

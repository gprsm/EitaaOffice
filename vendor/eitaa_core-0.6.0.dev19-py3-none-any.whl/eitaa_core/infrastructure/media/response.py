"""Parser for ``upload.file`` media responses."""

from __future__ import annotations

from ...domain.media import MediaChunk
from ...errors import MediaCdnRedirectError, UnexpectedConstructorError
from ..codec.tl import TLReader, hex_constructor
from . import constructors as c


class MediaResponseCodec:
    """Decode one RPC-normalized download response into a chunk."""

    @staticmethod
    def parse(data: bytes, *, offset: int, requested_limit: int) -> MediaChunk:
        reader = TLReader(data)
        constructor = reader.read_u32()
        if constructor == c.UPLOAD_FILE_CDN_REDIRECT:
            raise MediaCdnRedirectError(
                "Eitaa returned upload.fileCdnRedirect, which Core 5 does not follow yet.",
                safe_context={"offset": offset, "response_length": len(data)},
            )
        if constructor != c.UPLOAD_FILE:
            raise UnexpectedConstructorError(
                "Expected upload.file response.",
                safe_context={
                    "constructor": hex_constructor(constructor),
                    "response_length": len(data),
                },
            )
        file_type_constructor = reader.read_u32()
        modified_time = reader.read_i32()
        payload = reader.read_bytes()
        file_type, extension = c.STORAGE_FILE_TYPES.get(
            file_type_constructor,
            (f"unknown_{file_type_constructor:08x}", "bin"),
        )
        return MediaChunk(
            data=payload,
            offset=offset,
            requested_limit=requested_limit,
            file_type=file_type,
            extension=extension,
            modified_time=modified_time,
            file_type_constructor=file_type_constructor,
        )

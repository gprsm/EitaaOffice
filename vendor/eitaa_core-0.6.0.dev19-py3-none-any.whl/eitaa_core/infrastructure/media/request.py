"""Builders for Eitaa media download requests."""

from __future__ import annotations

from dataclasses import dataclass

from ...domain.enums import MediaDownloadMethod, MediaType
from ...domain.discovery import PeerPhotoReference
from ...domain.media import MediaReference, PhotoSizeReference, RemoteMediaReference
from ...errors import MediaValidationError
from ..codec.tl import TLWriter
from ..codec.peer import PeerCodec
from . import constructors as c


@dataclass(slots=True, frozen=True)
class MediaRequestPlan:
    """Resolved download method and location details safe for diagnostics."""

    payload: bytes
    method: MediaDownloadMethod
    thumb_type: str
    location_kind: str
    expected_size: int | None


def _require_remote_fields(media: MediaReference) -> None:
    missing = []
    if media.remote_id is None:
        missing.append("remote_id")
    if media.access_hash is None:
        missing.append("access_hash")
    if media.file_reference is None:
        missing.append("file_reference")
    if missing:
        raise MediaValidationError(
            "Media reference is incomplete for download.",
            safe_context={"media_type": media.type.value, "missing": missing},
        )


def _best_photo_size(media: MediaReference, requested: str | None) -> PhotoSizeReference | None:
    candidates = list(media.photo_sizes)
    if requested:
        exact = [item for item in candidates if item.type == requested]
        if exact:
            candidates = exact
    if not candidates:
        return None
    def score(item: PhotoSizeReference) -> tuple[int, int]:
        return (item.size or 0, (item.width or 0) * (item.height or 0))
    return max(candidates, key=score)


def _build_photo_location(media: MediaReference, thumb_type: str | None) -> tuple[bytes, str, str, int | None]:
    selected = _best_photo_size(media, thumb_type)
    if selected and selected.volume_id is not None and selected.local_id is not None:
        location = (
            TLWriter()
            .write_i32(c.INPUT_FILE_LOCATION)
            .write_i64(selected.volume_id)
            .write_i32(selected.local_id)
            .write_i64(selected.secret or 0)
            .write_bytes(media.file_reference or b"")
            .to_bytes()
        )
        return location, "inputFileLocation", selected.type or "", selected.size
    chosen_thumb = thumb_type
    if chosen_thumb is None:
        selected = _best_photo_size(media, None)
        chosen_thumb = selected.type if selected else ""
    location = (
        TLWriter()
        .write_i32(c.INPUT_PHOTO_FILE_LOCATION)
        .write_i64(media.remote_id or 0)
        .write_i64(media.access_hash or 0)
        .write_bytes(media.file_reference or b"")
        .write_string(chosen_thumb or "")
        .to_bytes()
    )
    return location, "inputPhotoFileLocation", chosen_thumb or "", selected.size if selected else None


def _build_document_location(media: MediaReference, thumb_type: str | None) -> tuple[bytes, str, str, int | None]:
    chosen_thumb = thumb_type or ""
    location = (
        TLWriter()
        .write_i32(c.INPUT_DOCUMENT_FILE_LOCATION)
        .write_i64(media.remote_id or 0)
        .write_i64(media.access_hash or 0)
        .write_bytes(media.file_reference or b"")
        .write_string(chosen_thumb)
        .to_bytes()
    )
    expected = media.size if not chosen_thumb else None
    return location, "inputDocumentFileLocation", chosen_thumb, expected


class MediaRequestCodec:
    """Serialize ``upload.getFile`` and Eitaa's ``upload.getFile2``."""

    @staticmethod
    def build(
        media: RemoteMediaReference,
        *,
        offset: int,
        limit: int,
        method: MediaDownloadMethod,
        thumb_type: str | None = None,
        precise: bool = False,
        cdn_supported: bool = True,
    ) -> MediaRequestPlan:
        """Build one chunk request after validating offsets and media fields."""
        if offset < 0:
            raise MediaValidationError("Media offset cannot be negative.")
        if not 1 <= limit <= 1024 * 1024:
            raise MediaValidationError(
                "Media chunk limit must be between 1 byte and 1 MiB.",
                safe_context={"limit": limit},
            )
        if method is MediaDownloadMethod.AUTO:
            raise MediaValidationError("AUTO must be resolved before request serialization.")
        if isinstance(media, PeerPhotoReference):
            wants_big = (thumb_type or "small").lower() in {"big", "large", "x"}
            selected = media.big if wants_big else media.small
            chosen_thumb = "big" if wants_big else "small"
            if selected and selected.volume_id is not None and selected.local_id is not None:
                # Eitaa layer 135 still serves dialog avatars through its
                # legacy inputFileLocation extension. The modern peer-photo
                # location is retained below for responses without a legacy
                # volume/local pair.
                location = (
                    TLWriter().write_i32(c.INPUT_FILE_LOCATION)
                    .write_i64(selected.volume_id).write_i32(selected.local_id)
                    .write_i64(selected.secret or 0).write_bytes(b"").to_bytes()
                )
                kind = "inputFileLocation(dialogPhoto)"
            else:
                location = (
                    TLWriter()
                    .write_i32(c.INPUT_PEER_PHOTO_FILE_LOCATION)
                    .write_i32(1 if wants_big else 0)
                    .write_raw(PeerCodec.encode_input_peer(media.peer))
                    .write_i64(media.photo_id)
                    .to_bytes()
                )
                kind = "inputPeerPhotoFileLocation"
            expected = None
        else:
            _require_remote_fields(media)
        if not isinstance(media, PeerPhotoReference) and media.type is MediaType.PHOTO:
            location, kind, chosen_thumb, expected = _build_photo_location(media, thumb_type)
        elif not isinstance(media, PeerPhotoReference):
            location, kind, chosen_thumb, expected = _build_document_location(media, thumb_type)
        writer = TLWriter()
        if method is MediaDownloadMethod.GET_FILE2:
            writer.write_i32(c.UPLOAD_GET_FILE2).write_raw(location).write_i32(offset).write_i32(limit)
        elif method is MediaDownloadMethod.GET_FILE:
            flags = (1 if precise else 0) | (2 if cdn_supported else 0)
            writer.write_i32(c.UPLOAD_GET_FILE).write_i32(flags).write_raw(location).write_i32(offset).write_i32(limit)
        else:
            raise MediaValidationError(
                "Unsupported media download method.",
                safe_context={"method": str(method)},
            )
        return MediaRequestPlan(writer.to_bytes(), method, chosen_thumb, kind, expected)

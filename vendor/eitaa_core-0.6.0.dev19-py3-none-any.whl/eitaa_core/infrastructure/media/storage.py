"""Atomic local media storage with Windows-safe file names."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from ...errors import MediaStorageError
from ..diagnostics import DiagnosticManager

_INVALID_WINDOWS = re.compile(r'[<>:"/\|?*\x00-\x1f]')
_RESERVED_WINDOWS = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


def sanitize_file_name(value: str, *, fallback: str = "media") -> str:
    """Return a portable file name without directory traversal components."""
    name = Path(value or "").name
    name = _INVALID_WINDOWS.sub("_", name).strip().strip(".")
    if not name:
        name = fallback
    stem = Path(name).stem
    if stem.upper() in _RESERVED_WINDOWS:
        name = f"_{name}"
    return name[:180]


@dataclass(slots=True)
class PendingMediaFile:
    """One partially written file owned by :class:`LocalMediaStorage`."""

    partial_path: Path
    base_name: str
    overwrite: bool
    bytes_written: int = 0


class LocalMediaStorage:
    """Create ``.partial`` files and atomically rename completed downloads."""

    def __init__(self, diagnostics: DiagnosticManager | None = None) -> None:
        self.diagnostics = diagnostics

    def prepare(self, directory: Path, preferred_name: str, *, overwrite: bool) -> PendingMediaFile:
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        safe = sanitize_file_name(preferred_name)
        partial = directory / f".{safe}.partial"
        if partial.exists():
            partial.unlink()
        partial.touch()
        self._emit(
            "partial_prepared",
            fields={
                "directory": str(directory),
                "file_name_length": len(safe),
                "file_extension": Path(safe).suffix.lower(),
            },
        )
        return PendingMediaFile(partial, safe, overwrite)

    def append(self, pending: PendingMediaFile, data: bytes) -> None:
        try:
            with pending.partial_path.open("ab") as handle:
                handle.write(data)
            pending.bytes_written += len(data)
        except OSError as exc:
            debug = self._emit(
                "append_failed",
                level="error",
                fields={"path": str(pending.partial_path), "error_type": type(exc).__name__},
            )
            raise MediaStorageError(
                "Could not write downloaded media bytes.",
                safe_context={"path": str(pending.partial_path), "error_type": type(exc).__name__},
                debug_file=debug,
            ) from exc

    def finalize(self, pending: PendingMediaFile, *, extension: str | None) -> Path:
        extension = (extension or "bin").lower().lstrip(".")
        base = sanitize_file_name(pending.base_name)
        suffix = Path(base).suffix.lower().lstrip(".")
        final_name = base if suffix else f"{base}.{extension}"
        final = pending.partial_path.parent / final_name
        if final.exists() and not pending.overwrite:
            pending.partial_path.unlink(missing_ok=True)
            raise MediaStorageError(
                "Destination media file already exists.",
                safe_context={"path": str(final), "overwrite": False},
            )
        if final.exists():
            final.unlink()
        try:
            pending.partial_path.replace(final)
        except OSError as exc:
            debug = self._emit(
                "finalize_failed",
                level="error",
                fields={"path": str(final), "error_type": type(exc).__name__},
            )
            raise MediaStorageError(
                "Could not finalize the downloaded media file.",
                safe_context={"path": str(final), "error_type": type(exc).__name__},
                debug_file=debug,
            ) from exc
        self._emit(
            "media_finalized",
            fields={
                "directory": str(final.parent),
                "file_name_length": len(final.name),
                "file_extension": final.suffix.lower(),
                "bytes_written": pending.bytes_written,
            },
        )
        return final

    def abort(self, pending: PendingMediaFile, *, keep_nonempty: bool = True) -> Path | None:
        if not pending.partial_path.exists():
            return None
        if keep_nonempty and pending.partial_path.stat().st_size > 0:
            return pending.partial_path
        pending.partial_path.unlink(missing_ok=True)
        return None

    def _emit(self, event: str, *, level: str = "info", fields: dict[str, object]) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("media_storage", event, level=level, fields=fields)

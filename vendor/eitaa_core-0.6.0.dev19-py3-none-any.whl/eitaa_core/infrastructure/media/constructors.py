"""TL constructors used by native media downloads."""

INPUT_FILE_LOCATION = 0xDFDAABE1
INPUT_PHOTO_FILE_LOCATION = 0x40181FFE
INPUT_DOCUMENT_FILE_LOCATION = 0xBAD07584
INPUT_PEER_PHOTO_FILE_LOCATION = 0x37257E99
UPLOAD_GET_FILE = 0xB15A9AFC
UPLOAD_GET_FILE2 = 0xE3A6CFB5
UPLOAD_FILE = 0x096A18D5
UPLOAD_FILE_CDN_REDIRECT = 0xF18CDA44

STORAGE_FILE_TYPES: dict[int, tuple[str, str]] = {
    0xAA963B05: ("unknown", "bin"),
    1086091090: ("partial", "part"),
    8322574: ("jpeg", "jpg"),
    0xCAD181F6: ("gif", "gif"),
    172975040: ("png", "png"),
    0xAE1E508D: ("pdf", "pdf"),
    1384777335: ("mp3", "mp3"),
    1258941372: ("mov", "mov"),
    0xB3CEA0E4: ("mp4", "mp4"),
    276907596: ("webp", "webp"),
}

"""Infrastructure adapters. Frontends should normally use :mod:`eitaa_core`."""

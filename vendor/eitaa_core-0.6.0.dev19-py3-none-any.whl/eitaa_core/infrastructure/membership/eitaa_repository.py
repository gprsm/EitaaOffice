"""RPC-backed reversible membership repository."""

from __future__ import annotations

from ...application.gateway import RpcGateway
from ...domain.enums import EndpointRole, PeerType
from ...domain.membership import MembershipCheckResult, MembershipMutationResult
from ...domain.peer import Peer
from ...errors import EitaaCoreError, RpcError
from ...infrastructure.diagnostics import DiagnosticManager
from ...ports.membership_repository import MembershipRepository
from .codec import MembershipCodec


_NOT_MEMBER_ERRORS = {
    "USER_NOT_PARTICIPANT",
    "PARTICIPANT_ID_INVALID",
}


class EitaaMembershipRepository(MembershipRepository):
    """Execute invitation and reversible removal through the shared gateway."""

    def __init__(
        self, gateway: RpcGateway, diagnostics: DiagnosticManager | None = None
    ) -> None:
        self.gateway = gateway
        self.diagnostics = diagnostics

    def check_member(self, target: Peer, user: Peer) -> MembershipCheckResult:
        if target.type is not PeerType.CHANNEL:
            raise ValueError("Remote per-user check is only available for channel peers.")
        try:
            rpc = self.gateway.invoke(
                MembershipCodec.build_get_participant(target, user),
                operation="channels.getParticipant",
                endpoint_role=EndpointRole.API,
            )
            result = MembershipCodec.parse_check_result(rpc.body)
        except RpcError as exc:
            text = exc.text.upper()
            if any(code in text for code in _NOT_MEMBER_ERRORS):
                result = MembershipCheckResult(
                    is_member=False,
                    response_type="rpc.user_not_participant",
                )
            else:
                self._attach(exc, "membership_check_failed", target, user)
                raise
        except EitaaCoreError as exc:
            self._attach(exc, "membership_check_failed", target, user)
            raise
        self._emit(
            "membership_check_completed",
            fields={
                "target": target.safe_summary(),
                "user": user.safe_summary(),
                **result.safe_summary(),
            },
        )
        return result

    def add_member(
        self, target: Peer, user: Peer, *, fwd_limit: int = 0
    ) -> MembershipMutationResult:
        operation = (
            "channels.inviteToChannel"
            if target.type is PeerType.CHANNEL
            else "messages.addChatUser"
        )
        try:
            rpc = self.gateway.invoke(
                MembershipCodec.build_add_member(target, user, fwd_limit=fwd_limit),
                operation=operation,
                endpoint_role=EndpointRole.API,
            )
            result = MembershipCodec.parse_mutation_result(
                rpc.body, operation=operation
            )
        except EitaaCoreError as exc:
            self._attach(exc, "membership_add_failed", target, user)
            raise
        self._emit(
            "membership_add_completed",
            fields={
                "target": target.safe_summary(),
                "user": user.safe_summary(),
                **result.safe_summary(),
            },
        )
        return result

    def remove_member(
        self,
        target: Peer,
        user: Peer,
        *,
        revoke_history: bool = False,
        release_channel_ban: bool = True,
    ) -> MembershipMutationResult:
        operation = (
            "channels.editBanned.kick"
            if target.type is PeerType.CHANNEL
            else "messages.deleteChatUser"
        )
        try:
            rpc = self.gateway.invoke(
                MembershipCodec.build_remove_member(
                    target, user, revoke_history=revoke_history
                ),
                operation=operation,
                endpoint_role=EndpointRole.API,
            )
            first = MembershipCodec.parse_mutation_result(
                rpc.body,
                operation=operation,
                ban_released=(False if target.type is PeerType.CHANNEL else None),
            )
            if target.type is PeerType.CHANNEL and release_channel_ban:
                try:
                    unban_rpc = self.gateway.invoke(
                        MembershipCodec.build_channel_ban(target, user, ban=False),
                        operation="channels.editBanned.release",
                        endpoint_role=EndpointRole.API,
                    )
                    result = MembershipCodec.parse_mutation_result(
                        unban_rpc.body,
                        operation="channels.editBanned.release",
                        ban_released=True,
                    )
                except EitaaCoreError as exc:
                    # Removal already succeeded. Return a partial result so the
                    # application can report that the user remains restricted.
                    self._emit(
                        "membership_release_ban_failed",
                        level="warning",
                        fields={
                            "target": target.safe_summary(),
                            "user": user.safe_summary(),
                            "error_type": type(exc).__name__,
                        },
                    )
                    result = MembershipMutationResult(
                        accepted=first.accepted,
                        response_type="removed_but_release_failed",
                        ban_released=False,
                    )
            else:
                result = first
        except EitaaCoreError as exc:
            self._attach(exc, "membership_remove_failed", target, user)
            raise
        self._emit(
            "membership_remove_completed",
            fields={
                "target": target.safe_summary(),
                "user": user.safe_summary(),
                **result.safe_summary(),
            },
        )
        return result

    def _attach(
        self, error: EitaaCoreError, event: str, target: Peer, user: Peer
    ) -> None:
        debug_file = self._emit(
            event,
            level="error",
            fields={
                "target": target.safe_summary(),
                "user": user.safe_summary(),
                "error_type": type(error).__name__,
            },
        )
        if not error.debug_file:
            error.debug_file = debug_file

    def _emit(
        self,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit(
            "membership", event, level=level, fields=fields
        )

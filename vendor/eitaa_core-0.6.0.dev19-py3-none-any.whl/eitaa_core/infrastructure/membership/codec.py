"""TL serializer/parser for reversible membership invitation operations."""

from __future__ import annotations

from ...domain.enums import PeerType
from ...domain.membership import (
    MembershipCheckResult,
    MembershipMutationResult,
)
from ...domain.peer import Peer
from ...errors import DomainValidationError, UnexpectedConstructorError
from ..codec.peer import PeerCodec
from ..codec.tl import TLReader, TLWriter, hex_constructor
from ..send.constructors import SUCCESS_UPDATE_CONSTRUCTORS
from . import constructors as c


class MembershipCodec:
    """Build Core 7.4 membership RPC requests and classify safe responses."""

    @staticmethod
    def build_get_participant(target: Peer, user: Peer) -> bytes:
        MembershipCodec._require_channel(target)
        MembershipCodec._require_user(user)
        return (
            TLWriter()
            .write_i32(c.CHANNELS_GET_PARTICIPANT)
            .write_raw(MembershipCodec._input_channel(target))
            .write_raw(PeerCodec.encode_input_peer(user))
            .to_bytes()
        )

    @staticmethod
    def build_add_member(target: Peer, user: Peer, *, fwd_limit: int = 0) -> bytes:
        MembershipCodec._require_user(user)
        if not 0 <= fwd_limit <= 100:
            raise DomainValidationError(
                "fwd_limit must be between 0 and 100.",
                safe_context={"fwd_limit": fwd_limit},
            )
        if target.type is PeerType.CHANNEL:
            return (
                TLWriter()
                .write_i32(c.CHANNELS_INVITE_TO_CHANNEL)
                .write_raw(MembershipCodec._input_channel(target))
                .write_vector([PeerCodec.encode_input_user(user)])
                .to_bytes()
            )
        if target.type is PeerType.CHAT:
            target.validate()
            return (
                TLWriter()
                .write_i32(c.MESSAGES_ADD_CHAT_USER)
                .write_i64(target.id)
                .write_raw(PeerCodec.encode_input_user(user))
                .write_i32(fwd_limit)
                .to_bytes()
            )
        raise DomainValidationError(
            "Membership target must be a basic group, supergroup, or channel.",
            safe_context={"peer_type": target.type.value},
        )

    @staticmethod
    def build_remove_member(
        target: Peer,
        user: Peer,
        *,
        revoke_history: bool = False,
    ) -> bytes:
        MembershipCodec._require_user(user)
        if target.type is PeerType.CHAT:
            target.validate()
            return (
                TLWriter()
                .write_i32(c.MESSAGES_DELETE_CHAT_USER)
                .write_i32(1 if revoke_history else 0)
                .write_i64(target.id)
                .write_raw(PeerCodec.encode_input_user(user))
                .to_bytes()
            )
        if target.type is PeerType.CHANNEL:
            return MembershipCodec.build_channel_ban(target, user, ban=True)
        raise DomainValidationError(
            "Membership target must be a basic group, supergroup, or channel.",
            safe_context={"peer_type": target.type.value},
        )

    @staticmethod
    def build_channel_ban(target: Peer, user: Peer, *, ban: bool) -> bytes:
        MembershipCodec._require_channel(target)
        MembershipCodec._require_user(user)
        # view_messages=true removes/kicks the participant. Empty rights release
        # the ban while keeping the user outside the channel/supergroup.
        rights_flags = 1 if ban else 0
        rights = (
            TLWriter()
            .write_i32(c.CHAT_BANNED_RIGHTS)
            .write_i32(rights_flags)
            .write_i32(0)
            .to_bytes()
        )
        return (
            TLWriter()
            .write_i32(c.CHANNELS_EDIT_BANNED)
            .write_raw(MembershipCodec._input_channel(target))
            .write_raw(PeerCodec.encode_input_peer(user))
            .write_raw(rights)
            .to_bytes()
        )

    @staticmethod
    def parse_check_result(data: bytes) -> MembershipCheckResult:
        reader = TLReader(data)
        constructor = reader.read_u32()
        if constructor != c.CHANNELS_CHANNEL_PARTICIPANT:
            raise UnexpectedConstructorError(
                "Expected channels.channelParticipant.",
                safe_context={
                    "actual_constructor": hex_constructor(constructor),
                    "response_length": len(data),
                },
            )
        return MembershipCheckResult(
            is_member=True,
            response_type="channels.channelParticipant",
        )

    @staticmethod
    def parse_mutation_result(
        data: bytes,
        *,
        operation: str,
        ban_released: bool | None = None,
    ) -> MembershipMutationResult:
        reader = TLReader(data)
        constructor = reader.read_u32()
        response_type = SUCCESS_UPDATE_CONSTRUCTORS.get(constructor)
        if response_type is None:
            raise UnexpectedConstructorError(
                "Unsupported membership mutation response constructor.",
                safe_context={
                    "operation": operation,
                    "actual_constructor": hex_constructor(constructor),
                    "response_length": len(data),
                },
            )
        return MembershipMutationResult(
            accepted=True,
            response_type=response_type,
            ban_released=ban_released,
        )

    @staticmethod
    def _input_channel(peer: Peer) -> bytes:
        MembershipCodec._require_channel(peer)
        assert peer.access_hash is not None
        return (
            TLWriter()
            .write_i32(c.INPUT_CHANNEL)
            .write_i64(peer.id)
            .write_i64(peer.access_hash)
            .to_bytes()
        )

    @staticmethod
    def _require_channel(peer: Peer) -> None:
        if peer.type is not PeerType.CHANNEL:
            raise DomainValidationError(
                "This operation requires a channel or supergroup peer.",
                safe_context={"peer_type": peer.type.value},
            )
        peer.validate()

    @staticmethod
    def _require_user(peer: Peer) -> None:
        if peer.type is not PeerType.USER:
            raise DomainValidationError(
                "Membership recipient must be a user peer.",
                safe_context={"peer_type": peer.type.value},
            )
        peer.validate()

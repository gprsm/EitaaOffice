"""Deterministic TL serializer/parser for outbound operations.

The photo request intentionally matches the successful Eitaa Web capture used
by alpha15.4: media flags 136, an empty entities vector, ``photo.jpeg`` for a
small photo upload, and an empty MD5 field in ``inputFile``.
"""

from __future__ import annotations

from ...domain.enums import SendKind
from ...domain.peer import Peer
from ...domain.send import MessageDeleteResult, SendResult, UploadedFile
from ...errors import SendResponseError, UnexpectedConstructorError
from ..codec.constructors import BOOL_FALSE, BOOL_TRUE
from ..codec.peer import PeerCodec
from ..codec.tl import TLReader, TLWriter, hex_constructor
from .constructors import (
    DOCUMENT_ATTRIBUTE_FILENAME,
    INPUT_FILE,
    INPUT_FILE_BIG,
    INPUT_MEDIA_UPLOADED_DOCUMENT,
    INPUT_MEDIA_UPLOADED_PHOTO,
    MESSAGES_AFFECTED_MESSAGES,
    MESSAGES_DELETE_MESSAGES,
    MESSAGES_SEND_MEDIA,
    MESSAGES_SEND_MESSAGE,
    SUCCESS_UPDATE_CONSTRUCTORS,
    UPDATE_MESSAGE_ID,
    UPDATE_SHORT_SENT_MESSAGE,
    UPLOAD_SAVE_BIG_FILE_PART,
    UPLOAD_SAVE_FILE_PART,
)


class SendCodec:
    """Build and parse Core 5 outbound TL methods."""

    @staticmethod
    def build_send_text(peer: Peer, text: str, *, random_id: int) -> bytes:
        """Build ``messages.sendMessage`` with no optional fields."""
        return (
            TLWriter()
            .write_i32(MESSAGES_SEND_MESSAGE)
            .write_i32(0)
            .write_raw(PeerCodec.encode_input_peer(peer))
            .write_string(text)
            .write_i64(random_id)
            .to_bytes()
        )

    @staticmethod
    def build_upload_part(
        peer: Peer,
        *,
        file_id: int,
        part_index: int,
        total_parts: int,
        total_size: int,
        chunk: bytes,
        big: bool,
    ) -> bytes:
        """Build Eitaa's extended upload part request.

        Eitaa Web sets both optional bits after the bytes field: bit 0 includes
        the access-hash-free destination ``Peer`` and bit 1 includes the total
        file size.  ``saveBigFilePart`` additionally carries total part count.
        """
        writer = TLWriter().write_i32(
            UPLOAD_SAVE_BIG_FILE_PART if big else UPLOAD_SAVE_FILE_PART
        )
        writer.write_i64(file_id).write_i32(part_index)
        if big:
            writer.write_i32(total_parts)
        return (
            writer.write_bytes(chunk)
            .write_i32(3)
            .write_raw(PeerCodec.encode_upload_peer(peer))
            .write_i64(total_size)
            .to_bytes()
        )

    @staticmethod
    def build_send_photo(
        peer: Peer,
        uploaded: UploadedFile,
        caption: str,
        *,
        random_id: int,
    ) -> bytes:
        uploaded.validate()
        input_file = SendCodec._input_file(uploaded)
        media = (
            TLWriter()
            .write_i32(INPUT_MEDIA_UPLOADED_PHOTO)
            .write_i32(0)
            .write_raw(input_file)
            .to_bytes()
        )
        return SendCodec._send_media(peer, media, caption, random_id=random_id)

    @staticmethod
    def build_send_file(
        peer: Peer,
        uploaded: UploadedFile,
        caption: str,
        *,
        mime_type: str,
        original_name: str,
        random_id: int,
    ) -> bytes:
        uploaded.validate()
        attribute = (
            TLWriter()
            .write_i32(DOCUMENT_ATTRIBUTE_FILENAME)
            .write_string(original_name)
            .to_bytes()
        )
        media = (
            TLWriter()
            .write_i32(INPUT_MEDIA_UPLOADED_DOCUMENT)
            .write_i32(1 << 4)  # force_file
            .write_raw(SendCodec._input_file(uploaded))
            .write_string(mime_type)
            .write_vector([attribute])
            .to_bytes()
        )
        return SendCodec._send_media(peer, media, caption, random_id=random_id)

    @staticmethod
    def _input_file(uploaded: UploadedFile) -> bytes:
        writer = TLWriter().write_i32(INPUT_FILE_BIG if uploaded.big else INPUT_FILE)
        writer.write_i64(uploaded.file_id).write_i32(uploaded.parts).write_string(
            uploaded.remote_name
        )
        if not uploaded.big:
            # Web-compatible request: currently an empty md5_checksum string.
            writer.write_string("")
        return writer.to_bytes()

    @staticmethod
    def _send_media(peer: Peer, media: bytes, caption: str, *, random_id: int) -> bytes:
        # bit 3 = entities and bit 7 = clear_draft.  The entities vector is
        # present even when empty, matching the successful web request.
        return (
            TLWriter()
            .write_i32(MESSAGES_SEND_MEDIA)
            .write_i32((1 << 3) | (1 << 7))
            .write_raw(PeerCodec.encode_input_peer(peer))
            .write_raw(media)
            .write_string(caption)
            .write_i64(random_id)
            .write_vector([])
            .to_bytes()
        )

    @staticmethod
    def build_delete_messages(message_ids: tuple[int, ...], *, revoke: bool) -> bytes:
        """Build ``messages.deleteMessages`` for private/user chats."""
        if not message_ids:
            raise ValueError("At least one message id is required for deletion.")
        if len(message_ids) > 100:
            raise ValueError("At most 100 message ids may be deleted in one request.")
        items = [TLWriter().write_i32(message_id).to_bytes() for message_id in message_ids]
        return (
            TLWriter()
            .write_i32(MESSAGES_DELETE_MESSAGES)
            .write_i32(1 if revoke else 0)
            .write_vector(items)
            .to_bytes()
        )

    @staticmethod
    def parse_bool(data: bytes) -> bool:
        """Parse the Bool response of one upload part."""
        reader = TLReader(data)
        constructor = reader.read_u32()
        if constructor == BOOL_TRUE:
            return True
        if constructor == BOOL_FALSE:
            return False
        raise UnexpectedConstructorError(
            "Upload part response is not a TL Bool.",
            safe_context={
                "actual_constructor": hex_constructor(constructor),
                "response_length": len(data),
            },
        )

    @staticmethod
    def parse_send_result(
        data: bytes,
        *,
        kind: SendKind,
        peer: Peer,
        uploaded: UploadedFile | None = None,
        random_id: int | None = None,
    ) -> SendResult:
        """Normalize known successful send response constructors.

        ``updateShortSentMessage`` exposes the new message id directly.  Full
        ``updates`` responses are accepted without deeply parsing their update
        vector; a later sync can retrieve the canonical message if needed.
        """
        reader = TLReader(data)
        constructor = reader.read_u32()
        if constructor == UPDATE_SHORT_SENT_MESSAGE:
            flags = reader.read_i32()
            message_id = reader.read_i32()
            pts = reader.read_i32()
            pts_count = reader.read_i32()
            date = reader.read_i32()
            return SendResult.from_server_timestamp(
                kind=kind,
                peer=peer,
                accepted=True,
                response_constructor=hex_constructor(constructor),
                response_type="updateShortSentMessage",
                message_id=message_id,
                pts=pts,
                pts_count=pts_count,
                server_timestamp=date,
                uploaded=uploaded,
            )
        response_type = SUCCESS_UPDATE_CONSTRUCTORS.get(constructor)
        if response_type:
            message_id = SendCodec._extract_message_id_for_random_id(data, random_id)
            return SendResult.from_server_timestamp(
                kind=kind,
                peer=peer,
                accepted=True,
                response_constructor=hex_constructor(constructor),
                response_type=response_type,
                message_id=message_id,
                uploaded=uploaded,
            )
        raise SendResponseError(
            "Unsupported successful-send response constructor.",
            safe_context={
                "constructor": hex_constructor(constructor),
                "response_length": len(data),
                "send_kind": kind.value,
            },
        )
    @staticmethod
    def parse_delete_result(
        data: bytes, *, message_count: int, revoke: bool
    ) -> MessageDeleteResult:
        reader = TLReader(data)
        constructor = reader.read_u32()
        if constructor != MESSAGES_AFFECTED_MESSAGES:
            raise SendResponseError(
                "Unsupported delete-messages response constructor.",
                safe_context={
                    "constructor": hex_constructor(constructor),
                    "response_length": len(data),
                },
            )
        pts = reader.read_i32()
        pts_count = reader.read_i32()
        return MessageDeleteResult(
            accepted=True,
            response_constructor=hex_constructor(constructor),
            response_type="messages.affectedMessages",
            message_count=message_count,
            revoke=revoke,
            pts=pts,
            pts_count=pts_count,
        )

    @staticmethod
    def _extract_message_id_for_random_id(
        data: bytes, random_id: int | None
    ) -> int | None:
        """Find fixed-width ``updateMessageID`` matching the request random id."""
        if random_id is None:
            return None
        marker = int(UPDATE_MESSAGE_ID).to_bytes(4, "little", signed=False)
        start = 0
        while True:
            index = data.find(marker, start)
            if index < 0:
                return None
            if index + 16 <= len(data):
                message_id = int.from_bytes(data[index + 4:index + 8], "little", signed=True)
                candidate_random = int.from_bytes(
                    data[index + 8:index + 16], "little", signed=True
                )
                if candidate_random == random_id and message_id > 0:
                    return message_id
            start = index + 1


"""RPC-backed implementation of the outbound send repository."""

from __future__ import annotations

from ...application.gateway import RpcGateway
from ...domain.enums import EndpointRole, SendKind
from ...domain.peer import Peer
from ...domain.send import MessageDeleteResult, SendResult, UploadedFile
from ...errors import EitaaCoreError
from ...infrastructure.diagnostics import DiagnosticManager
from ...ports.send_repository import SendRepository
from .codec import SendCodec


class EitaaSendRepository(SendRepository):
    """Execute text, upload, photo, and document methods through RpcGateway."""

    def __init__(
        self,
        gateway: RpcGateway,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.gateway = gateway
        self.diagnostics = diagnostics

    def upload_part(
        self,
        peer: Peer,
        *,
        file_id: int,
        part_index: int,
        total_parts: int,
        total_size: int,
        chunk: bytes,
        big: bool,
    ) -> bool:
        try:
            result = self.gateway.invoke(
                SendCodec.build_upload_part(
                    peer,
                    file_id=file_id,
                    part_index=part_index,
                    total_parts=total_parts,
                    total_size=total_size,
                    chunk=chunk,
                    big=big,
                ),
                operation=(
                    "upload.saveBigFilePart" if big else "upload.saveFilePart"
                ),
                endpoint_role=EndpointRole.MEDIA,
            )
            ok = SendCodec.parse_bool(result.body)
        except EitaaCoreError as exc:
            self._attach_error(
                exc,
                "upload_part_failed",
                {
                    "part_index": part_index,
                    "total_parts": total_parts,
                    "total_size": total_size,
                    "chunk_length": len(chunk),
                    "big": big,
                },
                component="upload",
            )
            raise
        self._emit(
            "upload",
            "upload_part_completed",
            fields={
                "part_index": part_index,
                "total_parts": total_parts,
                "chunk_length": len(chunk),
                "big": big,
                "ok": ok,
            },
        )
        return ok

    def send_text(self, peer: Peer, text: str, *, random_id: int) -> SendResult:
        return self._send(
            SendCodec.build_send_text(peer, text, random_id=random_id),
            operation="messages.sendMessage",
            kind=SendKind.TEXT,
            peer=peer,
            random_id=random_id,
        )

    def send_photo(
        self,
        peer: Peer,
        uploaded: UploadedFile,
        caption: str,
        *,
        random_id: int,
    ) -> SendResult:
        return self._send(
            SendCodec.build_send_photo(
                peer, uploaded, caption, random_id=random_id
            ),
            operation="messages.sendMedia.photo",
            kind=SendKind.PHOTO,
            peer=peer,
            uploaded=uploaded,
            random_id=random_id,
        )

    def send_file(
        self,
        peer: Peer,
        uploaded: UploadedFile,
        caption: str,
        *,
        mime_type: str,
        original_name: str,
        random_id: int,
    ) -> SendResult:
        return self._send(
            SendCodec.build_send_file(
                peer,
                uploaded,
                caption,
                mime_type=mime_type,
                original_name=original_name,
                random_id=random_id,
            ),
            operation="messages.sendMedia.document",
            kind=SendKind.FILE,
            peer=peer,
            uploaded=uploaded,
            random_id=random_id,
        )

    def delete_messages(
        self, message_ids: tuple[int, ...], *, revoke: bool
    ) -> MessageDeleteResult:
        try:
            rpc = self.gateway.invoke(
                SendCodec.build_delete_messages(message_ids, revoke=revoke),
                operation="messages.deleteMessages",
                endpoint_role=EndpointRole.API,
            )
            result = SendCodec.parse_delete_result(
                rpc.body, message_count=len(message_ids), revoke=revoke
            )
        except EitaaCoreError as exc:
            self._attach_error(
                exc,
                "delete_messages_failed",
                {"message_count": len(message_ids), "revoke": revoke},
                component="send",
            )
            raise
        self._emit("send", "delete_messages_completed", fields=result.safe_summary())
        return result

    def _send(
        self,
        packed: bytes,
        *,
        operation: str,
        kind: SendKind,
        peer: Peer,
        uploaded: UploadedFile | None = None,
        random_id: int | None = None,
    ) -> SendResult:
        try:
            rpc = self.gateway.invoke(
                packed,
                operation=operation,
                endpoint_role=(
                    EndpointRole.API if kind is SendKind.TEXT else EndpointRole.MEDIA
                ),
            )
            result = SendCodec.parse_send_result(
                rpc.body, kind=kind, peer=peer, uploaded=uploaded, random_id=random_id
            )
        except EitaaCoreError as exc:
            self._attach_error(
                exc,
                "send_request_failed",
                {
                    "kind": kind.value,
                    "peer": peer.safe_summary(),
                    "uploaded": uploaded.safe_summary() if uploaded else None,
                },
                component="send",
            )
            raise
        self._emit(
            "send",
            "send_request_completed",
            fields=result.safe_summary(),
        )
        return result

    def _attach_error(
        self,
        error: EitaaCoreError,
        event: str,
        fields: dict[str, object],
        *,
        component: str,
    ) -> None:
        debug_file = self._emit(
            component, event, level="error", fields={**fields, "error_type": type(error).__name__}
        )
        if not error.debug_file:
            error.debug_file = debug_file

    def _emit(
        self,
        component: str,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit(component, event, level=level, fields=fields)

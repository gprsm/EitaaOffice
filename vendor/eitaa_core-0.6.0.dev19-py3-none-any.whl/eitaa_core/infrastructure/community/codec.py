"""Deterministic TL codec for member listing, administrators, and search."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from ...domain.community import CommunityMember, MemberPage
from ...domain.enums import MemberRemoteFilter, MemberRole, MemberState, PeerType
from ...domain.peer import Peer
from ...domain.user import User
from ...errors import DomainValidationError, TLDecodeError, UnexpectedConstructorError
from ..codec.constructors import BOOL_FALSE, BOOL_TRUE, VECTOR
from ..codec.peer import PeerCodec
from ..codec.tl import TLReader, TLWriter, hex_constructor
from ..contacts.codec import ContactsCodec
from ..discovery.codec import DiscoveryCodec
from ..history.media_codec import _parse_photo
from . import constructors as c


@dataclass(slots=True)
class _ParticipantRow:
    user_id: int
    role: MemberRole
    state: MemberState
    joined_at: datetime | None = None
    inviter_id: int | None = None
    promoted_by: int | None = None
    rank: str | None = None
    can_edit: bool = False


def _timestamp(value: int) -> datetime | None:
    try:
        return datetime.fromtimestamp(value, timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


class CommunityCodec:
    """Pure request builders and conservative response parsers."""

    @staticmethod
    def build_get_participants(
        community: Peer,
        *,
        filter: MemberRemoteFilter = MemberRemoteFilter.RECENT,
        query: str = "",
        offset: int = 0,
        limit: int = 100,
        hash_value: int = 0,
    ) -> bytes:
        if community.type is not PeerType.CHANNEL:
            raise DomainValidationError(
                "channels.getParticipants requires a channel or supergroup peer.",
                safe_context={"peer_type": community.type.value},
            )
        community.validate()
        if offset < 0 or not 1 <= limit <= 200:
            raise DomainValidationError(
                "Participant offset/limit is outside the supported range.",
                safe_context={"offset": offset, "limit": limit},
            )
        return (
            TLWriter()
            .write_i32(c.CHANNELS_GET_PARTICIPANTS)
            .write_raw(CommunityCodec._input_channel(community))
            .write_raw(CommunityCodec._filter(filter, query))
            .write_i32(offset)
            .write_i32(limit)
            .write_i64(hash_value)
            .to_bytes()
        )

    @staticmethod
    def build_get_participant(community: Peer, member: Peer) -> bytes:
        if community.type is not PeerType.CHANNEL:
            raise DomainValidationError("channels.getParticipant requires a channel peer.")
        return (
            TLWriter()
            .write_i32(c.CHANNELS_GET_PARTICIPANT)
            .write_raw(CommunityCodec._input_channel(community))
            .write_raw(PeerCodec.encode_input_peer(member))
            .to_bytes()
        )

    @staticmethod
    def build_get_full_chat(community: Peer) -> bytes:
        if community.type is not PeerType.CHAT:
            raise DomainValidationError("messages.getFullChat requires a basic chat peer.")
        return (
            TLWriter()
            .write_i32(c.MESSAGES_GET_FULL_CHAT)
            .write_i64(community.id)
            .to_bytes()
        )

    @staticmethod
    def parse_channel_participants(
        data: bytes,
        *,
        community: Peer,
        offset: int,
        limit: int,
    ) -> MemberPage:
        reader = TLReader(data)
        top = reader.read_u32()
        if top == c.CHANNELS_CHANNEL_PARTICIPANTS_NOT_MODIFIED:
            CommunityCodec._require_end(reader, "channels.channelParticipantsNotModified")
            return MemberPage(
                community=community,
                members=(),
                total_count=0,
                offset=offset,
                limit=limit,
                response_type="channels.channelParticipantsNotModified",
                next_offset=None,
                not_modified=True,
            )
        if top != c.CHANNELS_CHANNEL_PARTICIPANTS:
            raise UnexpectedConstructorError(
                "Expected channels.channelParticipants.",
                safe_context={"actual_constructor": hex_constructor(top)},
            )
        total = reader.read_i32()
        rows = [
            CommunityCodec._parse_channel_participant(reader)
            for _ in range(CommunityCodec._vector_count(reader))
        ]
        for _ in range(CommunityCodec._vector_count(reader)):
            CommunityCodec._skip_chat(reader)
        users = [
            ContactsCodec._parse_user(reader)
            for _ in range(CommunityCodec._vector_count(reader))
        ]
        CommunityCodec._require_end(reader, "channels.channelParticipants")
        members = CommunityCodec._merge_rows(community, rows, users)
        next_offset = offset + len(rows) if offset + len(rows) < total and rows else None
        return MemberPage(
            community=community,
            members=members,
            total_count=max(total, len(members)),
            offset=offset,
            limit=limit,
            response_type="channels.channelParticipants",
            next_offset=next_offset,
        )

    @staticmethod
    def parse_basic_chat_members(data: bytes, *, community: Peer) -> MemberPage:
        reader = TLReader(data)
        reader.expect_constructor(c.MESSAGES_CHAT_FULL)
        reader.expect_constructor(c.CHAT_FULL)
        flags = reader.read_u32()
        chat_id = reader.read_i64()
        reader.read_string()  # about
        rows = CommunityCodec._parse_chat_participants(reader)
        if flags & (1 << 2):
            _parse_photo(reader, 0)
        CommunityCodec._skip_notify_settings(reader)
        if flags & (1 << 13):
            CommunityCodec._skip_exported_invite(reader)
        if flags & (1 << 3):
            for _ in range(CommunityCodec._vector_count(reader)):
                CommunityCodec._skip_bot_info(reader)
        if flags & (1 << 6):
            reader.read_i32()
        if flags & (1 << 11):
            reader.read_i32()
        if flags & (1 << 12):
            CommunityCodec._skip_input_group_call(reader)
        if flags & (1 << 14):
            reader.read_i32()
        if flags & (1 << 15):
            CommunityCodec._read_peer(reader)
        if flags & (1 << 16):
            reader.read_string()
        for _ in range(CommunityCodec._vector_count(reader)):
            CommunityCodec._skip_chat(reader)
        users = [
            ContactsCodec._parse_user(reader)
            for _ in range(CommunityCodec._vector_count(reader))
        ]
        CommunityCodec._require_end(reader, "messages.chatFull")
        effective = community if community.id == chat_id else Peer(chat_id, PeerType.CHAT, title=community.title)
        members = CommunityCodec._merge_rows(effective, rows, users)
        return MemberPage(
            community=effective,
            members=members,
            total_count=len(members),
            offset=0,
            limit=max(1, len(members)),
            response_type="messages.chatFull",
            next_offset=None,
        )

    @staticmethod
    def _input_channel(peer: Peer) -> bytes:
        peer.validate()
        assert peer.access_hash is not None
        return (
            TLWriter()
            .write_i32(c.INPUT_CHANNEL)
            .write_i64(peer.id)
            .write_i64(peer.access_hash)
            .to_bytes()
        )

    @staticmethod
    def _filter(filter: MemberRemoteFilter, query: str) -> bytes:
        writer = TLWriter()
        if filter is MemberRemoteFilter.RECENT:
            return writer.write_i32(c.CHANNEL_PARTICIPANTS_RECENT).to_bytes()
        if filter is MemberRemoteFilter.ADMINS:
            return writer.write_i32(c.CHANNEL_PARTICIPANTS_ADMINS).to_bytes()
        if filter is MemberRemoteFilter.BOTS:
            return writer.write_i32(c.CHANNEL_PARTICIPANTS_BOTS).to_bytes()
        if filter is MemberRemoteFilter.KICKED:
            return writer.write_i32(c.CHANNEL_PARTICIPANTS_KICKED).write_string(query).to_bytes()
        if filter is MemberRemoteFilter.BANNED:
            return writer.write_i32(c.CHANNEL_PARTICIPANTS_BANNED).write_string(query).to_bytes()
        if filter is MemberRemoteFilter.SEARCH:
            return writer.write_i32(c.CHANNEL_PARTICIPANTS_SEARCH).write_string(query).to_bytes()
        if filter is MemberRemoteFilter.CONTACTS:
            return writer.write_i32(c.CHANNEL_PARTICIPANTS_CONTACTS).write_string(query).to_bytes()
        raise DomainValidationError(
            "Unsupported remote member filter.",
            safe_context={"filter": str(filter)},
        )

    @staticmethod
    def _parse_channel_participant(reader: TLReader) -> _ParticipantRow:
        constructor = reader.read_u32()
        if constructor == c.CHANNEL_PARTICIPANT:
            return _ParticipantRow(reader.read_i64(), MemberRole.MEMBER, MemberState.ACTIVE, _timestamp(reader.read_i32()))
        if constructor == c.CHANNEL_PARTICIPANT_SELF:
            user_id = reader.read_i64(); inviter = reader.read_i64(); date = reader.read_i32()
            return _ParticipantRow(user_id, MemberRole.SELF, MemberState.ACTIVE, _timestamp(date), inviter_id=inviter)
        if constructor == c.CHANNEL_PARTICIPANT_CREATOR:
            flags = reader.read_u32(); user_id = reader.read_i64()
            CommunityCodec._skip_admin_rights(reader)
            rank = reader.read_string() if flags & 1 else None
            return _ParticipantRow(user_id, MemberRole.OWNER, MemberState.ACTIVE, rank=rank, can_edit=True)
        if constructor == c.CHANNEL_PARTICIPANT_ADMIN:
            flags = reader.read_u32(); user_id = reader.read_i64()
            inviter = reader.read_i64() if flags & (1 << 1) else None
            promoted_by = reader.read_i64(); date = reader.read_i32()
            CommunityCodec._skip_admin_rights(reader)
            rank = reader.read_string() if flags & (1 << 2) else None
            return _ParticipantRow(
                user_id, MemberRole.ADMIN, MemberState.ACTIVE, _timestamp(date),
                inviter_id=inviter, promoted_by=promoted_by, rank=rank,
                can_edit=bool(flags & 1),
            )
        if constructor == c.CHANNEL_PARTICIPANT_BANNED:
            flags = reader.read_u32(); peer = CommunityCodec._read_peer(reader)
            reader.read_i64(); date = reader.read_i32(); CommunityCodec._skip_banned_rights(reader)
            return _ParticipantRow(
                peer.id, MemberRole.BANNED,
                MemberState.LEFT if flags & 1 else MemberState.BANNED,
                _timestamp(date),
            )
        if constructor == c.CHANNEL_PARTICIPANT_LEFT:
            peer = CommunityCodec._read_peer(reader)
            return _ParticipantRow(peer.id, MemberRole.LEFT, MemberState.LEFT)
        raise UnexpectedConstructorError(
            "Unsupported ChannelParticipant constructor.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _parse_chat_participants(reader: TLReader) -> list[_ParticipantRow]:
        constructor = reader.read_u32()
        if constructor == c.CHAT_PARTICIPANTS_FORBIDDEN:
            flags = reader.read_u32(); reader.read_i64()
            return [CommunityCodec._parse_chat_participant(reader)] if flags & 1 else []
        if constructor != c.CHAT_PARTICIPANTS:
            raise UnexpectedConstructorError(
                "Expected ChatParticipants.",
                safe_context={"actual_constructor": hex_constructor(constructor)},
            )
        reader.read_i64()
        rows = [
            CommunityCodec._parse_chat_participant(reader)
            for _ in range(CommunityCodec._vector_count(reader))
        ]
        reader.read_i32()
        return rows

    @staticmethod
    def _parse_chat_participant(reader: TLReader) -> _ParticipantRow:
        constructor = reader.read_u32()
        if constructor == c.CHAT_PARTICIPANT:
            user_id = reader.read_i64(); inviter = reader.read_i64(); date = reader.read_i32()
            return _ParticipantRow(user_id, MemberRole.MEMBER, MemberState.ACTIVE, _timestamp(date), inviter_id=inviter)
        if constructor == c.CHAT_PARTICIPANT_CREATOR:
            return _ParticipantRow(reader.read_i64(), MemberRole.OWNER, MemberState.ACTIVE, can_edit=True)
        if constructor == c.CHAT_PARTICIPANT_ADMIN:
            user_id = reader.read_i64(); inviter = reader.read_i64(); date = reader.read_i32()
            return _ParticipantRow(user_id, MemberRole.ADMIN, MemberState.ACTIVE, _timestamp(date), inviter_id=inviter, can_edit=True)
        raise UnexpectedConstructorError(
            "Unsupported ChatParticipant constructor.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _merge_rows(community: Peer, rows: list[_ParticipantRow], users: list[User]) -> tuple[CommunityMember, ...]:
        by_id = {user.peer.id: user for user in users}
        now = datetime.now(timezone.utc)
        result: list[CommunityMember] = []
        for row in rows:
            user = by_id.get(row.user_id, User(peer=Peer(row.user_id, PeerType.USER)))
            result.append(
                CommunityMember(
                    community=community,
                    user=user,
                    role=row.role,
                    state=row.state,
                    joined_at=row.joined_at,
                    inviter_id=row.inviter_id,
                    promoted_by=row.promoted_by,
                    rank=row.rank,
                    can_edit=row.can_edit,
                    fetched_at=now,
                )
            )
        return tuple(result)

    @staticmethod
    def _skip_chat(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor == c.CHAT_EMPTY:
            reader.read_i64(); return
        if constructor == c.CHAT_FORBIDDEN:
            reader.read_i64(); reader.read_string(); return
        if constructor == c.CHANNEL_FORBIDDEN:
            flags = reader.read_u32(); reader.read_i64(); reader.read_i64(); reader.read_string()
            if flags & (1 << 16): reader.read_i32()
            return
        if constructor == c.CHAT:
            flags = reader.read_u32(); reader.read_i64(); reader.read_string()
            CommunityCodec._skip_chat_photo(reader)
            reader.read_i32(); reader.read_i32(); reader.read_i32()
            if flags & (1 << 6): CommunityCodec._skip_input_channel(reader)
            if flags & (1 << 14): CommunityCodec._skip_admin_rights(reader)
            if flags & (1 << 18): CommunityCodec._skip_banned_rights(reader)
            return
        if constructor == c.CHANNEL:
            flags = reader.read_u32(); reader.read_i64()
            if flags & (1 << 13): reader.read_i64()
            reader.read_string()
            if flags & (1 << 6): reader.read_string()
            CommunityCodec._skip_chat_photo(reader); reader.read_i32()
            if flags & (1 << 9):
                for _ in range(CommunityCodec._vector_count(reader)):
                    CommunityCodec._skip_restriction_reason(reader)
            if flags & (1 << 14): CommunityCodec._skip_admin_rights(reader)
            if flags & (1 << 15): CommunityCodec._skip_banned_rights(reader)
            if flags & (1 << 18): CommunityCodec._skip_banned_rights(reader)
            if flags & (1 << 17): reader.read_i32()
            if flags & (1 << 29): reader.read_i32()
            return
        raise UnexpectedConstructorError(
            "Unsupported Chat constructor in member response.",
            safe_context={"actual_constructor": hex_constructor(constructor)},
        )

    @staticmethod
    def _skip_chat_photo(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor == c.CHAT_PHOTO_EMPTY:
            return
        if constructor != c.CHAT_PHOTO:
            raise UnexpectedConstructorError("Unsupported ChatPhoto constructor.", safe_context={"actual_constructor": hex_constructor(constructor)})
        reader.read_u32(); reader.read_i64()
        ContactsCodec._skip_file_location(reader); ContactsCodec._skip_file_location(reader)
        reader.read_i32()

    @staticmethod
    def _skip_admin_rights(reader: TLReader) -> None:
        reader.expect_constructor(c.CHAT_ADMIN_RIGHTS); reader.read_u32()

    @staticmethod
    def _skip_banned_rights(reader: TLReader) -> None:
        reader.expect_constructor(c.CHAT_BANNED_RIGHTS); reader.read_u32(); reader.read_i32()

    @staticmethod
    def _skip_input_channel(reader: TLReader) -> None:
        reader.expect_constructor(c.INPUT_CHANNEL); reader.read_i64(); reader.read_i64()

    @staticmethod
    def _skip_restriction_reason(reader: TLReader) -> None:
        reader.expect_constructor(c.RESTRICTION_REASON); reader.read_string(); reader.read_string(); reader.read_string()

    @staticmethod
    def _skip_notify_settings(reader: TLReader) -> None:
        DiscoveryCodec._skip_notify_settings(reader)

    @staticmethod
    def _skip_exported_invite(reader: TLReader) -> None:
        constructor = reader.read_u32()
        if constructor == c.CHAT_INVITE_EMPTY:
            return
        if constructor != c.CHAT_INVITE_EXPORTED:
            raise UnexpectedConstructorError("Unsupported ExportedChatInvite.", safe_context={"actual_constructor": hex_constructor(constructor)})
        flags = reader.read_u32(); reader.read_string(); reader.read_i64(); reader.read_i32()
        if flags & (1 << 4): reader.read_i32()
        if flags & (1 << 1): reader.read_i32()
        if flags & (1 << 2): reader.read_i32()
        if flags & (1 << 3): reader.read_i32()

    @staticmethod
    def _skip_bot_info(reader: TLReader) -> None:
        reader.expect_constructor(c.BOT_INFO); reader.read_i64(); reader.read_string()
        for _ in range(CommunityCodec._vector_count(reader)):
            reader.expect_constructor(c.BOT_COMMAND); reader.read_string(); reader.read_string()

    @staticmethod
    def _skip_input_group_call(reader: TLReader) -> None:
        reader.expect_constructor(c.INPUT_GROUP_CALL); reader.read_i64(); reader.read_i64()

    @staticmethod
    def _read_peer(reader: TLReader) -> Peer:
        constructor = reader.read_u32(); peer_id = reader.read_i64()
        if constructor == c.PEER_USER: return Peer(peer_id, PeerType.USER)
        if constructor == c.PEER_CHAT: return Peer(peer_id, PeerType.CHAT)
        if constructor == c.PEER_CHANNEL: return Peer(peer_id, PeerType.CHANNEL)
        raise UnexpectedConstructorError("Unsupported Peer constructor.", safe_context={"actual_constructor": hex_constructor(constructor)})

    @staticmethod
    def _vector_count(reader: TLReader) -> int:
        reader.expect_constructor(VECTOR)
        count = reader.read_i32()
        if count < 0 or count > 1_000_000:
            raise TLDecodeError("Member vector count is outside the safe range.", safe_context={"count": count})
        return count

    @staticmethod
    def _read_bool(reader: TLReader) -> bool:
        constructor = reader.read_u32()
        if constructor == BOOL_TRUE: return True
        if constructor == BOOL_FALSE: return False
        raise UnexpectedConstructorError("Expected Bool.", safe_context={"actual_constructor": hex_constructor(constructor)})

    @staticmethod
    def _require_end(reader: TLReader, name: str) -> None:
        if reader.remaining():
            raise TLDecodeError(
                f"Trailing bytes remain after parsing {name}.",
                safe_context={"remaining": reader.remaining(), "object": name},
            )

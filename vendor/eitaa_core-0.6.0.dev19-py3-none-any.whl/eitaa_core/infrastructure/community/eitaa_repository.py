"""RPC-backed community membership repository."""

from __future__ import annotations

from ...application.gateway import RpcGateway
from ...domain.community import MemberPage
from ...domain.enums import EndpointRole, MemberRemoteFilter, PeerType
from ...domain.peer import Peer
from ...errors import DomainValidationError, EitaaCoreError
from ...infrastructure.diagnostics import DiagnosticManager
from ...ports.community_repository import CommunityRepository
from .codec import CommunityCodec


class EitaaCommunityRepository(CommunityRepository):
    """Fetch group/channel members through the shared authenticated gateway."""

    def __init__(self, gateway: RpcGateway, diagnostics: DiagnosticManager | None = None) -> None:
        self.gateway = gateway
        self.diagnostics = diagnostics

    def fetch_page(
        self,
        community: Peer,
        *,
        filter: MemberRemoteFilter = MemberRemoteFilter.RECENT,
        query: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> MemberPage:
        try:
            if community.type is PeerType.CHANNEL:
                rpc = self.gateway.invoke(
                    CommunityCodec.build_get_participants(
                        community, filter=filter, query=query, offset=offset, limit=limit
                    ),
                    operation="channels.getParticipants",
                    endpoint_role=EndpointRole.API,
                )
                page = CommunityCodec.parse_channel_participants(
                    rpc.body, community=community, offset=offset, limit=limit
                )
            elif community.type is PeerType.CHAT:
                rpc = self.gateway.invoke(
                    CommunityCodec.build_get_full_chat(community),
                    operation="messages.getFullChat",
                    endpoint_role=EndpointRole.API,
                )
                full = CommunityCodec.parse_basic_chat_members(rpc.body, community=community)
                selected = full.members[offset:offset + limit]
                page = MemberPage(
                    community=community,
                    members=selected,
                    total_count=full.total_count,
                    offset=offset,
                    limit=limit,
                    response_type=full.response_type,
                    next_offset=(offset + len(selected) if offset + len(selected) < full.total_count else None),
                )
            else:
                raise DomainValidationError(
                    "User peers do not have a community member list.",
                    safe_context={"peer_type": community.type.value},
                )
        except EitaaCoreError as exc:
            debug_file = self._emit(
                "members_fetch_failed",
                level="error",
                fields={
                    "community": community.safe_summary(),
                    "filter": filter.value,
                    "query_length": len(query),
                    "offset": offset,
                    "limit": limit,
                    "error_type": type(exc).__name__,
                },
            )
            if not exc.debug_file:
                exc.debug_file = debug_file
            raise
        self._emit("members_fetch_completed", fields=page.safe_summary())
        return page

    def _emit(self, event: str, *, level: str = "info", fields: dict[str, object] | None = None) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("members", event, level=level, fields=fields)

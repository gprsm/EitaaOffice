"""Atomic JSON, JSONL, and CSV writers for exported messages."""

from __future__ import annotations

import csv
import json
import os
import tempfile
from pathlib import Path
from typing import Iterable

from ...domain.enums import ExportFormat
from ...domain.message import Message
from ...errors import ExportError
from ..diagnostics import DiagnosticManager


class MessageExportWriter:
    """Incrementally write message records to an atomic temporary file."""

    def __init__(
        self,
        path: Path,
        format: ExportFormat,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.path = Path(path)
        self.format = format
        self.diagnostics = diagnostics
        self._temporary_path: Path | None = None
        self._handle = None
        self._csv = None
        self._first_json = True

    def __enter__(self) -> "MessageExportWriter":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            handle = tempfile.NamedTemporaryFile(
                "w",
                encoding="utf-8",
                newline="",
                dir=self.path.parent,
                prefix=f".{self.path.name}.",
                suffix=".tmp",
                delete=False,
            )
            self._handle = handle
            self._temporary_path = Path(handle.name)
            if self.format is ExportFormat.JSON:
                handle.write("[\n")
            elif self.format is ExportFormat.CSV:
                self._csv = csv.DictWriter(
                    handle,
                    fieldnames=[
                        "peer_type", "peer_id", "message_id", "date_utc",
                        "text", "outgoing", "from_peer_type", "from_peer_id",
                        "reply_to_message_id", "media_type", "mime_type",
                        "file_name", "media_size", "parse_warning",
                    ],
                )
                self._csv.writeheader()
            return self
        except OSError as exc:
            raise ExportError(
                "Could not create the temporary export file.",
                safe_context={
                    "output_directory": str(self.path.parent),
                    "error_type": type(exc).__name__,
                },
            ) from exc

    def write_many(self, messages: Iterable[Message]) -> int:
        if self._handle is None:
            raise ExportError("Export writer is not open.")
        count = 0
        for message in messages:
            record = _message_record(message)
            if self.format is ExportFormat.JSONL:
                self._handle.write(json.dumps(record, ensure_ascii=False) + "\n")
            elif self.format is ExportFormat.JSON:
                if not self._first_json:
                    self._handle.write(",\n")
                self._handle.write(json.dumps(record, ensure_ascii=False, indent=2))
                self._first_json = False
            elif self.format is ExportFormat.CSV:
                assert self._csv is not None
                self._csv.writerow(record)
            else:
                raise ExportError(
                    "Unsupported export format.",
                    safe_context={"format": str(self.format)},
                )
            count += 1
        return count

    def finalize(self) -> Path:
        if self._handle is None or self._temporary_path is None:
            raise ExportError("Export writer is not open.")
        try:
            if self.format is ExportFormat.JSON:
                self._handle.write("\n]\n")
            self._handle.flush()
            os.fsync(self._handle.fileno())
            self._handle.close()
            self._handle = None
            os.replace(self._temporary_path, self.path)
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass
            return self.path
        except OSError as exc:
            raise ExportError(
                "Could not finalize the export file atomically.",
                safe_context={
                    "output_directory": str(self.path.parent),
                    "error_type": type(exc).__name__,
                },
            ) from exc

    def abort(self) -> None:
        try:
            if self._handle is not None:
                self._handle.close()
        finally:
            self._handle = None
            if self._temporary_path is not None:
                self._temporary_path.unlink(missing_ok=True)

    def __exit__(self, exc_type, exc, traceback) -> None:
        if exc is not None:
            self.abort()


def _message_record(message: Message) -> dict[str, object]:
    media = message.media
    return {
        "peer_type": message.peer.type.value,
        "peer_id": message.peer.id,
        "message_id": message.id,
        "date_utc": message.date.isoformat(),
        "text": message.text,
        "outgoing": message.outgoing,
        "from_peer_type": message.from_peer.type.value if message.from_peer else None,
        "from_peer_id": message.from_peer.id if message.from_peer else None,
        "reply_to_message_id": message.reply_to_message_id,
        "media_type": media.type.value if media else None,
        "mime_type": media.mime_type if media else None,
        "file_name": media.file_name if media else None,
        "media_size": media.size if media else None,
        "parse_warning": message.parse_warning,
    }

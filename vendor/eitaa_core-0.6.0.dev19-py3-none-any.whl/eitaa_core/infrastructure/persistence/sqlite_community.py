"""SQLite persistence for community members and crash-safe bulk jobs."""

from __future__ import annotations

import hashlib
import secrets
import sqlite3
import unicodedata
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

from ...domain.community import (
    BulkJob,
    BulkMessageDeleteReport,
    BulkMessageSpec,
    BulkRecipient,
    BulkRunReport,
    BulkSendOptions,
    CommunityMember,
    MemberPage,
    MemberSearchQuery,
    MemberSyncResult,
)
from ...domain.phone_list import (
    PhoneCleanupReport,
    PhoneListEntry,
    PhoneListInputRow,
    PhoneRecipientList,
)
from ...domain.enums import (
    BulkDeleteStatus,
    BulkJobStatus,
    BulkRecipientStatus,
    MemberRole,
    MemberState,
    PeerType,
    SendKind,
    UserStatusKind,
    ContactResolutionSource,
    PhoneCleanupStatus,
    PhoneEntryStatus,
    PhoneListStatus,
)
from ...domain.peer import Peer
from ...domain.phone import PhoneNumber
from ...domain.user import User, UserStatus
from ...errors import MessageStoreError
from ..diagnostics import DiagnosticManager
from .sqlite_messages import SCHEMA_VERSION, SQLiteMessageRepository


class SQLiteCommunityRepository:
    """Store membership snapshots and persistent delivery jobs in Core SQLite."""

    def __init__(self, path: Path | str, diagnostics: DiagnosticManager | None = None) -> None:
        self.path = Path(path)
        self.diagnostics = diagnostics
        self._connection: sqlite3.Connection | None = None

    def initialize(self) -> None:
        if self._connection is not None:
            return
        # Reuse the cumulative Core migration owner before opening this adapter.
        migrator = SQLiteMessageRepository(self.path, self.diagnostics)
        migrator.initialize()
        migrator.close()
        try:
            connection = sqlite3.connect(self.path, timeout=30)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA journal_mode = WAL")
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if version != SCHEMA_VERSION:
                raise MessageStoreError(
                    "Community repository schema mismatch.",
                    safe_context={"database_version": version, "supported_version": SCHEMA_VERSION},
                )
            self._connection = connection
            self._emit("database", "community_database_initialized", fields={"schema_version": version})
        except sqlite3.Error as exc:
            raise MessageStoreError(
                "Could not initialize community SQLite repository.",
                safe_context={"sqlite_error": type(exc).__name__},
                debug_file=self._emit(
                    "database", "community_database_initialize_failed", level="error",
                    fields={"sqlite_error": type(exc).__name__},
                ),
            ) from exc

    # ------------------------------------------------------------------
    # Members
    # ------------------------------------------------------------------
    def sync_members(
        self,
        community: Peer,
        members: Sequence[CommunityMember],
        *,
        complete_snapshot: bool,
    ) -> MemberSyncResult:
        connection = self._require_connection()
        now = _utc_now()
        inserted = updated = unchanged = reactivated = 0
        incoming_ids: set[int] = set()
        try:
            with connection:
                for member in members:
                    incoming_ids.add(member.user.peer.id)
                    key = (community.type.value, community.id, member.user.peer.id)
                    old = connection.execute(
                        """SELECT access_hash,first_name,last_name,username,phone,status_kind,
                                  is_contact,is_mutual_contact,is_deleted,is_bot,is_verified,
                                  role,state,joined_at,inviter_id,promoted_by,rank,can_edit
                           FROM community_members
                           WHERE community_type=? AND community_id=? AND user_id=?""",
                        key,
                    ).fetchone()
                    values = _member_values(member)
                    if old is None:
                        connection.execute(
                            """INSERT INTO community_members(
                                community_type,community_id,user_id,access_hash,first_name,last_name,
                                username,phone,status_kind,status_expires_at,status_was_online_at,
                                is_contact,is_mutual_contact,is_deleted,is_bot,is_verified,
                                role,state,joined_at,inviter_id,promoted_by,rank,can_edit,
                                first_seen_at,last_seen_at,left_at,updated_at
                            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            (community.type.value, community.id, member.user.peer.id, *values, now, now, None, now),
                        )
                        inserted += 1
                    else:
                        comparable_old = tuple(old)
                        comparable_new = (
                            values[0], values[1], values[2], values[3], values[4], values[5],
                            values[8], values[9], values[10], values[11], values[12], values[13],
                            values[14], values[15], values[16], values[17], values[18], values[19],
                        )
                        was_inactive = str(old[12]) != MemberState.ACTIVE.value
                        if comparable_old == comparable_new:
                            connection.execute(
                                """UPDATE community_members SET last_seen_at=?, left_at=NULL
                                   WHERE community_type=? AND community_id=? AND user_id=?""",
                                (now, *key),
                            )
                            unchanged += 1
                        else:
                            connection.execute(
                                """UPDATE community_members SET
                                    access_hash=?,first_name=?,last_name=?,username=?,phone=?,status_kind=?,
                                    status_expires_at=?,status_was_online_at=?,is_contact=?,is_mutual_contact=?,
                                    is_deleted=?,is_bot=?,is_verified=?,role=?,state=?,joined_at=?,inviter_id=?,
                                    promoted_by=?,rank=?,can_edit=?,last_seen_at=?,left_at=NULL,updated_at=?
                                   WHERE community_type=? AND community_id=? AND user_id=?""",
                                (*values, now, now, *key),
                            )
                            updated += 1
                        if was_inactive and member.state is MemberState.ACTIVE:
                            reactivated += 1

                marked_left = 0
                if complete_snapshot:
                    rows = connection.execute(
                        """SELECT user_id FROM community_members
                           WHERE community_type=? AND community_id=? AND state=?""",
                        (community.type.value, community.id, MemberState.ACTIVE.value),
                    ).fetchall()
                    missing = [int(row[0]) for row in rows if int(row[0]) not in incoming_ids]
                    for user_id in missing:
                        connection.execute(
                            """UPDATE community_members
                               SET state=?, role=?, left_at=?, updated_at=?
                               WHERE community_type=? AND community_id=? AND user_id=?""",
                            (
                                MemberState.LEFT.value, MemberRole.LEFT.value, now, now,
                                community.type.value, community.id, user_id,
                            ),
                        )
                    marked_left = len(missing)
        except sqlite3.Error as exc:
            raise MessageStoreError(
                "Could not persist community members.",
                safe_context={"member_count": len(members), "sqlite_error": type(exc).__name__},
                debug_file=self._emit(
                    "members", "members_store_failed", level="error",
                    fields={"member_count": len(members), "sqlite_error": type(exc).__name__},
                ),
            ) from exc
        result = MemberSyncResult(
            fetched=len(members), inserted=inserted, updated=updated, unchanged=unchanged,
            reactivated=reactivated, marked_left=marked_left, complete_snapshot=complete_snapshot,
        )
        self._emit("members", "members_stored", fields=result.safe_summary())
        return result

    def search_members(self, query: MemberSearchQuery) -> MemberPage:
        query.validate()
        sql = "SELECT * FROM community_members WHERE community_type=? AND community_id=?"
        params: list[object] = [query.community.type.value, query.community.id]
        if query.text:
            variants = _member_search_variants(query.text)
            clauses: list[str] = []
            for variant in variants:
                clauses.append(
                    "(first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\' "
                    "OR username LIKE ? ESCAPE '\\' OR CAST(user_id AS TEXT) LIKE ? ESCAPE '\\')"
                )
                pattern = "%" + variant.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
                params.extend([pattern, pattern, pattern, pattern])
            sql += " AND (" + " OR ".join(clauses) + ")"
        if query.roles:
            sql += " AND role IN (" + ",".join("?" for _ in query.roles) + ")"
            params.extend(item.value for item in query.roles)
        if query.states:
            sql += " AND state IN (" + ",".join("?" for _ in query.states) + ")"
            params.extend(item.value for item in query.states)
        if query.sendable_only:
            sql += " AND access_hash IS NOT NULL AND is_deleted=0"
        if not query.include_bots:
            sql += " AND is_bot=0"
        count_sql = "SELECT COUNT(*) FROM (" + sql + ")"
        total = int(self._require_connection().execute(count_sql, params).fetchone()[0])
        sql += " ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, user_id LIMIT ? OFFSET ?"
        rows = self._require_connection().execute(sql, [*params, query.limit, query.offset]).fetchall()
        members = tuple(_row_to_member(row, query.community) for row in rows)
        return MemberPage(
            community=query.community,
            members=members,
            total_count=total,
            offset=query.offset,
            limit=query.limit,
            response_type="local.community_members",
            next_offset=query.offset + len(members) if query.offset + len(members) < total else None,
        )

    def get_member(self, community: Peer, user_id: int) -> CommunityMember | None:
        row = self._require_connection().execute(
            "SELECT * FROM community_members WHERE community_type=? AND community_id=? AND user_id=?",
            (community.type.value, community.id, user_id),
        ).fetchone()
        return _row_to_member(row, community) if row else None

    def mark_member_left(self, community: Peer, user_id: int) -> bool:
        """Mark one known member as left after a confirmed membership rollback."""
        now = _utc_now()
        with self._require_connection():
            cursor = self._require_connection().execute(
                """UPDATE community_members SET state=?,role=?,left_at=?,updated_at=?
                   WHERE community_type=? AND community_id=? AND user_id=?""",
                (
                    MemberState.LEFT.value, MemberRole.LEFT.value, now, now,
                    community.type.value, community.id, user_id,
                ),
            )
        return bool(cursor.rowcount)

    # ------------------------------------------------------------------
    # Phone recipient lists
    # ------------------------------------------------------------------
    def create_phone_list(
        self,
        *,
        name: str,
        source_name: str,
        rows: Sequence[PhoneListInputRow],
        valid_unique: int,
        duplicate_count: int,
        invalid_count: int,
    ) -> PhoneRecipientList:
        list_id = uuid.uuid4().hex
        digest = hashlib.sha256(list_id.encode("ascii")).digest()
        virtual_peer_id = int.from_bytes(digest[:8], "little") & 0x7FFF_FFFF_FFFF_FFFF
        virtual_peer_id = virtual_peer_id or 1
        now = _utc_now()
        pending_count = sum(1 for row in rows if row.status is PhoneEntryStatus.PENDING)
        connection = self._require_connection()
        with connection:
            connection.execute(
                """INSERT INTO phone_recipient_lists(
                    list_id,name,virtual_peer_id,source_name,status,total_rows,valid_unique,
                    duplicate_count,invalid_count,pending_count,resolved_count,not_found_count,
                    failed_count,created_at,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    list_id, name.strip() or "Phone recipients", virtual_peer_id, source_name,
                    PhoneListStatus.DRAFT.value, len(rows), valid_unique, duplicate_count,
                    invalid_count, pending_count, 0, 0, 0, now, now,
                ),
            )
            for row in rows:
                phone_text = str(row.phone) if row.phone else None
                fingerprint_source = phone_text or f"row:{row.row_number}:{row.error_code or 'invalid'}"
                phone_hash = hashlib.sha256(fingerprint_source.encode("utf-8")).hexdigest()
                connection.execute(
                    """INSERT INTO phone_recipient_entries(
                        list_id,row_number,phone,phone_hash,first_name,last_name,status,attempts,
                        error_code,created_at,updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        list_id, row.row_number, phone_text, phone_hash,
                        row.first_name.strip() or "Eitaa", row.last_name.strip(), row.status.value,
                        0, row.error_code, now, now,
                    ),
                )
        result = self.get_phone_list(list_id)
        assert result is not None
        self._emit("phone_lists", "phone_list_created", fields=result.safe_summary())
        return result

    def get_phone_list(self, list_id: str) -> PhoneRecipientList | None:
        row = self._require_connection().execute(
            "SELECT * FROM phone_recipient_lists WHERE list_id=?", (list_id,)
        ).fetchone()
        return _row_to_phone_list(row) if row else None

    def list_phone_lists(self, *, limit: int = 100) -> tuple[PhoneRecipientList, ...]:
        rows = self._require_connection().execute(
            "SELECT * FROM phone_recipient_lists ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return tuple(_row_to_phone_list(row) for row in rows)

    def set_phone_list_status(
        self,
        list_id: str,
        status: PhoneListStatus,
        *,
        stop_reason: str | None = None,
    ) -> PhoneRecipientList:
        now = _utc_now()
        resolved_at = now if status in {PhoneListStatus.READY, PhoneListStatus.PARTIAL} else None
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE phone_recipient_lists
                   SET status=?,stop_reason=?,updated_at=?,resolved_at=COALESCE(?,resolved_at)
                   WHERE list_id=?""",
                (status.value, stop_reason, now, resolved_at, list_id),
            )
        result = self.get_phone_list(list_id)
        if result is None:
            raise MessageStoreError("Phone recipient list was not found.", safe_context={"list_id": list_id})
        return result

    def recover_phone_processing(self, list_id: str) -> int:
        now = _utc_now()
        with self._require_connection():
            cursor = self._require_connection().execute(
                """UPDATE phone_recipient_entries
                   SET status=?,error_code=?,error_type=?,updated_at=?
                   WHERE list_id=? AND status=?""",
                (
                    PhoneEntryStatus.PENDING.value, "INTERRUPTED", "previous_process_stopped",
                    now, list_id, PhoneEntryStatus.PROCESSING.value,
                ),
            )
        self.refresh_phone_list_counts(list_id)
        return int(cursor.rowcount)

    def claim_phone_entry(self, list_id: str, *, max_attempts: int) -> PhoneListEntry | None:
        connection = self._require_connection()
        now = _utc_now()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT * FROM phone_recipient_entries
                   WHERE list_id=? AND status IN (?,?) AND attempts < ?
                   ORDER BY row_number,entry_id LIMIT 1""",
                (
                    list_id, PhoneEntryStatus.PENDING.value, PhoneEntryStatus.FAILED.value,
                    max_attempts,
                ),
            ).fetchone()
            if row is None:
                connection.commit()
                return None
            connection.execute(
                """UPDATE phone_recipient_entries
                   SET status=?,attempts=attempts+1,updated_at=?
                   WHERE entry_id=?""",
                (PhoneEntryStatus.PROCESSING.value, now, int(row["entry_id"])),
            )
            connection.commit()
            refreshed = connection.execute(
                "SELECT * FROM phone_recipient_entries WHERE entry_id=?",
                (int(row["entry_id"]),),
            ).fetchone()
            return _row_to_phone_entry(refreshed)
        except sqlite3.Error:
            connection.rollback()
            raise

    def resolved_user_exists(self, list_id: str, user_id: int, *, exclude_entry_id: int) -> bool:
        row = self._require_connection().execute(
            """SELECT 1 FROM phone_recipient_entries
               WHERE list_id=? AND user_id=? AND entry_id<>? AND status=? LIMIT 1""",
            (list_id, user_id, exclude_entry_id, PhoneEntryStatus.RESOLVED.value),
        ).fetchone()
        return row is not None

    def mark_phone_entry_resolved(
        self,
        entry: PhoneListEntry,
        user: User,
        *,
        source: ContactResolutionSource,
        contact_added_by_list: bool,
    ) -> None:
        now = _utc_now()
        phone_text = str(user.phone or entry.phone) if (user.phone or entry.phone) else None
        cleanup_status = (
            PhoneCleanupStatus.ELIGIBLE.value
            if contact_added_by_list
            else PhoneCleanupStatus.NOT_REQUIRED.value
        )
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE phone_recipient_entries SET
                    phone=COALESCE(?,phone),status=?,user_id=?,access_hash=?,resolved_first_name=?,
                    resolved_last_name=?,username=?,error_code=NULL,error_type=NULL,
                    contact_source=?,contact_added_by_list=?,cleanup_status=?,
                    cleanup_error_code=NULL,cleanup_error_type=NULL,cleanup_response_type=NULL,
                    resolved_at=?,updated_at=? WHERE entry_id=?""",
                (
                    phone_text, PhoneEntryStatus.RESOLVED.value, user.peer.id, user.peer.access_hash,
                    user.first_name, user.last_name, user.username, source.value,
                    int(contact_added_by_list), cleanup_status, now, now, entry.id,
                ),
            )
        self.refresh_phone_list_counts(entry.list_id)

    def mark_phone_entry_terminal(
        self,
        entry: PhoneListEntry,
        *,
        status: PhoneEntryStatus,
        error_code: str | None,
        error_type: str | None,
    ) -> None:
        if status not in {
            PhoneEntryStatus.NOT_FOUND, PhoneEntryStatus.INVALID,
            PhoneEntryStatus.DUPLICATE, PhoneEntryStatus.FAILED,
            PhoneEntryStatus.PENDING,
        }:
            raise ValueError("Unsupported phone-entry terminal status")
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE phone_recipient_entries
                   SET status=?,error_code=?,error_type=?,updated_at=? WHERE entry_id=?""",
                (status.value, error_code, error_type, now, entry.id),
            )
        self.refresh_phone_list_counts(entry.list_id)

    def refresh_phone_list_counts(self, list_id: str) -> PhoneRecipientList:
        connection = self._require_connection()
        counts = {
            str(row["status"]): int(row["count"])
            for row in connection.execute(
                """SELECT status,COUNT(*) AS count FROM phone_recipient_entries
                   WHERE list_id=? GROUP BY status""",
                (list_id,),
            ).fetchall()
        }
        pending = counts.get(PhoneEntryStatus.PENDING.value, 0) + counts.get(PhoneEntryStatus.PROCESSING.value, 0)
        with connection:
            connection.execute(
                """UPDATE phone_recipient_lists SET
                    pending_count=?,resolved_count=?,not_found_count=?,failed_count=?,updated_at=?
                   WHERE list_id=?""",
                (
                    pending,
                    counts.get(PhoneEntryStatus.RESOLVED.value, 0),
                    counts.get(PhoneEntryStatus.NOT_FOUND.value, 0),
                    counts.get(PhoneEntryStatus.FAILED.value, 0),
                    _utc_now(), list_id,
                ),
            )
        result = self.get_phone_list(list_id)
        if result is None:
            raise MessageStoreError("Phone recipient list was not found.", safe_context={"list_id": list_id})
        return result

    def list_phone_entries(
        self,
        list_id: str,
        *,
        status: PhoneEntryStatus | None = None,
        offset: int = 0,
        limit: int = 1000,
    ) -> tuple[PhoneListEntry, ...]:
        sql = "SELECT * FROM phone_recipient_entries WHERE list_id=?"
        params: list[object] = [list_id]
        if status is not None:
            sql += " AND status=?"
            params.append(status.value)
        sql += " ORDER BY row_number,entry_id LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        rows = self._require_connection().execute(sql, params).fetchall()
        return tuple(_row_to_phone_entry(row) for row in rows)

    def resolved_phone_members(self, phone_list: PhoneRecipientList) -> tuple[CommunityMember, ...]:
        rows = self._require_connection().execute(
            """SELECT * FROM phone_recipient_entries
               WHERE list_id=? AND status=? AND user_id IS NOT NULL AND access_hash IS NOT NULL
               ORDER BY row_number,entry_id""",
            (phone_list.id, PhoneEntryStatus.RESOLVED.value),
        ).fetchall()
        members: list[CommunityMember] = []
        seen: set[int] = set()
        for row in rows:
            user_id = int(row["user_id"])
            if user_id in seen:
                continue
            seen.add(user_id)
            phone = PhoneNumber.parse(str(row["phone"])) if row["phone"] else None
            user = User(
                peer=Peer(user_id, PeerType.USER, row["access_hash"], row["username"]),
                first_name=row["resolved_first_name"] or row["first_name"],
                last_name=row["resolved_last_name"] or row["last_name"],
                username=row["username"],
                phone=phone,
                is_contact=True,
            )
            members.append(
                CommunityMember(
                    community=phone_list.virtual_community,
                    user=user,
                    role=MemberRole.MEMBER,
                    state=MemberState.ACTIVE,
                )
            )
        return tuple(members)

    # ------------------------------------------------------------------
    # Phone-list contact cleanup
    # ------------------------------------------------------------------
    def prepare_phone_cleanup(self, list_id: str, *, include_legacy_unknown: bool = False) -> int:
        """Make safe cleanup candidates eligible and optionally include legacy unknown rows."""
        connection = self._require_connection()
        now = _utc_now()
        changed = 0
        with connection:
            cursor = connection.execute(
                """UPDATE phone_recipient_entries
                   SET cleanup_status=?,cleanup_error_code=NULL,cleanup_error_type=NULL,cleanup_updated_at=?
                   WHERE list_id=? AND status=? AND contact_added_by_list=1
                     AND cleanup_status IN (?,?)""",
                (
                    PhoneCleanupStatus.ELIGIBLE.value, now, list_id,
                    PhoneEntryStatus.RESOLVED.value, PhoneCleanupStatus.NOT_REQUIRED.value,
                    PhoneCleanupStatus.FAILED.value,
                ),
            )
            changed += int(cursor.rowcount)
            if include_legacy_unknown:
                cursor = connection.execute(
                    """UPDATE phone_recipient_entries
                       SET cleanup_status=?,cleanup_error_code='LEGACY_OWNERSHIP_ASSUMED',
                           cleanup_error_type='explicit_operator_override',cleanup_updated_at=?
                       WHERE list_id=? AND status=? AND contact_source IS NULL
                         AND contact_added_by_list=0 AND cleanup_status IN (?,?)""",
                    (
                        PhoneCleanupStatus.ELIGIBLE.value, now, list_id,
                        PhoneEntryStatus.RESOLVED.value, PhoneCleanupStatus.NOT_REQUIRED.value,
                        PhoneCleanupStatus.FAILED.value,
                    ),
                )
                changed += int(cursor.rowcount)
        return changed

    def recover_phone_cleanup_processing(self, list_id: str) -> int:
        now = _utc_now()
        with self._require_connection():
            cursor = self._require_connection().execute(
                """UPDATE phone_recipient_entries
                   SET cleanup_status=?,cleanup_error_code='INTERRUPTED',
                       cleanup_error_type='previous_process_stopped',cleanup_updated_at=?
                   WHERE list_id=? AND cleanup_status=?""",
                (
                    PhoneCleanupStatus.ELIGIBLE.value, now, list_id,
                    PhoneCleanupStatus.PROCESSING.value,
                ),
            )
        return int(cursor.rowcount)

    def claim_phone_cleanup_entry(self, list_id: str, *, max_attempts: int) -> PhoneListEntry | None:
        connection = self._require_connection()
        now = _utc_now()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT * FROM phone_recipient_entries
                   WHERE list_id=? AND cleanup_status IN (?,?) AND cleanup_attempts < ?
                     AND phone IS NOT NULL
                   ORDER BY row_number,entry_id LIMIT 1""",
                (
                    list_id, PhoneCleanupStatus.ELIGIBLE.value, PhoneCleanupStatus.FAILED.value,
                    max_attempts,
                ),
            ).fetchone()
            if row is None:
                connection.commit()
                return None
            connection.execute(
                """UPDATE phone_recipient_entries
                   SET cleanup_status=?,cleanup_attempts=cleanup_attempts+1,cleanup_updated_at=?
                   WHERE entry_id=?""",
                (PhoneCleanupStatus.PROCESSING.value, now, int(row["entry_id"])),
            )
            connection.commit()
            refreshed = connection.execute(
                "SELECT * FROM phone_recipient_entries WHERE entry_id=?",
                (int(row["entry_id"]),),
            ).fetchone()
            return _row_to_phone_entry(refreshed)
        except sqlite3.Error:
            connection.rollback()
            raise

    def mark_phone_cleanup_removed(
        self, entry: PhoneListEntry, *, response_type: str = "contacts.delete"
    ) -> None:
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE phone_recipient_entries
                   SET cleanup_status=?,cleanup_error_code=NULL,cleanup_error_type=NULL,
                       cleanup_response_type=?,cleanup_updated_at=?,removed_at=? WHERE entry_id=?""",
                (
                    PhoneCleanupStatus.REMOVED.value, response_type, now, now, entry.id,
                ),
            )

    def mark_phone_cleanup_error(
        self,
        entry: PhoneListEntry,
        *,
        retry: bool,
        error_code: str | None,
        error_type: str,
    ) -> None:
        now = _utc_now()
        status = PhoneCleanupStatus.ELIGIBLE if retry else PhoneCleanupStatus.FAILED
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE phone_recipient_entries
                   SET cleanup_status=?,cleanup_error_code=?,cleanup_error_type=?,
                       cleanup_response_type=NULL,cleanup_updated_at=?
                   WHERE entry_id=?""",
                (status.value, error_code, error_type, now, entry.id),
            )

    def phone_cleanup_report(
        self, list_id: str, *, stop_reason: str | None = None
    ) -> PhoneCleanupReport:
        connection = self._require_connection()
        rows = connection.execute(
            """SELECT cleanup_status,COUNT(*) AS count FROM phone_recipient_entries
               WHERE list_id=? GROUP BY cleanup_status""",
            (list_id,),
        ).fetchall()
        counts = {str(row["cleanup_status"]): int(row["count"]) for row in rows}
        eligible_total = int(connection.execute(
            """SELECT COUNT(*) FROM phone_recipient_entries
               WHERE list_id=? AND status=? AND (contact_added_by_list=1 OR cleanup_status<>?)""",
            (list_id, PhoneEntryStatus.RESOLVED.value, PhoneCleanupStatus.NOT_REQUIRED.value),
        ).fetchone()[0])
        skipped_existing = int(connection.execute(
            """SELECT COUNT(*) FROM phone_recipient_entries
               WHERE list_id=? AND status=? AND contact_source=? AND contact_added_by_list=0""",
            (list_id, PhoneEntryStatus.RESOLVED.value, ContactResolutionSource.EXISTING.value),
        ).fetchone()[0])
        skipped_legacy = int(connection.execute(
            """SELECT COUNT(*) FROM phone_recipient_entries
               WHERE list_id=? AND status=? AND contact_source IS NULL
                 AND contact_added_by_list=0 AND cleanup_status=?""",
            (list_id, PhoneEntryStatus.RESOLVED.value, PhoneCleanupStatus.NOT_REQUIRED.value),
        ).fetchone()[0])
        pending = counts.get(PhoneCleanupStatus.ELIGIBLE.value, 0)
        processing = counts.get(PhoneCleanupStatus.PROCESSING.value, 0)
        return PhoneCleanupReport(
            list_id=list_id,
            eligible=eligible_total,
            removed=counts.get(PhoneCleanupStatus.REMOVED.value, 0),
            failed=counts.get(PhoneCleanupStatus.FAILED.value, 0),
            skipped_existing=skipped_existing,
            skipped_legacy_unknown=skipped_legacy,
            pending=pending,
            processing=processing,
            complete=pending == 0 and processing == 0,
            stop_reason=stop_reason,
        )

    # ------------------------------------------------------------------
    # Bulk jobs
    # ------------------------------------------------------------------
    def create_job(
        self,
        community: Peer,
        spec: BulkMessageSpec,
        options: BulkSendOptions,
        recipients: Sequence[CommunityMember],
    ) -> BulkJob:
        spec.validate(); options.validate()
        job_id = uuid.uuid4().hex
        now = _utc_now()
        skipped = 0
        connection = self._require_connection()
        with connection:
            connection.execute(
                """INSERT INTO bulk_jobs(
                    job_id,community_type,community_id,community_access_hash,community_username,
                    community_title,kind,text,file_path,caption,mime_type,content_hash,status,
                    delay_seconds,max_attempts,retry_delay_seconds,test_limit,stop_on_server_error,
                    recipient_count,sent_count,failed_count,skipped_count,created_at,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    job_id, community.type.value, community.id, community.access_hash,
                    community.username, community.title, spec.kind.value, spec.text,
                    str(spec.file_path) if spec.file_path else None, spec.caption, spec.mime_type,
                    spec.content_hash, BulkJobStatus.DRAFT.value, options.delay_seconds,
                    options.max_attempts, options.retry_delay_seconds, options.test_limit,
                    int(options.stop_on_server_error), len(recipients), 0, 0, 0, now, now,
                ),
            )
            for member in recipients:
                sendable = member.is_sendable
                status = BulkRecipientStatus.PENDING if sendable else BulkRecipientStatus.SKIPPED
                if not sendable:
                    skipped += 1
                user = member.user
                connection.execute(
                    """INSERT INTO bulk_recipients(
                        job_id,user_id,access_hash,first_name,last_name,username,role,status,
                        attempts,random_id,error_code,error_type,updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        job_id, user.peer.id, user.peer.access_hash, user.first_name, user.last_name,
                        user.username, member.role.value, status.value, 0, secrets.randbits(63) or 1,
                        "UNSENDABLE" if not sendable else None,
                        "missing_access_hash_or_inactive" if not sendable else None,
                        now,
                    ),
                )
            connection.execute(
                "UPDATE bulk_jobs SET skipped_count=?, updated_at=? WHERE job_id=?",
                (skipped, now, job_id),
            )
        job = self.get_job(job_id)
        assert job is not None
        self._emit("bulk_send", "bulk_job_created", fields=job.safe_summary())
        return job

    def get_job(self, job_id: str) -> BulkJob | None:
        row = self._require_connection().execute(
            "SELECT * FROM bulk_jobs WHERE job_id=?", (job_id,)
        ).fetchone()
        return _row_to_job(row) if row else None

    def list_jobs(self, *, limit: int = 100) -> tuple[BulkJob, ...]:
        rows = self._require_connection().execute(
            "SELECT * FROM bulk_jobs ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return tuple(_row_to_job(row) for row in rows)

    def set_job_status(
        self,
        job_id: str,
        status: BulkJobStatus,
        *,
        stop_reason: str | None = None,
    ) -> BulkJob:
        now = _utc_now()
        started = now if status is BulkJobStatus.RUNNING else None
        finished = now if status in {
            BulkJobStatus.COMPLETED, BulkJobStatus.CANCELLED,
            BulkJobStatus.BLOCKED, BulkJobStatus.FAILED,
        } else None
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE bulk_jobs SET status=?,stop_reason=?,updated_at=?,
                    started_at=COALESCE(started_at,?),finished_at=? WHERE job_id=?""",
                (status.value, stop_reason, now, started, finished, job_id),
            )
        job = self.get_job(job_id)
        if job is None:
            raise MessageStoreError("Bulk job was not found.", safe_context={"job_id": job_id})
        return job

    def recover_processing(self, job_id: str) -> int:
        now = _utc_now()
        with self._require_connection():
            cursor = self._require_connection().execute(
                """UPDATE bulk_recipients SET status=?,error_code=?,error_type=?,updated_at=?
                   WHERE job_id=? AND status=?""",
                (
                    BulkRecipientStatus.PENDING.value, "INTERRUPTED", "previous_process_stopped",
                    now, job_id, BulkRecipientStatus.PROCESSING.value,
                ),
            )
        return int(cursor.rowcount)

    def claim_next_recipient(self, job_id: str) -> BulkRecipient | None:
        connection = self._require_connection()
        now = _utc_now()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT * FROM bulk_recipients
                   WHERE job_id=? AND status=? ORDER BY user_id LIMIT 1""",
                (job_id, BulkRecipientStatus.PENDING.value),
            ).fetchone()
            if row is None:
                connection.commit(); return None
            connection.execute(
                """UPDATE bulk_recipients SET status=?,attempts=attempts+1,last_attempt_at=?,updated_at=?
                   WHERE job_id=? AND user_id=? AND status=?""",
                (
                    BulkRecipientStatus.PROCESSING.value, now, now, job_id, int(row["user_id"]),
                    BulkRecipientStatus.PENDING.value,
                ),
            )
            connection.commit()
            refreshed = connection.execute(
                "SELECT * FROM bulk_recipients WHERE job_id=? AND user_id=?",
                (job_id, int(row["user_id"])),
            ).fetchone()
            return _row_to_recipient(refreshed)
        except sqlite3.Error:
            connection.rollback(); raise

    def mark_recipient_sent(
        self,
        recipient: BulkRecipient,
        *,
        response_type: str,
        message_id: int | None,
    ) -> None:
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE bulk_recipients SET status=?,error_code=NULL,error_type=NULL,
                    response_type=?,message_id=?,sent_at=?,updated_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    BulkRecipientStatus.SENT.value, response_type, message_id, now, now,
                    recipient.job_id, recipient.user.peer.id,
                ),
            )
        self.refresh_job_counts(recipient.job_id)

    def mark_recipient_error(
        self,
        recipient: BulkRecipient,
        *,
        retry: bool,
        error_code: str | None,
        error_type: str,
    ) -> None:
        now = _utc_now()
        status = BulkRecipientStatus.PENDING if retry else BulkRecipientStatus.FAILED
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE bulk_recipients SET status=?,error_code=?,error_type=?,updated_at=?
                   WHERE job_id=? AND user_id=?""",
                (status.value, error_code, error_type, now, recipient.job_id, recipient.user.peer.id),
            )
        self.refresh_job_counts(recipient.job_id)

    def refresh_job_counts(self, job_id: str) -> BulkJob:
        connection = self._require_connection()
        counts = {
            str(row["status"]): int(row["count"])
            for row in connection.execute(
                "SELECT status,COUNT(*) AS count FROM bulk_recipients WHERE job_id=? GROUP BY status",
                (job_id,),
            ).fetchall()
        }
        with connection:
            connection.execute(
                """UPDATE bulk_jobs SET sent_count=?,failed_count=?,skipped_count=?,updated_at=?
                   WHERE job_id=?""",
                (
                    counts.get(BulkRecipientStatus.SENT.value, 0),
                    counts.get(BulkRecipientStatus.FAILED.value, 0),
                    counts.get(BulkRecipientStatus.SKIPPED.value, 0),
                    _utc_now(), job_id,
                ),
            )
        job = self.get_job(job_id)
        assert job is not None
        return job

    def report(self, job_id: str) -> BulkRunReport:
        job = self.refresh_job_counts(job_id)
        rows = self._require_connection().execute(
            "SELECT status,COUNT(*) AS count FROM bulk_recipients WHERE job_id=? GROUP BY status",
            (job_id,),
        ).fetchall()
        counts = {str(row["status"]): int(row["count"]) for row in rows}
        return BulkRunReport(
            job=job,
            pending=counts.get(BulkRecipientStatus.PENDING.value, 0),
            processing=counts.get(BulkRecipientStatus.PROCESSING.value, 0),
        )

    def list_recipients(
        self,
        job_id: str,
        *,
        status: BulkRecipientStatus | None = None,
        limit: int = 1000,
    ) -> tuple[BulkRecipient, ...]:
        sql = "SELECT * FROM bulk_recipients WHERE job_id=?"
        params: list[object] = [job_id]
        if status:
            sql += " AND status=?"; params.append(status.value)
        sql += " ORDER BY user_id LIMIT ?"; params.append(limit)
        rows = self._require_connection().execute(sql, params).fetchall()
        return tuple(_row_to_recipient(row) for row in rows)

    # ------------------------------------------------------------------
    # Bulk-message deletion state
    # ------------------------------------------------------------------
    def prepare_bulk_message_deletion(self, job_id: str) -> None:
        now = _utc_now()
        connection = self._require_connection()
        with connection:
            connection.execute(
                """UPDATE bulk_recipients SET delete_status=?,delete_error_code=NULL,
                       delete_error_type=NULL,delete_updated_at=?
                   WHERE job_id=? AND status=? AND message_id IS NOT NULL
                     AND delete_status=?""",
                (
                    BulkDeleteStatus.PENDING.value, now, job_id,
                    BulkRecipientStatus.SENT.value, BulkDeleteStatus.NOT_REQUESTED.value,
                ),
            )
            connection.execute(
                """UPDATE bulk_recipients SET delete_status=?,delete_error_code='MESSAGE_ID_MISSING',
                       delete_error_type='send_response_did_not_expose_message_id',delete_updated_at=?
                   WHERE job_id=? AND status=? AND message_id IS NULL
                     AND delete_status=?""",
                (
                    BulkDeleteStatus.SKIPPED_MISSING_ID.value, now, job_id,
                    BulkRecipientStatus.SENT.value, BulkDeleteStatus.NOT_REQUESTED.value,
                ),
            )

    def recover_bulk_delete_processing(self, job_id: str) -> int:
        now = _utc_now()
        with self._require_connection():
            cursor = self._require_connection().execute(
                """UPDATE bulk_recipients SET delete_status=?,delete_error_code='INTERRUPTED',
                       delete_error_type='previous_process_stopped',delete_updated_at=?
                   WHERE job_id=? AND delete_status=?""",
                (
                    BulkDeleteStatus.PENDING.value, now, job_id,
                    BulkDeleteStatus.PROCESSING.value,
                ),
            )
        return int(cursor.rowcount)

    def claim_next_message_deletion(
        self, job_id: str, *, max_attempts: int
    ) -> BulkRecipient | None:
        connection = self._require_connection()
        now = _utc_now()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT * FROM bulk_recipients
                   WHERE job_id=? AND delete_status IN (?,?) AND delete_attempts < ?
                     AND message_id IS NOT NULL
                   ORDER BY user_id LIMIT 1""",
                (
                    job_id, BulkDeleteStatus.PENDING.value, BulkDeleteStatus.FAILED.value,
                    max_attempts,
                ),
            ).fetchone()
            if row is None:
                connection.commit()
                return None
            connection.execute(
                """UPDATE bulk_recipients
                   SET delete_status=?,delete_attempts=delete_attempts+1,delete_updated_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    BulkDeleteStatus.PROCESSING.value, now, job_id, int(row["user_id"]),
                ),
            )
            connection.commit()
            refreshed = connection.execute(
                "SELECT * FROM bulk_recipients WHERE job_id=? AND user_id=?",
                (job_id, int(row["user_id"])),
            ).fetchone()
            return _row_to_recipient(refreshed)
        except sqlite3.Error:
            connection.rollback()
            raise

    def mark_message_deleted(
        self, recipient: BulkRecipient, *, response_type: str
    ) -> None:
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE bulk_recipients SET delete_status=?,delete_error_code=NULL,
                       delete_error_type=NULL,delete_response_type=?,delete_updated_at=?,deleted_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    BulkDeleteStatus.DELETED.value, response_type, now, now,
                    recipient.job_id, recipient.user.peer.id,
                ),
            )

    def mark_message_delete_error(
        self,
        recipient: BulkRecipient,
        *,
        retry: bool,
        error_code: str | None,
        error_type: str,
    ) -> None:
        now = _utc_now()
        status = BulkDeleteStatus.PENDING if retry else BulkDeleteStatus.FAILED
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE bulk_recipients SET delete_status=?,delete_error_code=?,
                       delete_error_type=?,delete_updated_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    status.value, error_code, error_type, now,
                    recipient.job_id, recipient.user.peer.id,
                ),
            )

    def bulk_message_delete_report(
        self,
        job_id: str,
        *,
        revoke: bool,
        stop_reason: str | None = None,
    ) -> BulkMessageDeleteReport:
        connection = self._require_connection()
        sent_recipients = int(connection.execute(
            "SELECT COUNT(*) FROM bulk_recipients WHERE job_id=? AND status=?",
            (job_id, BulkRecipientStatus.SENT.value),
        ).fetchone()[0])
        rows = connection.execute(
            """SELECT delete_status,COUNT(*) AS count FROM bulk_recipients
               WHERE job_id=? AND status=? GROUP BY delete_status""",
            (job_id, BulkRecipientStatus.SENT.value),
        ).fetchall()
        counts = {str(row["delete_status"]): int(row["count"]) for row in rows}
        pending = counts.get(BulkDeleteStatus.PENDING.value, 0)
        processing = counts.get(BulkDeleteStatus.PROCESSING.value, 0)
        eligible = sent_recipients - counts.get(BulkDeleteStatus.SKIPPED_MISSING_ID.value, 0)
        return BulkMessageDeleteReport(
            job_id=job_id,
            sent_recipients=sent_recipients,
            eligible=eligible,
            deleted=counts.get(BulkDeleteStatus.DELETED.value, 0),
            failed=counts.get(BulkDeleteStatus.FAILED.value, 0),
            missing_message_id=counts.get(BulkDeleteStatus.SKIPPED_MISSING_ID.value, 0),
            pending=pending,
            processing=processing,
            revoke=revoke,
            complete=pending == 0 and processing == 0,
            stop_reason=stop_reason,
        )

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close(); self._connection = None

    def _require_connection(self) -> sqlite3.Connection:
        if self._connection is None:
            self.initialize()
        assert self._connection is not None
        return self._connection

    def _emit(
        self,
        component: str,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit(component, event, level=level, fields=fields)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _dt(value: str | None) -> datetime | None:
    if not value:
        return None
    result = datetime.fromisoformat(value)
    return result if result.tzinfo else result.replace(tzinfo=timezone.utc)


def _member_values(member: CommunityMember) -> tuple[object, ...]:
    user = member.user
    status = user.status
    return (
        user.peer.access_hash,
        user.first_name,
        user.last_name,
        user.username,
        str(user.phone) if user.phone else None,
        status.kind.value if status else None,
        status.expires_at.isoformat() if status and status.expires_at else None,
        status.was_online_at.isoformat() if status and status.was_online_at else None,
        int(user.is_contact),
        int(user.is_mutual_contact),
        int(user.is_deleted),
        int(user.is_bot),
        int(user.is_verified),
        member.role.value,
        member.state.value,
        member.joined_at.isoformat() if member.joined_at else None,
        member.inviter_id,
        member.promoted_by,
        member.rank,
        int(member.can_edit),
    )



_ARABIC_DIACRITICS = {
    chr(code) for code in range(0x064B, 0x0660)
} | {"\u0670"}


def _member_search_variants(value: str) -> tuple[str, ...]:
    """Return safe Persian/Arabic spelling variants for local member search."""
    raw = unicodedata.normalize("NFKC", value).strip()
    if not raw:
        return ("",)

    def clean(text: str) -> str:
        text = "".join(ch for ch in text if ch not in _ARABIC_DIACRITICS)
        return text.replace("\u200c", "").replace("\u200f", "").replace("\u200e", "")

    persian = clean(raw).translate(
        str.maketrans({
            "ي": "ی",
            "ى": "ی",
            "ئ": "ی",
            "ك": "ک",
            "ة": "ه",
            "ۀ": "ه",
        })
    )
    arabic = persian.translate(str.maketrans({"ی": "ي", "ک": "ك"}))
    compact = persian.replace(" ", "")
    variants: list[str] = []
    for item in (clean(raw), persian, arabic, compact):
        if item and item not in variants:
            variants.append(item)
    return tuple(variants)


def _row_to_phone_list(row: sqlite3.Row) -> PhoneRecipientList:
    virtual = Peer(
        int(row["virtual_peer_id"]),
        PeerType.CHAT,
        title=str(row["name"]),
    )
    return PhoneRecipientList(
        id=str(row["list_id"]),
        name=str(row["name"]),
        virtual_community=virtual,
        status=PhoneListStatus(str(row["status"])),
        source_name=str(row["source_name"]),
        total_rows=int(row["total_rows"]),
        valid_unique=int(row["valid_unique"]),
        duplicate_count=int(row["duplicate_count"]),
        invalid_count=int(row["invalid_count"]),
        pending_count=int(row["pending_count"]),
        resolved_count=int(row["resolved_count"]),
        not_found_count=int(row["not_found_count"]),
        failed_count=int(row["failed_count"]),
        stop_reason=row["stop_reason"],
        created_at=_dt(row["created_at"]),
        updated_at=_dt(row["updated_at"]),
        resolved_at=_dt(row["resolved_at"]),
    )


def _row_to_phone_entry(row: sqlite3.Row) -> PhoneListEntry:
    phone = None
    if row["phone"]:
        try:
            phone = PhoneNumber.parse(str(row["phone"]))
        except Exception:
            phone = None
    user = None
    if row["user_id"] is not None:
        user = User(
            peer=Peer(
                int(row["user_id"]),
                PeerType.USER,
                row["access_hash"],
                row["username"],
            ),
            first_name=row["resolved_first_name"] or row["first_name"],
            last_name=row["resolved_last_name"] or row["last_name"],
            username=row["username"],
            phone=phone,
            is_contact=True,
        )
    return PhoneListEntry(
        id=int(row["entry_id"]),
        list_id=str(row["list_id"]),
        row_number=int(row["row_number"]),
        phone=phone,
        first_name=str(row["first_name"] or "Eitaa"),
        last_name=str(row["last_name"] or ""),
        status=PhoneEntryStatus(str(row["status"])),
        attempts=int(row["attempts"]),
        user=user,
        error_code=row["error_code"],
        error_type=row["error_type"],
        contact_source=(
            ContactResolutionSource(str(row["contact_source"]))
            if row["contact_source"] else None
        ),
        contact_added_by_list=bool(row["contact_added_by_list"]),
        cleanup_status=PhoneCleanupStatus(str(row["cleanup_status"])),
        cleanup_attempts=int(row["cleanup_attempts"]),
        cleanup_error_code=row["cleanup_error_code"],
        cleanup_error_type=row["cleanup_error_type"],
        cleanup_response_type=row["cleanup_response_type"],
        cleanup_updated_at=_dt(row["cleanup_updated_at"]),
        removed_at=_dt(row["removed_at"]),
        created_at=_dt(row["created_at"]),
        updated_at=_dt(row["updated_at"]),
        resolved_at=_dt(row["resolved_at"]),
    )

def _row_to_member(row: sqlite3.Row, community: Peer) -> CommunityMember:
    status = None
    if row["status_kind"]:
        status = UserStatus(
            UserStatusKind(str(row["status_kind"])),
            expires_at=_dt(row["status_expires_at"]),
            was_online_at=_dt(row["status_was_online_at"]),
        )
    phone = None
    if row["phone"]:
        try:
            phone = PhoneNumber.parse(str(row["phone"]))
        except Exception:
            phone = None
    user = User(
        peer=Peer(int(row["user_id"]), PeerType.USER, row["access_hash"], row["username"]),
        first_name=row["first_name"], last_name=row["last_name"], username=row["username"],
        phone=phone, status=status, is_contact=bool(row["is_contact"]),
        is_mutual_contact=bool(row["is_mutual_contact"]), is_deleted=bool(row["is_deleted"]),
        is_bot=bool(row["is_bot"]), is_verified=bool(row["is_verified"]),
    )
    return CommunityMember(
        community=community, user=user, role=MemberRole(str(row["role"])),
        state=MemberState(str(row["state"])), joined_at=_dt(row["joined_at"]),
        inviter_id=row["inviter_id"], promoted_by=row["promoted_by"], rank=row["rank"],
        can_edit=bool(row["can_edit"]), fetched_at=_dt(row["last_seen_at"]) or datetime.now(timezone.utc),
    )


def _row_to_job(row: sqlite3.Row) -> BulkJob:
    community = Peer(
        int(row["community_id"]), PeerType(str(row["community_type"])),
        row["community_access_hash"], row["community_username"], row["community_title"],
    )
    spec = BulkMessageSpec(
        kind=SendKind(str(row["kind"])), text=str(row["text"] or ""),
        file_path=Path(str(row["file_path"])) if row["file_path"] else None,
        caption=str(row["caption"] or ""), mime_type=row["mime_type"],
    )
    options = BulkSendOptions(
        delay_seconds=float(row["delay_seconds"]), max_attempts=int(row["max_attempts"]),
        retry_delay_seconds=float(row["retry_delay_seconds"]), test_limit=row["test_limit"],
        stop_on_server_error=bool(row["stop_on_server_error"]),
    )
    return BulkJob(
        id=str(row["job_id"]), community=community, spec=spec, options=options,
        status=BulkJobStatus(str(row["status"])), recipient_count=int(row["recipient_count"]),
        sent_count=int(row["sent_count"]), failed_count=int(row["failed_count"]),
        skipped_count=int(row["skipped_count"]), stop_reason=row["stop_reason"],
        created_at=_dt(row["created_at"]), updated_at=_dt(row["updated_at"]),
        started_at=_dt(row["started_at"]), finished_at=_dt(row["finished_at"]),
    )


def _row_to_recipient(row: sqlite3.Row) -> BulkRecipient:
    user = User(
        peer=Peer(int(row["user_id"]), PeerType.USER, row["access_hash"], row["username"]),
        first_name=row["first_name"], last_name=row["last_name"], username=row["username"],
    )
    return BulkRecipient(
        job_id=str(row["job_id"]), user=user, role=MemberRole(str(row["role"])),
        status=BulkRecipientStatus(str(row["status"])), random_id=int(row["random_id"]),
        attempts=int(row["attempts"]), error_code=row["error_code"], error_type=row["error_type"],
        response_type=row["response_type"], message_id=row["message_id"],
        last_attempt_at=_dt(row["last_attempt_at"]), sent_at=_dt(row["sent_at"]),
        delete_status=BulkDeleteStatus(str(row["delete_status"])),
        delete_attempts=int(row["delete_attempts"]),
        delete_error_code=row["delete_error_code"],
        delete_error_type=row["delete_error_type"],
        delete_response_type=row["delete_response_type"],
        delete_updated_at=_dt(row["delete_updated_at"]),
        deleted_at=_dt(row["deleted_at"]),
    )

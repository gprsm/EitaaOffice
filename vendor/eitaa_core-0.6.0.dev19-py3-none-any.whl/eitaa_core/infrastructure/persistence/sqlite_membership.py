"""SQLite persistence for reversible Core 7.4 membership jobs."""

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

from ...domain.enums import (
    MembershipAddStatus,
    MembershipJobStatus,
    MembershipRollbackStatus,
    PeerType,
    PhoneEntryStatus,
)
from ...domain.membership import (
    MembershipInviteOptions,
    MembershipJob,
    MembershipPreview,
    MembershipRecipient,
    MembershipRollbackReport,
    MembershipRunReport,
)
from ...domain.peer import Peer
from ...domain.user import User
from ...errors import MembershipError, MessageStoreError
from ..diagnostics import DiagnosticManager
from .sqlite_messages import SCHEMA_VERSION, SQLiteMessageRepository


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _dt(value: str | None) -> datetime | None:
    return datetime.fromisoformat(value) if value else None


class SQLiteMembershipRepository:
    """Persist membership invitation/rollback state in the cumulative database."""

    def __init__(
        self, path: Path | str, diagnostics: DiagnosticManager | None = None
    ) -> None:
        self.path = Path(path)
        self.diagnostics = diagnostics
        self._connection: sqlite3.Connection | None = None

    def initialize(self) -> None:
        if self._connection is not None:
            return
        migrator = SQLiteMessageRepository(self.path, self.diagnostics)
        migrator.initialize()
        migrator.close()
        try:
            connection = sqlite3.connect(self.path, timeout=30)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA journal_mode = WAL")
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if version != SCHEMA_VERSION:
                raise MessageStoreError(
                    "Membership repository schema mismatch.",
                    safe_context={
                        "database_version": version,
                        "supported_version": SCHEMA_VERSION,
                    },
                )
            self._connection = connection
            self._emit("membership_database_initialized", {"schema_version": version})
        except sqlite3.Error as exc:
            raise MessageStoreError(
                "Could not initialize membership SQLite repository.",
                safe_context={"sqlite_error": type(exc).__name__},
            ) from exc

    def preview(
        self,
        list_id: str,
        target: Peer,
        *,
        test_limit: int | None = None,
        sample_limit: int = 10,
    ) -> MembershipPreview:
        if test_limit is not None and test_limit < 1:
            raise MembershipError("test_limit must be positive.")
        connection = self._require_connection()
        meta = connection.execute(
            "SELECT valid_unique,resolved_count FROM phone_recipient_lists WHERE list_id=?",
            (list_id,),
        ).fetchone()
        if meta is None:
            raise MembershipError(
                "Phone recipient list was not found.", safe_context={"list_id": list_id}
            )
        rows = connection.execute(
            """SELECT e.entry_id,e.user_id,e.access_hash,e.resolved_first_name,
                      e.resolved_last_name,e.username,
                      CASE WHEN m.user_id IS NULL THEN 0 ELSE 1 END AS known_existing
               FROM phone_recipient_entries e
               LEFT JOIN community_members m
                 ON m.community_type=? AND m.community_id=? AND m.user_id=e.user_id
                AND m.state='active'
               WHERE e.list_id=? AND e.status=?
                 AND e.user_id IS NOT NULL AND e.access_hash IS NOT NULL
               ORDER BY e.row_number,e.entry_id""",
            (target.type.value, target.id, list_id, PhoneEntryStatus.RESOLVED.value),
        ).fetchall()
        selected = rows[:test_limit] if test_limit is not None else rows
        sample = tuple(
            {
                "user_id": int(row["user_id"]),
                "display_name": _display_name(row),
                "known_existing": bool(row["known_existing"]),
            }
            for row in selected[:sample_limit]
        )
        result = MembershipPreview(
            list_id=list_id,
            target=target,
            eligible_count=len(rows),
            selected_count=len(selected),
            known_existing_count=sum(bool(row["known_existing"]) for row in selected),
            unresolved_count=max(0, int(meta["valid_unique"]) - int(meta["resolved_count"])),
            test_limit=test_limit,
            sample=sample,
        )
        self._emit("membership_preview_created", result.safe_summary())
        return result

    def create_job(
        self,
        list_id: str,
        target: Peer,
        options: MembershipInviteOptions,
    ) -> MembershipJob:
        options.validate()
        preview = self.preview(
            list_id, target, test_limit=options.test_limit, sample_limit=0
        )
        if preview.selected_count == 0:
            raise MembershipError(
                "No resolved sendable users are available for this membership job.",
                safe_context=preview.safe_summary(),
            )
        connection = self._require_connection()
        rows = connection.execute(
            """SELECT e.entry_id,e.user_id,e.access_hash,e.resolved_first_name,
                      e.resolved_last_name,e.username,
                      CASE WHEN m.user_id IS NULL THEN 0 ELSE 1 END AS known_existing
               FROM phone_recipient_entries e
               LEFT JOIN community_members m
                 ON m.community_type=? AND m.community_id=? AND m.user_id=e.user_id
                AND m.state='active'
               WHERE e.list_id=? AND e.status=?
                 AND e.user_id IS NOT NULL AND e.access_hash IS NOT NULL
               ORDER BY e.row_number,e.entry_id""",
            (target.type.value, target.id, list_id, PhoneEntryStatus.RESOLVED.value),
        ).fetchall()
        if options.test_limit is not None:
            rows = rows[: options.test_limit]
        job_id = uuid.uuid4().hex
        now = _utc_now()
        known_existing = sum(bool(row["known_existing"]) for row in rows)
        with connection:
            connection.execute(
                """INSERT INTO membership_jobs(
                    job_id,list_id,target_type,target_id,target_access_hash,
                    target_username,target_title,status,delay_seconds,max_attempts,
                    retry_delay_seconds,test_limit,stop_on_server_error,fwd_limit,
                    recipient_count,added_count,already_member_count,failed_count,
                    skipped_count,created_at,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    job_id,
                    list_id,
                    target.type.value,
                    target.id,
                    target.access_hash,
                    target.username,
                    target.title,
                    MembershipJobStatus.DRAFT.value,
                    options.delay_seconds,
                    options.max_attempts,
                    options.retry_delay_seconds,
                    options.test_limit,
                    int(options.stop_on_server_error),
                    options.fwd_limit,
                    len(rows),
                    0,
                    known_existing,
                    0,
                    0,
                    now,
                    now,
                ),
            )
            for row in rows:
                existing = bool(row["known_existing"])
                connection.execute(
                    """INSERT INTO membership_recipients(
                        job_id,entry_id,user_id,access_hash,first_name,last_name,
                        username,add_status,add_attempts,previously_member,
                        added_by_job,rollback_status
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        job_id,
                        int(row["entry_id"]),
                        int(row["user_id"]),
                        row["access_hash"],
                        row["resolved_first_name"],
                        row["resolved_last_name"],
                        row["username"],
                        (
                            MembershipAddStatus.ALREADY_MEMBER.value
                            if existing
                            else MembershipAddStatus.PENDING.value
                        ),
                        0,
                        1 if existing else None,
                        0,
                        MembershipRollbackStatus.NOT_REQUIRED.value,
                    ),
                )
        job = self.get_job(job_id)
        assert job is not None
        self._emit("membership_job_created", job.safe_summary())
        return job

    def get_job(self, job_id: str) -> MembershipJob | None:
        row = self._require_connection().execute(
            "SELECT * FROM membership_jobs WHERE job_id=?", (job_id,)
        ).fetchone()
        return _row_to_job(row) if row else None

    def jobs(self, *, limit: int = 100) -> tuple[MembershipJob, ...]:
        rows = self._require_connection().execute(
            "SELECT * FROM membership_jobs ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return tuple(_row_to_job(row) for row in rows)

    def set_job_status(
        self,
        job_id: str,
        status: MembershipJobStatus,
        *,
        stop_reason: str | None = None,
    ) -> MembershipJob:
        now = _utc_now()
        started_at = now if status is MembershipJobStatus.RUNNING else None
        finished_at = (
            now
            if status
            in {
                MembershipJobStatus.COMPLETED,
                MembershipJobStatus.CANCELLED,
                MembershipJobStatus.BLOCKED,
                MembershipJobStatus.FAILED,
            }
            else None
        )
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE membership_jobs SET status=?,stop_reason=?,updated_at=?,
                   started_at=COALESCE(started_at,?),finished_at=COALESCE(?,finished_at)
                   WHERE job_id=?""",
                (status.value, stop_reason, now, started_at, finished_at, job_id),
            )
        job = self.get_job(job_id)
        if job is None:
            raise MembershipError(
                "Membership job was not found.", safe_context={"job_id": job_id}
            )
        return job

    def recover_processing(self, job_id: str) -> int:
        now = _utc_now()
        with self._require_connection():
            cursor = self._require_connection().execute(
                """UPDATE membership_recipients
                   SET add_status=?,add_error_code=?,add_error_type=?,last_attempt_at=?
                   WHERE job_id=? AND add_status=?""",
                (
                    MembershipAddStatus.PENDING.value,
                    "INTERRUPTED",
                    "previous_process_stopped",
                    now,
                    job_id,
                    MembershipAddStatus.PROCESSING.value,
                ),
            )
        return int(cursor.rowcount)

    def claim_recipient(
        self, job_id: str, *, max_attempts: int
    ) -> MembershipRecipient | None:
        connection = self._require_connection()
        now = _utc_now()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT * FROM membership_recipients
                   WHERE job_id=? AND add_status=? AND add_attempts < ?
                   ORDER BY user_id LIMIT 1""",
                (
                    job_id,
                    MembershipAddStatus.PENDING.value,
                    max_attempts,
                ),
            ).fetchone()
            if row is None:
                connection.commit()
                return None
            connection.execute(
                """UPDATE membership_recipients
                   SET add_status=?,add_attempts=add_attempts+1,last_attempt_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    MembershipAddStatus.PROCESSING.value,
                    now,
                    job_id,
                    int(row["user_id"]),
                ),
            )
            connection.commit()
            refreshed = connection.execute(
                "SELECT * FROM membership_recipients WHERE job_id=? AND user_id=?",
                (job_id, int(row["user_id"])),
            ).fetchone()
            return _row_to_recipient(refreshed)
        except sqlite3.Error:
            connection.rollback()
            raise

    def mark_already_member(
        self,
        recipient: MembershipRecipient,
        *,
        response_type: str,
    ) -> None:
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE membership_recipients SET add_status=?,previously_member=1,
                   added_by_job=0,add_error_code=NULL,add_error_type=NULL,
                   add_response_type=?,rollback_status=?,last_attempt_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    MembershipAddStatus.ALREADY_MEMBER.value,
                    response_type,
                    MembershipRollbackStatus.NOT_REQUIRED.value,
                    now,
                    recipient.job_id,
                    recipient.user.peer.id,
                ),
            )
        self.refresh_counts(recipient.job_id)

    def mark_added(
        self, recipient: MembershipRecipient, *, response_type: str
    ) -> None:
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE membership_recipients SET add_status=?,previously_member=0,
                   added_by_job=1,add_error_code=NULL,add_error_type=NULL,
                   add_response_type=?,added_at=?,rollback_status=?
                   WHERE job_id=? AND user_id=?""",
                (
                    MembershipAddStatus.ADDED.value,
                    response_type,
                    now,
                    MembershipRollbackStatus.ELIGIBLE.value,
                    recipient.job_id,
                    recipient.user.peer.id,
                ),
            )
        self.refresh_counts(recipient.job_id)

    def mark_add_failed(
        self,
        recipient: MembershipRecipient,
        *,
        retry: bool,
        error_code: str,
        error_type: str,
    ) -> None:
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE membership_recipients SET add_status=?,add_error_code=?,
                   add_error_type=?,add_response_type=NULL
                   WHERE job_id=? AND user_id=?""",
                (
                    (
                        MembershipAddStatus.PENDING.value
                        if retry
                        else MembershipAddStatus.FAILED.value
                    ),
                    error_code,
                    error_type,
                    recipient.job_id,
                    recipient.user.peer.id,
                ),
            )
        self.refresh_counts(recipient.job_id)

    def refresh_counts(self, job_id: str) -> MembershipJob:
        connection = self._require_connection()
        counts = {
            str(row["add_status"]): int(row["count"])
            for row in connection.execute(
                """SELECT add_status,COUNT(*) AS count FROM membership_recipients
                   WHERE job_id=? GROUP BY add_status""",
                (job_id,),
            ).fetchall()
        }
        now = _utc_now()
        with connection:
            connection.execute(
                """UPDATE membership_jobs SET added_count=?,already_member_count=?,
                   failed_count=?,skipped_count=?,updated_at=? WHERE job_id=?""",
                (
                    counts.get(MembershipAddStatus.ADDED.value, 0),
                    counts.get(MembershipAddStatus.ALREADY_MEMBER.value, 0),
                    counts.get(MembershipAddStatus.FAILED.value, 0),
                    counts.get(MembershipAddStatus.SKIPPED.value, 0),
                    now,
                    job_id,
                ),
            )
        job = self.get_job(job_id)
        if job is None:
            raise MembershipError(
                "Membership job was not found.", safe_context={"job_id": job_id}
            )
        return job

    def report(self, job_id: str) -> MembershipRunReport:
        job = self.refresh_counts(job_id)
        row = self._require_connection().execute(
            """SELECT
                SUM(CASE WHEN add_status=? THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN add_status=? THEN 1 ELSE 0 END) AS processing
               FROM membership_recipients WHERE job_id=?""",
            (
                MembershipAddStatus.PENDING.value,
                MembershipAddStatus.PROCESSING.value,
                job_id,
            ),
        ).fetchone()
        return MembershipRunReport(
            job=job,
            pending=int(row["pending"] or 0),
            processing=int(row["processing"] or 0),
        )

    def recipients(
        self,
        job_id: str,
        *,
        add_status: MembershipAddStatus | None = None,
        limit: int = 1000,
    ) -> tuple[MembershipRecipient, ...]:
        sql = "SELECT * FROM membership_recipients WHERE job_id=?"
        params: list[object] = [job_id]
        if add_status is not None:
            sql += " AND add_status=?"
            params.append(add_status.value)
        sql += " ORDER BY user_id LIMIT ?"
        params.append(limit)
        rows = self._require_connection().execute(sql, params).fetchall()
        return tuple(_row_to_recipient(row) for row in rows)

    # ------------------------------------------------------------------
    # Rollback
    # ------------------------------------------------------------------
    def start_rollback(self, job_id: str) -> None:
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE membership_jobs SET rollback_started_at=COALESCE(rollback_started_at,?),
                   rollback_finished_at=NULL,rollback_stop_reason=NULL,updated_at=?
                   WHERE job_id=?""",
                (now, now, job_id),
            )

    def finish_rollback(self, job_id: str, *, stop_reason: str | None = None) -> None:
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE membership_jobs SET rollback_finished_at=?,
                   rollback_stop_reason=?,updated_at=? WHERE job_id=?""",
                (now, stop_reason, now, job_id),
            )

    def recover_rollback_processing(self, job_id: str) -> int:
        now = _utc_now()
        with self._require_connection():
            cursor = self._require_connection().execute(
                """UPDATE membership_recipients SET rollback_status=?,
                   rollback_error_code=?,rollback_error_type=?,rollback_updated_at=?
                   WHERE job_id=? AND rollback_status=?""",
                (
                    MembershipRollbackStatus.ELIGIBLE.value,
                    "INTERRUPTED",
                    "previous_process_stopped",
                    now,
                    job_id,
                    MembershipRollbackStatus.PROCESSING.value,
                ),
            )
        return int(cursor.rowcount)

    def claim_rollback(
        self, job_id: str, *, max_attempts: int
    ) -> MembershipRecipient | None:
        connection = self._require_connection()
        now = _utc_now()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT * FROM membership_recipients
                   WHERE job_id=? AND added_by_job=1
                     AND rollback_status=? AND rollback_attempts < ?
                   ORDER BY user_id LIMIT 1""",
                (
                    job_id,
                    MembershipRollbackStatus.ELIGIBLE.value,
                    max_attempts,
                ),
            ).fetchone()
            if row is None:
                connection.commit()
                return None
            connection.execute(
                """UPDATE membership_recipients SET rollback_status=?,
                   rollback_attempts=rollback_attempts+1,rollback_updated_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    MembershipRollbackStatus.PROCESSING.value,
                    now,
                    job_id,
                    int(row["user_id"]),
                ),
            )
            connection.commit()
            refreshed = connection.execute(
                "SELECT * FROM membership_recipients WHERE job_id=? AND user_id=?",
                (job_id, int(row["user_id"])),
            ).fetchone()
            return _row_to_recipient(refreshed)
        except sqlite3.Error:
            connection.rollback()
            raise

    def mark_rollback_removed(
        self,
        recipient: MembershipRecipient,
        *,
        response_type: str,
        ban_released: bool | None,
    ) -> None:
        now = _utc_now()
        status = (
            MembershipRollbackStatus.REMOVED_BUT_RESTRICTED
            if ban_released is False
            else MembershipRollbackStatus.REMOVED
        )
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE membership_recipients SET rollback_status=?,
                   rollback_error_code=NULL,rollback_error_type=NULL,
                   rollback_response_type=?,rollback_updated_at=?,removed_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    status.value,
                    response_type,
                    now,
                    now,
                    recipient.job_id,
                    recipient.user.peer.id,
                ),
            )

    def mark_rollback_failed(
        self,
        recipient: MembershipRecipient,
        *,
        retry: bool,
        error_code: str,
        error_type: str,
    ) -> None:
        now = _utc_now()
        with self._require_connection():
            self._require_connection().execute(
                """UPDATE membership_recipients SET rollback_status=?,
                   rollback_error_code=?,rollback_error_type=?,rollback_updated_at=?
                   WHERE job_id=? AND user_id=?""",
                (
                    (
                        MembershipRollbackStatus.ELIGIBLE.value
                        if retry
                        else MembershipRollbackStatus.FAILED.value
                    ),
                    error_code,
                    error_type,
                    now,
                    recipient.job_id,
                    recipient.user.peer.id,
                ),
            )

    def rollback_report(self, job_id: str) -> MembershipRollbackReport:
        job = self.get_job(job_id)
        if job is None:
            raise MembershipError(
                "Membership job was not found.", safe_context={"job_id": job_id}
            )
        rows = self._require_connection().execute(
            """SELECT rollback_status,COUNT(*) AS count
               FROM membership_recipients WHERE job_id=? AND added_by_job=1
               GROUP BY rollback_status""",
            (job_id,),
        ).fetchall()
        counts = {str(row["rollback_status"]): int(row["count"]) for row in rows}
        pending = counts.get(MembershipRollbackStatus.ELIGIBLE.value, 0)
        processing = counts.get(MembershipRollbackStatus.PROCESSING.value, 0)
        return MembershipRollbackReport(
            job_id=job_id,
            added_by_job=sum(counts.values()),
            eligible=pending,
            removed=counts.get(MembershipRollbackStatus.REMOVED.value, 0),
            removed_but_restricted=counts.get(
                MembershipRollbackStatus.REMOVED_BUT_RESTRICTED.value, 0
            ),
            failed=counts.get(MembershipRollbackStatus.FAILED.value, 0),
            pending=pending,
            processing=processing,
            complete=pending == 0 and processing == 0,
            stop_reason=job.rollback_stop_reason,
        )

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    def _require_connection(self) -> sqlite3.Connection:
        if self._connection is None:
            raise MessageStoreError("Membership repository is not initialized.")
        return self._connection

    def _emit(self, event: str, fields: dict[str, object]) -> None:
        if self.diagnostics:
            self.diagnostics.emit("membership", event, fields=fields)


def _display_name(row: sqlite3.Row) -> str:
    name = " ".join(
        item
        for item in (row["resolved_first_name"], row["resolved_last_name"])
        if item
    ).strip()
    return name or row["username"] or str(row["user_id"])


def _row_to_job(row: sqlite3.Row) -> MembershipJob:
    target = Peer(
        id=int(row["target_id"]),
        type=PeerType(str(row["target_type"])),
        access_hash=row["target_access_hash"],
        username=row["target_username"],
        title=row["target_title"],
    )
    options = MembershipInviteOptions(
        delay_seconds=float(row["delay_seconds"]),
        max_attempts=int(row["max_attempts"]),
        retry_delay_seconds=float(row["retry_delay_seconds"]),
        test_limit=(int(row["test_limit"]) if row["test_limit"] is not None else None),
        stop_on_server_error=bool(row["stop_on_server_error"]),
        fwd_limit=int(row["fwd_limit"]),
    )
    return MembershipJob(
        id=str(row["job_id"]),
        list_id=str(row["list_id"]),
        target=target,
        options=options,
        status=MembershipJobStatus(str(row["status"])),
        recipient_count=int(row["recipient_count"]),
        added_count=int(row["added_count"]),
        already_member_count=int(row["already_member_count"]),
        failed_count=int(row["failed_count"]),
        skipped_count=int(row["skipped_count"]),
        stop_reason=row["stop_reason"],
        created_at=_dt(row["created_at"]),
        updated_at=_dt(row["updated_at"]),
        started_at=_dt(row["started_at"]),
        finished_at=_dt(row["finished_at"]),
        rollback_started_at=_dt(row["rollback_started_at"]),
        rollback_finished_at=_dt(row["rollback_finished_at"]),
        rollback_stop_reason=row["rollback_stop_reason"],
    )


def _row_to_recipient(row: sqlite3.Row) -> MembershipRecipient:
    user = User(
        peer=Peer(
            id=int(row["user_id"]),
            type=PeerType.USER,
            access_hash=row["access_hash"],
            username=row["username"],
            title=_display_name_from_membership(row),
        ),
        first_name=row["first_name"],
        last_name=row["last_name"],
        username=row["username"],
    )
    previous = row["previously_member"]
    return MembershipRecipient(
        job_id=str(row["job_id"]),
        entry_id=int(row["entry_id"]),
        user=user,
        add_status=MembershipAddStatus(str(row["add_status"])),
        add_attempts=int(row["add_attempts"]),
        previously_member=(bool(previous) if previous is not None else None),
        added_by_job=bool(row["added_by_job"]),
        add_error_code=row["add_error_code"],
        add_error_type=row["add_error_type"],
        add_response_type=row["add_response_type"],
        last_attempt_at=_dt(row["last_attempt_at"]),
        added_at=_dt(row["added_at"]),
        rollback_status=MembershipRollbackStatus(str(row["rollback_status"])),
        rollback_attempts=int(row["rollback_attempts"]),
        rollback_error_code=row["rollback_error_code"],
        rollback_error_type=row["rollback_error_type"],
        rollback_response_type=row["rollback_response_type"],
        rollback_updated_at=_dt(row["rollback_updated_at"]),
        removed_at=_dt(row["removed_at"]),
    )


def _display_name_from_membership(row: sqlite3.Row) -> str:
    name = " ".join(item for item in (row["first_name"], row["last_name"]) if item).strip()
    return name or row["username"] or str(row["user_id"])

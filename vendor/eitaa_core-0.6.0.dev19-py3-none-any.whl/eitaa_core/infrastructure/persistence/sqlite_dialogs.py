"""SQLite adapter for complete dialog snapshots and avatar cache paths."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from ...domain.discovery import (
    DialogCollection, DialogEntry, PeerPhotoReference, PhotoLocationReference,
)
from ...domain.enums import DialogKind, PeerType
from ...domain.peer import Peer
from ...errors import MessageStoreError
from ..diagnostics import DiagnosticManager
from .sqlite_messages import SCHEMA_VERSION


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class SQLiteDialogRepository:
    """Persist one current row per dialog without deleting older app data."""

    def __init__(self, path: Path | str, diagnostics: DiagnosticManager | None = None) -> None:
        self.path = Path(path)
        self.diagnostics = diagnostics
        self._connection: sqlite3.Connection | None = None

    def initialize(self) -> None:
        if self._connection is not None:
            return
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")
        version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        if version < SCHEMA_VERSION:
            connection.close()
            raise MessageStoreError(
                "Dialog tables require the current database migration.",
                safe_context={"database_version": version, "required_version": SCHEMA_VERSION},
            )
        self._connection = connection

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    def store_snapshot(self, result: DialogCollection) -> int:
        connection = self._require_connection()
        sync_id = uuid4().hex
        now = _now()
        try:
            with connection:
                connection.execute(
                    """INSERT INTO dialog_sync_runs
                       (sync_id, started_at, finished_at, server_total_count,
                        received_count, pages_fetched, complete)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (sync_id, now, now, result.total_count, len(result.dialogs),
                     result.pages_fetched, int(result.complete)),
                )
                for item in result.dialogs:
                    photo = item.photo
                    small = photo.small if photo else None
                    big = photo.big if photo else None
                    connection.execute(
                        """INSERT INTO dialogs (
                            peer_type, peer_id, access_hash, username, title, kind,
                            top_message_id, top_message_date, unread_count,
                            unread_mentions_count, read_inbox_max_id, read_outbox_max_id,
                            pinned, unread_mark, folder_id, broadcast, megagroup,
                            participants_count, photo_id, photo_dc_id, photo_has_video,
                            photo_small_constructor, photo_small_dc_id,
                            photo_small_volume_id, photo_small_local_id, photo_small_secret,
                            photo_big_constructor, photo_big_dc_id, photo_big_volume_id,
                            photo_big_local_id, photo_big_secret, photo_cached_path,
                            last_sync_id, is_active, updated_at
                        ) VALUES (
                            ?,?,?,?,?,?, ?,?,?,?,?,?, ?,?,?,?,?,?, ?,?,?, ?,?,?,?,?, ?,?,?,?,?,?, ?,?,?
                        )
                        ON CONFLICT(peer_type, peer_id) DO UPDATE SET
                            access_hash=excluded.access_hash,
                            username=excluded.username,
                            title=excluded.title,
                            kind=excluded.kind,
                            top_message_id=excluded.top_message_id,
                            top_message_date=excluded.top_message_date,
                            unread_count=excluded.unread_count,
                            unread_mentions_count=excluded.unread_mentions_count,
                            read_inbox_max_id=excluded.read_inbox_max_id,
                            read_outbox_max_id=excluded.read_outbox_max_id,
                            pinned=excluded.pinned,
                            unread_mark=excluded.unread_mark,
                            folder_id=excluded.folder_id,
                            broadcast=excluded.broadcast,
                            megagroup=excluded.megagroup,
                            participants_count=excluded.participants_count,
                            photo_cached_path=CASE
                                WHEN dialogs.photo_id=excluded.photo_id
                                THEN dialogs.photo_cached_path ELSE NULL END,
                            photo_id=excluded.photo_id,
                            photo_dc_id=excluded.photo_dc_id,
                            photo_has_video=excluded.photo_has_video,
                            photo_small_constructor=excluded.photo_small_constructor,
                            photo_small_dc_id=excluded.photo_small_dc_id,
                            photo_small_volume_id=excluded.photo_small_volume_id,
                            photo_small_local_id=excluded.photo_small_local_id,
                            photo_small_secret=excluded.photo_small_secret,
                            photo_big_constructor=excluded.photo_big_constructor,
                            photo_big_dc_id=excluded.photo_big_dc_id,
                            photo_big_volume_id=excluded.photo_big_volume_id,
                            photo_big_local_id=excluded.photo_big_local_id,
                            photo_big_secret=excluded.photo_big_secret,
                            last_sync_id=excluded.last_sync_id,
                            is_active=1,
                            updated_at=excluded.updated_at""",
                        (
                            item.peer.type.value, item.peer.id, item.peer.access_hash,
                            item.peer.username, item.peer.title, item.kind.value,
                            item.top_message_id, item.top_message_date, item.unread_count,
                            item.unread_mentions_count, item.read_inbox_max_id,
                            item.read_outbox_max_id, int(item.pinned), int(item.unread_mark),
                            item.folder_id, int(item.broadcast), int(item.megagroup),
                            item.participants_count, photo.photo_id if photo else None,
                            photo.dc_id if photo else None, int(photo.has_video) if photo else 0,
                            small.constructor if small else None, small.dc_id if small else None,
                            small.volume_id if small else None, small.local_id if small else None,
                            small.secret if small else None, big.constructor if big else None,
                            big.dc_id if big else None, big.volume_id if big else None,
                            big.local_id if big else None, big.secret if big else None,
                            item.photo_cached_path, sync_id, 1, now,
                        ),
                    )
                if result.complete:
                    connection.execute(
                        "UPDATE dialogs SET is_active=0, updated_at=? WHERE last_sync_id<>?",
                        (now, sync_id),
                    )
        except sqlite3.Error as exc:
            raise MessageStoreError(
                "Could not store the dialog snapshot.",
                safe_context={"sqlite_error": type(exc).__name__, "dialog_count": len(result.dialogs)},
            ) from exc
        return len(result.dialogs)

    def list_dialogs(
        self,
        *,
        kind: DialogKind | None = None,
        active_only: bool = True,
        limit: int = 10_000,
    ) -> tuple[DialogEntry, ...]:
        if limit < 1:
            raise ValueError("limit must be positive")
        clauses: list[str] = []
        values: list[object] = []
        if kind is not None:
            clauses.append("kind=?"); values.append(kind.value)
        if active_only:
            clauses.append("is_active=1")
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        rows = self._require_connection().execute(
            f"SELECT * FROM dialogs{where} ORDER BY pinned DESC, top_message_date DESC, top_message_id DESC LIMIT ?",
            (*values, limit),
        ).fetchall()
        return tuple(self._row_to_dialog(row) for row in rows)

    def set_photo_cache(self, peer: Peer, photo_id: int, path: str) -> None:
        with self._require_connection() as connection:
            connection.execute(
                """UPDATE dialogs SET photo_cached_path=?, updated_at=?
                   WHERE peer_type=? AND peer_id=? AND photo_id=?""",
                (path, _now(), peer.type.value, peer.id, photo_id),
            )

    def mark_read(
        self, peer: Peer, *, max_id: int, remaining_unread_count: int | None = None
    ) -> DialogEntry | None:
        if max_id <= 0:
            raise ValueError("max_id must be positive")
        connection = self._require_connection()
        current = connection.execute(
            "SELECT unread_count, read_inbox_max_id FROM dialogs WHERE peer_type=? AND peer_id=?",
            (peer.type.value, peer.id),
        ).fetchone()
        if current is None:
            return None
        remaining = (
            max(0, int(remaining_unread_count))
            if remaining_unread_count is not None
            else 0
        )
        read_max = max(int(current["read_inbox_max_id"] or 0), int(max_id))
        with connection:
            connection.execute(
                """UPDATE dialogs
                   SET read_inbox_max_id=?, unread_count=?, unread_mark=?,
                       unread_mentions_count=CASE WHEN ?=0 THEN 0 ELSE unread_mentions_count END,
                       updated_at=?
                   WHERE peer_type=? AND peer_id=?""",
                (read_max, remaining, int(remaining > 0), remaining, _now(),
                 peer.type.value, peer.id),
            )
        row = connection.execute(
            "SELECT * FROM dialogs WHERE peer_type=? AND peer_id=?",
            (peer.type.value, peer.id),
        ).fetchone()
        return self._row_to_dialog(row) if row is not None else None

    @staticmethod
    def _location(row: sqlite3.Row, prefix: str) -> PhotoLocationReference | None:
        constructor = row[f"photo_{prefix}_constructor"]
        if constructor is None:
            return None
        return PhotoLocationReference(
            constructor=constructor,
            dc_id=row[f"photo_{prefix}_dc_id"],
            volume_id=row[f"photo_{prefix}_volume_id"],
            local_id=row[f"photo_{prefix}_local_id"],
            secret=row[f"photo_{prefix}_secret"],
        )

    @classmethod
    def _row_to_dialog(cls, row: sqlite3.Row) -> DialogEntry:
        peer = Peer(
            id=row["peer_id"], type=PeerType(row["peer_type"]),
            access_hash=row["access_hash"], username=row["username"], title=row["title"],
        )
        photo = None
        if row["photo_id"] is not None:
            photo = PeerPhotoReference(
                peer=peer, photo_id=row["photo_id"], dc_id=row["photo_dc_id"],
                small=cls._location(row, "small"), big=cls._location(row, "big"),
                has_video=bool(row["photo_has_video"]),
            )
        return DialogEntry(
            peer=peer, top_message_id=row["top_message_id"],
            unread_count=row["unread_count"],
            unread_mentions_count=row["unread_mentions_count"],
            read_inbox_max_id=row["read_inbox_max_id"],
            read_outbox_max_id=row["read_outbox_max_id"],
            pinned=bool(row["pinned"]), unread_mark=bool(row["unread_mark"]),
            folder_id=row["folder_id"], top_message_date=row["top_message_date"],
            kind=DialogKind(row["kind"]), broadcast=bool(row["broadcast"]),
            megagroup=bool(row["megagroup"]), participants_count=row["participants_count"],
            photo=photo, photo_cached_path=row["photo_cached_path"],
        )

    def _require_connection(self) -> sqlite3.Connection:
        if self._connection is None:
            raise MessageStoreError("Dialog database is not initialized.")
        return self._connection

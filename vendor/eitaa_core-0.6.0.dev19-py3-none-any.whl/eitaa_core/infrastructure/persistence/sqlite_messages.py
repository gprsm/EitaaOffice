"""SQLite persistence for messages, retrieval cursors, and publication state.

Schema version 9 extends the Core 3/4 message database without discarding any
existing rows.  The adapter implements three application ports:

* message storage and local keyset search;
* named remote-history cursors;
* external publication workflow state.

The database contains full message text and remote media references.  It is
private application data and must never be shared as a diagnostic file.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

from ...domain.enums import MediaType, PeerType, PublicationStatus
from ...domain.media import MediaReference, PhotoSizeReference
from ...domain.message import Message, MessageWriteStats
from ...domain.peer import Peer
from ...domain.workflow import (
    HistoryCursor,
    MessageSearchPage,
    MessageSearchQuery,
    PublicationRecord,
    decode_search_cursor,
    encode_search_cursor,
)
from ...errors import MessageStoreError
from ..diagnostics import DiagnosticManager

SCHEMA_VERSION = 9


class SQLiteMessageRepository:
    """Persist messages and workflow state in one versioned SQLite database."""

    def __init__(
        self,
        path: Path | str,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.path = Path(path)
        self.diagnostics = diagnostics
        self._connection: sqlite3.Connection | None = None

    def initialize(self) -> None:
        """Open the database and apply cumulative idempotent migrations."""
        if self._connection is not None:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(self.path)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute("PRAGMA synchronous = NORMAL")
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if version > SCHEMA_VERSION:
                raise MessageStoreError(
                    "Database schema is newer than this Core version.",
                    safe_context={
                        "database_version": version,
                        "supported_version": SCHEMA_VERSION,
                    },
                )
            if version < SCHEMA_VERSION:
                self._backup_before_migration(connection, version)
            if version < 1:
                self._migrate_v1(connection)
                version = 1
            if version < 2:
                self._migrate_v2(connection)
                version = 2
            if version < 3:
                self._migrate_v3(connection)
                version = 3
            if version < 4:
                self._migrate_v4(connection)
                version = 4
            if version < 5:
                self._migrate_v5(connection)
                version = 5
            if version < 6:
                self._migrate_v6(connection)
                version = 6
            if version < 7:
                self._migrate_v7(connection)
                version = 7
            if version < 8:
                self._migrate_v8(connection)
                version = 8
            if version < 9:
                self._migrate_v9(connection)
            self._ensure_compatible_indexes(connection)
            self._connection = connection
            self._emit(
                "database",
                "database_initialized",
                fields={"path": str(self.path), "schema_version": SCHEMA_VERSION},
            )
        except MessageStoreError:
            connection.close()
            raise
        except sqlite3.Error as exc:
            connection.close()
            debug_file = self._emit(
                "database",
                "database_initialize_failed",
                level="error",
                fields={"path": str(self.path), "sqlite_error": type(exc).__name__},
            )
            raise MessageStoreError(
                "Could not initialize the SQLite database.",
                safe_context={
                    "path": str(self.path),
                    "sqlite_error": type(exc).__name__,
                },
                debug_file=debug_file,
            ) from exc

    def _backup_before_migration(
        self, connection: sqlite3.Connection, source_version: int
    ) -> None:
        """Create one consistent, non-overwriting recovery copy before migration."""
        if source_version == 0 or not self.path.exists():
            return
        backup_path = self.path.with_name(
            f"{self.path.name}.pre-schema{SCHEMA_VERSION}-v{source_version}.bak"
        )
        if backup_path.exists():
            return
        try:
            backup = sqlite3.connect(backup_path)
            try:
                connection.backup(backup)
            finally:
                backup.close()
        except sqlite3.Error as exc:
            raise MessageStoreError(
                "Could not create the pre-migration SQLite backup.",
                safe_context={
                    "database_version": source_version,
                    "target_version": SCHEMA_VERSION,
                    "sqlite_error": type(exc).__name__,
                },
            ) from exc

    @staticmethod
    def _migrate_v1(connection: sqlite3.Connection) -> None:
        """Create the original peer/message schema used by Core 3 and 4."""
        with connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS peers (
                    peer_type TEXT NOT NULL,
                    peer_id INTEGER NOT NULL,
                    access_hash INTEGER,
                    username TEXT,
                    title TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (peer_type, peer_id)
                );

                CREATE TABLE IF NOT EXISTS messages (
                    peer_type TEXT NOT NULL,
                    peer_id INTEGER NOT NULL,
                    message_id INTEGER NOT NULL,
                    date_utc TEXT NOT NULL,
                    text TEXT NOT NULL,
                    outgoing INTEGER NOT NULL DEFAULT 0,
                    from_peer_type TEXT,
                    from_peer_id INTEGER,
                    reply_to_message_id INTEGER,
                    flags INTEGER NOT NULL DEFAULT 0,
                    parse_warning TEXT,
                    media_json TEXT,
                    content_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (peer_type, peer_id, message_id),
                    FOREIGN KEY (peer_type, peer_id)
                        REFERENCES peers(peer_type, peer_id)
                        ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_messages_peer_date
                    ON messages(peer_type, peer_id, date_utc DESC);
                CREATE INDEX IF NOT EXISTS idx_messages_peer_message_id
                    ON messages(peer_type, peer_id, message_id DESC);
                PRAGMA user_version = 1;
                """
            )

    @staticmethod
    def _migrate_v2(connection: sqlite3.Connection) -> None:
        """Add named retrieval cursors and generic publication state."""
        with connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS history_cursors (
                    peer_type TEXT NOT NULL,
                    peer_id INTEGER NOT NULL,
                    cursor_key TEXT NOT NULL,
                    next_offset_id INTEGER NOT NULL DEFAULT 0,
                    page_size INTEGER NOT NULL,
                    pages_fetched INTEGER NOT NULL DEFAULT 0,
                    messages_fetched INTEGER NOT NULL DEFAULT 0,
                    completed INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (peer_type, peer_id, cursor_key),
                    FOREIGN KEY (peer_type, peer_id)
                        REFERENCES peers(peer_type, peer_id)
                        ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS message_publications (
                    peer_type TEXT NOT NULL,
                    peer_id INTEGER NOT NULL,
                    message_id INTEGER NOT NULL,
                    target_type TEXT NOT NULL,
                    target_key TEXT NOT NULL,
                    status TEXT NOT NULL,
                    external_post_id TEXT,
                    external_url TEXT,
                    published_content_hash TEXT,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_attempt_at TEXT,
                    published_at TEXT,
                    error_code TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (
                        peer_type, peer_id, message_id, target_type, target_key
                    ),
                    FOREIGN KEY (peer_type, peer_id, message_id)
                        REFERENCES messages(peer_type, peer_id, message_id)
                        ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_publications_target_status
                    ON message_publications(target_type, target_key, status, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_publications_message
                    ON message_publications(peer_type, peer_id, message_id);
                CREATE INDEX IF NOT EXISTS idx_cursors_updated
                    ON history_cursors(updated_at DESC);
                PRAGMA user_version = 2;
                """
            )

    @staticmethod
    def _migrate_v3(connection: sqlite3.Connection) -> None:
        """Add persistent community members and change detection."""
        with connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS community_members (
                    community_type TEXT NOT NULL,
                    community_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    access_hash INTEGER,
                    first_name TEXT,
                    last_name TEXT,
                    username TEXT,
                    phone TEXT,
                    status_kind TEXT,
                    status_expires_at TEXT,
                    status_was_online_at TEXT,
                    is_contact INTEGER NOT NULL DEFAULT 0,
                    is_mutual_contact INTEGER NOT NULL DEFAULT 0,
                    is_deleted INTEGER NOT NULL DEFAULT 0,
                    is_bot INTEGER NOT NULL DEFAULT 0,
                    is_verified INTEGER NOT NULL DEFAULT 0,
                    role TEXT NOT NULL,
                    state TEXT NOT NULL,
                    joined_at TEXT,
                    inviter_id INTEGER,
                    promoted_by INTEGER,
                    rank TEXT,
                    can_edit INTEGER NOT NULL DEFAULT 0,
                    first_seen_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL,
                    left_at TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (community_type, community_id, user_id)
                );

                CREATE INDEX IF NOT EXISTS idx_community_members_state
                    ON community_members(community_type, community_id, state, role, user_id);
                CREATE INDEX IF NOT EXISTS idx_community_members_name
                    ON community_members(community_type, community_id, first_name, last_name, username);
                PRAGMA user_version = 3;
                """
            )

    @staticmethod
    def _migrate_v4(connection: sqlite3.Connection) -> None:
        """Add crash-safe bulk jobs and per-recipient delivery state."""
        with connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS bulk_jobs (
                    job_id TEXT PRIMARY KEY,
                    community_type TEXT NOT NULL,
                    community_id INTEGER NOT NULL,
                    community_access_hash INTEGER,
                    community_username TEXT,
                    community_title TEXT,
                    kind TEXT NOT NULL,
                    text TEXT NOT NULL DEFAULT '',
                    file_path TEXT,
                    caption TEXT NOT NULL DEFAULT '',
                    mime_type TEXT,
                    content_hash TEXT NOT NULL,
                    status TEXT NOT NULL,
                    delay_seconds REAL NOT NULL,
                    max_attempts INTEGER NOT NULL,
                    retry_delay_seconds REAL NOT NULL,
                    test_limit INTEGER,
                    stop_on_server_error INTEGER NOT NULL DEFAULT 1,
                    recipient_count INTEGER NOT NULL DEFAULT 0,
                    sent_count INTEGER NOT NULL DEFAULT 0,
                    failed_count INTEGER NOT NULL DEFAULT 0,
                    skipped_count INTEGER NOT NULL DEFAULT 0,
                    stop_reason TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT
                );

                CREATE TABLE IF NOT EXISTS bulk_recipients (
                    job_id TEXT NOT NULL,
                    user_id INTEGER NOT NULL,
                    access_hash INTEGER,
                    first_name TEXT,
                    last_name TEXT,
                    username TEXT,
                    role TEXT NOT NULL,
                    status TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    random_id INTEGER NOT NULL,
                    error_code TEXT,
                    error_type TEXT,
                    response_type TEXT,
                    message_id INTEGER,
                    last_attempt_at TEXT,
                    sent_at TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (job_id, user_id),
                    FOREIGN KEY (job_id) REFERENCES bulk_jobs(job_id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_bulk_jobs_status
                    ON bulk_jobs(status, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_bulk_recipients_status
                    ON bulk_recipients(job_id, status, user_id);
                PRAGMA user_version = 4;
                """
            )

    @staticmethod
    def _migrate_v5(connection: sqlite3.Connection) -> None:
        """Add persistent phone-recipient lists and per-row resolution state."""
        with connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS phone_recipient_lists (
                    list_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    virtual_peer_id INTEGER NOT NULL UNIQUE,
                    source_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    total_rows INTEGER NOT NULL DEFAULT 0,
                    valid_unique INTEGER NOT NULL DEFAULT 0,
                    duplicate_count INTEGER NOT NULL DEFAULT 0,
                    invalid_count INTEGER NOT NULL DEFAULT 0,
                    pending_count INTEGER NOT NULL DEFAULT 0,
                    resolved_count INTEGER NOT NULL DEFAULT 0,
                    not_found_count INTEGER NOT NULL DEFAULT 0,
                    failed_count INTEGER NOT NULL DEFAULT 0,
                    stop_reason TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    resolved_at TEXT
                );

                CREATE TABLE IF NOT EXISTS phone_recipient_entries (
                    entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    list_id TEXT NOT NULL,
                    row_number INTEGER NOT NULL,
                    phone TEXT,
                    phone_hash TEXT NOT NULL,
                    first_name TEXT NOT NULL DEFAULT 'Eitaa',
                    last_name TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    user_id INTEGER,
                    access_hash INTEGER,
                    resolved_first_name TEXT,
                    resolved_last_name TEXT,
                    username TEXT,
                    error_code TEXT,
                    error_type TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    resolved_at TEXT,
                    FOREIGN KEY (list_id) REFERENCES phone_recipient_lists(list_id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_phone_lists_status
                    ON phone_recipient_lists(status, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_phone_entries_status
                    ON phone_recipient_entries(list_id, status, row_number);
                CREATE INDEX IF NOT EXISTS idx_phone_entries_user
                    ON phone_recipient_entries(list_id, user_id);
                CREATE INDEX IF NOT EXISTS idx_phone_entries_hash
                    ON phone_recipient_entries(list_id, phone_hash);
                PRAGMA user_version = 5;
                """
            )

    @staticmethod
    def _migrate_v6(connection: sqlite3.Connection) -> None:
        """Track phone-list contact ownership and bulk-message deletion state."""
        with connection:
            connection.executescript(
                """
                ALTER TABLE phone_recipient_entries ADD COLUMN contact_source TEXT;
                ALTER TABLE phone_recipient_entries ADD COLUMN contact_added_by_list INTEGER NOT NULL DEFAULT 0;
                ALTER TABLE phone_recipient_entries ADD COLUMN cleanup_status TEXT NOT NULL DEFAULT 'not_required';
                ALTER TABLE phone_recipient_entries ADD COLUMN cleanup_attempts INTEGER NOT NULL DEFAULT 0;
                ALTER TABLE phone_recipient_entries ADD COLUMN cleanup_error_code TEXT;
                ALTER TABLE phone_recipient_entries ADD COLUMN cleanup_error_type TEXT;
                ALTER TABLE phone_recipient_entries ADD COLUMN cleanup_response_type TEXT;
                ALTER TABLE phone_recipient_entries ADD COLUMN cleanup_updated_at TEXT;
                ALTER TABLE phone_recipient_entries ADD COLUMN removed_at TEXT;

                ALTER TABLE bulk_recipients ADD COLUMN delete_status TEXT NOT NULL DEFAULT 'not_requested';
                ALTER TABLE bulk_recipients ADD COLUMN delete_attempts INTEGER NOT NULL DEFAULT 0;
                ALTER TABLE bulk_recipients ADD COLUMN delete_error_code TEXT;
                ALTER TABLE bulk_recipients ADD COLUMN delete_error_type TEXT;
                ALTER TABLE bulk_recipients ADD COLUMN delete_response_type TEXT;
                ALTER TABLE bulk_recipients ADD COLUMN delete_updated_at TEXT;
                ALTER TABLE bulk_recipients ADD COLUMN deleted_at TEXT;

                CREATE INDEX IF NOT EXISTS idx_phone_entries_cleanup
                    ON phone_recipient_entries(list_id, cleanup_status, entry_id);
                CREATE INDEX IF NOT EXISTS idx_bulk_recipients_delete
                    ON bulk_recipients(job_id, delete_status, user_id);
                PRAGMA user_version = 6;
                """
            )

    @staticmethod
    def _migrate_v7(connection: sqlite3.Connection) -> None:
        """Add reversible bulk membership jobs and per-user rollback state."""
        with connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS membership_jobs (
                    job_id TEXT PRIMARY KEY,
                    list_id TEXT NOT NULL,
                    target_type TEXT NOT NULL,
                    target_id INTEGER NOT NULL,
                    target_access_hash INTEGER,
                    target_username TEXT,
                    target_title TEXT,
                    status TEXT NOT NULL,
                    delay_seconds REAL NOT NULL,
                    max_attempts INTEGER NOT NULL,
                    retry_delay_seconds REAL NOT NULL,
                    test_limit INTEGER,
                    stop_on_server_error INTEGER NOT NULL DEFAULT 1,
                    fwd_limit INTEGER NOT NULL DEFAULT 0,
                    recipient_count INTEGER NOT NULL DEFAULT 0,
                    added_count INTEGER NOT NULL DEFAULT 0,
                    already_member_count INTEGER NOT NULL DEFAULT 0,
                    failed_count INTEGER NOT NULL DEFAULT 0,
                    skipped_count INTEGER NOT NULL DEFAULT 0,
                    stop_reason TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    rollback_started_at TEXT,
                    rollback_finished_at TEXT,
                    rollback_stop_reason TEXT,
                    FOREIGN KEY (list_id) REFERENCES phone_recipient_lists(list_id)
                        ON DELETE RESTRICT
                );

                CREATE TABLE IF NOT EXISTS membership_recipients (
                    job_id TEXT NOT NULL,
                    entry_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    access_hash INTEGER,
                    first_name TEXT,
                    last_name TEXT,
                    username TEXT,
                    add_status TEXT NOT NULL,
                    add_attempts INTEGER NOT NULL DEFAULT 0,
                    previously_member INTEGER,
                    added_by_job INTEGER NOT NULL DEFAULT 0,
                    add_error_code TEXT,
                    add_error_type TEXT,
                    add_response_type TEXT,
                    last_attempt_at TEXT,
                    added_at TEXT,
                    rollback_status TEXT NOT NULL DEFAULT 'not_required',
                    rollback_attempts INTEGER NOT NULL DEFAULT 0,
                    rollback_error_code TEXT,
                    rollback_error_type TEXT,
                    rollback_response_type TEXT,
                    rollback_updated_at TEXT,
                    removed_at TEXT,
                    PRIMARY KEY (job_id, user_id),
                    FOREIGN KEY (job_id) REFERENCES membership_jobs(job_id)
                        ON DELETE CASCADE,
                    FOREIGN KEY (entry_id) REFERENCES phone_recipient_entries(entry_id)
                        ON DELETE RESTRICT
                );

                CREATE INDEX IF NOT EXISTS idx_membership_jobs_status
                    ON membership_jobs(status, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_membership_recipients_add
                    ON membership_recipients(job_id, add_status, user_id);
                CREATE INDEX IF NOT EXISTS idx_membership_recipients_rollback
                    ON membership_recipients(job_id, rollback_status, user_id);
                PRAGMA user_version = 7;
                """
            )

    @staticmethod
    def _migrate_v8(connection: sqlite3.Connection) -> None:
        """Add complete dialog snapshots, type flags, and photo references."""
        with connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS dialog_sync_runs (
                    sync_id TEXT PRIMARY KEY,
                    started_at TEXT NOT NULL,
                    finished_at TEXT NOT NULL,
                    server_total_count INTEGER,
                    received_count INTEGER NOT NULL,
                    pages_fetched INTEGER NOT NULL,
                    complete INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS dialogs (
                    peer_type TEXT NOT NULL,
                    peer_id INTEGER NOT NULL,
                    access_hash INTEGER,
                    username TEXT,
                    title TEXT,
                    kind TEXT NOT NULL,
                    top_message_id INTEGER NOT NULL DEFAULT 0,
                    top_message_date INTEGER,
                    unread_count INTEGER NOT NULL DEFAULT 0,
                    unread_mentions_count INTEGER NOT NULL DEFAULT 0,
                    read_inbox_max_id INTEGER NOT NULL DEFAULT 0,
                    read_outbox_max_id INTEGER NOT NULL DEFAULT 0,
                    pinned INTEGER NOT NULL DEFAULT 0,
                    unread_mark INTEGER NOT NULL DEFAULT 0,
                    folder_id INTEGER,
                    broadcast INTEGER NOT NULL DEFAULT 0,
                    megagroup INTEGER NOT NULL DEFAULT 0,
                    participants_count INTEGER,
                    photo_id INTEGER,
                    photo_dc_id INTEGER,
                    photo_has_video INTEGER NOT NULL DEFAULT 0,
                    photo_small_constructor INTEGER,
                    photo_small_dc_id INTEGER,
                    photo_small_volume_id INTEGER,
                    photo_small_local_id INTEGER,
                    photo_small_secret INTEGER,
                    photo_big_constructor INTEGER,
                    photo_big_dc_id INTEGER,
                    photo_big_volume_id INTEGER,
                    photo_big_local_id INTEGER,
                    photo_big_secret INTEGER,
                    photo_cached_path TEXT,
                    last_sync_id TEXT NOT NULL,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (peer_type, peer_id),
                    FOREIGN KEY (last_sync_id) REFERENCES dialog_sync_runs(sync_id)
                );

                CREATE INDEX IF NOT EXISTS idx_dialogs_kind_active
                    ON dialogs(kind, is_active, top_message_date DESC);
                CREATE INDEX IF NOT EXISTS idx_dialogs_sync
                    ON dialogs(last_sync_id);
                PRAGMA user_version = 8;
                """
            )

    @staticmethod
    def _migrate_v9(connection: sqlite3.Connection) -> None:
        """Persist the server-declared media-album identifier."""
        with connection:
            connection.executescript(
                """
                BEGIN IMMEDIATE;
                ALTER TABLE messages ADD COLUMN grouped_id INTEGER;
                CREATE INDEX IF NOT EXISTS idx_messages_peer_grouped
                    ON messages(peer_type, peer_id, grouped_id, message_id)
                    WHERE grouped_id IS NOT NULL;
                PRAGMA user_version = 9;
                COMMIT;
                """
            )

    def upsert_many(self, messages: Sequence[Message]) -> MessageWriteStats:
        """Insert, update, or count unchanged messages in one transaction.

        When already-published content changes, related publication rows move
        from ``published`` to ``needs_update`` automatically.  If content later
        returns exactly to the published hash, the state returns to
        ``published``.
        """
        if not messages:
            return MessageWriteStats()
        connection = self._require_connection()
        inserted = updated = unchanged = 0
        now = _utc_now()
        try:
            with connection:
                for message in messages:
                    self._upsert_peer(connection, message.peer, now)
                    if message.from_peer:
                        self._upsert_peer(connection, message.from_peer, now)
                    media_json = _media_to_json(message.media)
                    digest = _message_hash(message, media_json)
                    key = (message.peer.type.value, message.peer.id, message.id)
                    existing = connection.execute(
                        """SELECT content_hash, grouped_id FROM messages
                           WHERE peer_type=? AND peer_id=? AND message_id=?""",
                        key,
                    ).fetchone()
                    common = (
                        message.date.astimezone(timezone.utc).isoformat(),
                        message.text,
                        int(message.outgoing),
                        message.from_peer.type.value if message.from_peer else None,
                        message.from_peer.id if message.from_peer else None,
                        message.reply_to_message_id,
                        message.grouped_id,
                        message.flags,
                        message.parse_warning,
                        media_json,
                        digest,
                    )
                    if existing is None:
                        connection.execute(
                            """INSERT INTO messages (
                                peer_type,peer_id,message_id,date_utc,text,outgoing,
                                from_peer_type,from_peer_id,reply_to_message_id,
                                grouped_id,flags,parse_warning,media_json,content_hash,
                                created_at,updated_at
                            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            key + common + (now, now),
                        )
                        inserted += 1
                    elif (
                        existing["content_hash"] == digest
                        and existing["grouped_id"] == message.grouped_id
                    ):
                        unchanged += 1
                    elif existing["content_hash"] == digest:
                        connection.execute(
                            """UPDATE messages SET grouped_id=?, updated_at=?
                               WHERE peer_type=? AND peer_id=? AND message_id=?""",
                            (message.grouped_id, now) + key,
                        )
                        updated += 1
                    else:
                        connection.execute(
                            """UPDATE messages SET
                                date_utc=?, text=?, outgoing=?, from_peer_type=?,
                                from_peer_id=?, reply_to_message_id=?, grouped_id=?, flags=?,
                                parse_warning=?, media_json=?, content_hash=?,
                                updated_at=?
                               WHERE peer_type=? AND peer_id=? AND message_id=?""",
                            common + (now,) + key,
                        )
                        updated += 1
                    self._refresh_publication_staleness(
                        connection,
                        peer_type=key[0],
                        peer_id=key[1],
                        message_id=key[2],
                        current_hash=digest,
                        now=now,
                    )
        except sqlite3.Error as exc:
            debug_file = self._emit(
                "database",
                "message_upsert_failed",
                level="error",
                fields={
                    "message_count": len(messages),
                    "sqlite_error": type(exc).__name__,
                },
            )
            raise MessageStoreError(
                "Could not write messages to SQLite.",
                safe_context={
                    "message_count": len(messages),
                    "sqlite_error": type(exc).__name__,
                },
                debug_file=debug_file,
            ) from exc
        stats = MessageWriteStats(inserted, updated, unchanged)
        self._emit("database", "messages_upserted", fields=stats.safe_summary())
        return stats

    @staticmethod
    def _refresh_publication_staleness(
        connection: sqlite3.Connection,
        *,
        peer_type: str,
        peer_id: int,
        message_id: int,
        current_hash: str,
        now: str,
    ) -> None:
        connection.execute(
            """UPDATE message_publications
               SET status=?, updated_at=?
               WHERE peer_type=? AND peer_id=? AND message_id=?
                 AND status=?
                 AND published_content_hash IS NOT NULL
                 AND published_content_hash <> ?""",
            (
                PublicationStatus.NEEDS_UPDATE.value,
                now,
                peer_type,
                peer_id,
                message_id,
                PublicationStatus.PUBLISHED.value,
                current_hash,
            ),
        )
        connection.execute(
            """UPDATE message_publications
               SET status=?, updated_at=?
               WHERE peer_type=? AND peer_id=? AND message_id=?
                 AND status=?
                 AND published_content_hash = ?""",
            (
                PublicationStatus.PUBLISHED.value,
                now,
                peer_type,
                peer_id,
                message_id,
                PublicationStatus.NEEDS_UPDATE.value,
                current_hash,
            ),
        )

    @staticmethod
    def _upsert_peer(connection: sqlite3.Connection, peer: Peer, now: str) -> None:
        connection.execute(
            """INSERT INTO peers(peer_type,peer_id,access_hash,username,title,updated_at)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(peer_type,peer_id) DO UPDATE SET
                 access_hash=COALESCE(excluded.access_hash,peers.access_hash),
                 username=COALESCE(excluded.username,peers.username),
                 title=COALESCE(excluded.title,peers.title),
                 updated_at=excluded.updated_at""",
            (peer.type.value, peer.id, peer.access_hash, peer.username, peer.title, now),
        )

    def get(self, peer: Peer, message_id: int) -> Message | None:
        row = self._require_connection().execute(
            """SELECT m.*, p.access_hash, p.username, p.title
               FROM messages m JOIN peers p USING(peer_type,peer_id)
               WHERE m.peer_type=? AND m.peer_id=? AND m.message_id=?""",
            (peer.type.value, peer.id, message_id),
        ).fetchone()
        return _row_to_message(row) if row else None

    @staticmethod
    def _ensure_compatible_indexes(connection: sqlite3.Connection) -> None:
        """Create additive indexes that do not require a schema-version bump."""
        with connection:
            connection.execute(
                """CREATE INDEX IF NOT EXISTS idx_messages_peer_sender_date
                   ON messages(
                       peer_type, peer_id, from_peer_type, from_peer_id,
                       date_utc DESC, message_id DESC
                   )"""
            )
            connection.execute(
                """CREATE INDEX IF NOT EXISTS idx_messages_peer_grouped
                   ON messages(peer_type, peer_id, grouped_id, message_id)
                   WHERE grouped_id IS NOT NULL"""
            )

    def list_by_peer(
        self,
        peer: Peer,
        *,
        limit: int = 100,
        before_id: int | None = None,
    ) -> tuple[Message, ...]:
        query = MessageSearchQuery(peer=peer, before_id=before_id, limit=limit)
        return self.search(query).messages

    def list_by_grouped_id(self, peer: Peer, grouped_id: int) -> tuple[Message, ...]:
        rows = self._require_connection().execute(
            """SELECT m.*, p.access_hash, p.username, p.title
               FROM messages m JOIN peers p USING(peer_type,peer_id)
               WHERE m.peer_type=? AND m.peer_id=? AND m.grouped_id=?
               ORDER BY m.message_id ASC""",
            (peer.type.value, peer.id, grouped_id),
        ).fetchall()
        return tuple(_row_to_message(row) for row in rows)

    def search(self, query: MessageSearchQuery) -> MessageSearchPage:
        """Search local messages with sender, date, text, media, publication, and cursor filters."""
        try:
            query.validate()
        except ValueError as exc:
            raise MessageStoreError(
                str(exc), safe_context={"operation": "message_search"}
            ) from exc

        sql = """SELECT m.*, p.access_hash, p.username, p.title
                 FROM messages m JOIN peers p USING(peer_type,peer_id)
                 WHERE 1=1"""
        params: list[object] = []
        if query.peer:
            sql += " AND m.peer_type=? AND m.peer_id=?"
            params.extend((query.peer.type.value, query.peer.id))
        if query.sender:
            sql += " AND m.from_peer_type=? AND m.from_peer_id=?"
            params.extend((query.sender.type.value, query.sender.id))
        if query.date_from:
            sql += " AND m.date_utc >= ?"
            params.append(query.date_from.astimezone(timezone.utc).isoformat())
        if query.date_to:
            sql += " AND m.date_utc <= ?"
            params.append(query.date_to.astimezone(timezone.utc).isoformat())
        if query.before_id is not None:
            sql += " AND m.message_id < ?"
            params.append(query.before_id)
        if query.after_id is not None:
            sql += " AND m.message_id > ?"
            params.append(query.after_id)
        if query.media_types:
            placeholders = ",".join("?" for _ in query.media_types)
            sql += f" AND json_extract(m.media_json, '$.type') IN ({placeholders})"
            params.extend(item.value for item in query.media_types)
        if query.text:
            sql += " AND m.text LIKE ? ESCAPE '\\'"
            params.append("%" + _escape_like(query.text) + "%")

        publication_filters = any(
            value is not None
            for value in (
                query.publication_status,
                True if query.unpublished else None,
                query.target_type,
                query.target_key,
            )
        )
        if publication_filters:
            sql += """ AND """ + ("NOT EXISTS (" if query.unpublished else "EXISTS (") + """
                SELECT 1 FROM message_publications mp
                WHERE mp.peer_type=m.peer_type
                  AND mp.peer_id=m.peer_id
                  AND mp.message_id=m.message_id"""
            if query.publication_status:
                sql += " AND mp.status=?"
                params.append(query.publication_status.value)
            if query.target_type:
                sql += " AND mp.target_type=?"
                params.append(query.target_type)
            if query.target_key:
                sql += " AND mp.target_key=?"
                params.append(query.target_key)
            sql += ")"

        if query.cursor:
            date_utc, peer_type, peer_id, message_id = decode_search_cursor(query.cursor)
            sql += """ AND (
                m.date_utc < ? OR
                (m.date_utc = ? AND m.peer_type > ?) OR
                (m.date_utc = ? AND m.peer_type = ? AND m.peer_id > ?) OR
                (m.date_utc = ? AND m.peer_type = ? AND m.peer_id = ?
                    AND m.message_id < ?)
            )"""
            params.extend(
                (
                    date_utc,
                    date_utc,
                    peer_type,
                    date_utc,
                    peer_type,
                    peer_id,
                    date_utc,
                    peer_type,
                    peer_id,
                    message_id,
                )
            )

        sql += " ORDER BY m.date_utc DESC, m.peer_type ASC, m.peer_id ASC, m.message_id DESC"
        sql += " LIMIT ?"
        params.append(query.limit + 1)
        try:
            rows = self._require_connection().execute(sql, params).fetchall()
        except sqlite3.Error as exc:
            debug_file = self._emit(
                "search",
                "message_search_failed",
                level="error",
                fields={"sqlite_error": type(exc).__name__},
            )
            raise MessageStoreError(
                "Could not search local messages.",
                safe_context={"sqlite_error": type(exc).__name__},
                debug_file=debug_file,
            ) from exc

        has_more = len(rows) > query.limit
        selected = rows[: query.limit]
        next_cursor = None
        if has_more and selected:
            last = selected[-1]
            next_cursor = encode_search_cursor(
                date_utc=str(last["date_utc"]),
                peer_type=str(last["peer_type"]),
                peer_id=int(last["peer_id"]),
                message_id=int(last["message_id"]),
            )
        page = MessageSearchPage(
            messages=tuple(_row_to_message(row) for row in selected),
            next_cursor=next_cursor,
        )
        self._emit(
            "search",
            "message_search_completed",
            fields={
                **page.safe_summary(),
                "peer_filter_present": query.peer is not None,
                "sender_filter_present": query.sender is not None,
                "date_filter_present": query.date_from is not None or query.date_to is not None,
                "publication_filter_present": publication_filters,
                "text_filter_present": query.text is not None,
            },
        )
        return page

    def content_hash(self, peer: Peer, message_id: int) -> str | None:
        row = self._require_connection().execute(
            """SELECT content_hash FROM messages
               WHERE peer_type=? AND peer_id=? AND message_id=?""",
            (peer.type.value, peer.id, message_id),
        ).fetchone()
        return str(row[0]) if row else None

    def count(self, peer: Peer | None = None) -> int:
        connection = self._require_connection()
        if peer is None:
            return int(connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0])
        return int(
            connection.execute(
                "SELECT COUNT(*) FROM messages WHERE peer_type=? AND peer_id=?",
                (peer.type.value, peer.id),
            ).fetchone()[0]
        )

    def oldest_message_id(self, peer: Peer) -> int | None:
        return self._scalar_id("MIN", peer)

    def newest_message_id(self, peer: Peer) -> int | None:
        return self._scalar_id("MAX", peer)

    def _scalar_id(self, aggregate: str, peer: Peer) -> int | None:
        value = self._require_connection().execute(
            f"SELECT {aggregate}(message_id) FROM messages WHERE peer_type=? AND peer_id=?",
            (peer.type.value, peer.id),
        ).fetchone()[0]
        return int(value) if value is not None else None

    # ------------------------------------------------------------------
    # CursorRepository
    # ------------------------------------------------------------------
    def get_cursor(self, peer: Peer, key: str) -> HistoryCursor | None:
        row = self._require_connection().execute(
            """SELECT c.*, p.access_hash, p.username, p.title
               FROM history_cursors c JOIN peers p USING(peer_type,peer_id)
               WHERE c.peer_type=? AND c.peer_id=? AND c.cursor_key=?""",
            (peer.type.value, peer.id, key),
        ).fetchone()
        return _row_to_cursor(row) if row else None

    def save_cursor(self, cursor: HistoryCursor) -> None:
        try:
            cursor.validate()
        except ValueError as exc:
            raise MessageStoreError(str(exc), safe_context={"operation": "save_cursor"}) from exc
        connection = self._require_connection()
        now = cursor.updated_at.astimezone(timezone.utc).isoformat()
        try:
            with connection:
                self._upsert_peer(connection, cursor.peer, now)
                connection.execute(
                    """INSERT INTO history_cursors(
                        peer_type,peer_id,cursor_key,next_offset_id,page_size,
                        pages_fetched,messages_fetched,completed,updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(peer_type,peer_id,cursor_key) DO UPDATE SET
                        next_offset_id=excluded.next_offset_id,
                        page_size=excluded.page_size,
                        pages_fetched=excluded.pages_fetched,
                        messages_fetched=excluded.messages_fetched,
                        completed=excluded.completed,
                        updated_at=excluded.updated_at""",
                    (
                        cursor.peer.type.value,
                        cursor.peer.id,
                        cursor.key,
                        cursor.next_offset_id,
                        cursor.page_size,
                        cursor.pages_fetched,
                        cursor.messages_fetched,
                        int(cursor.completed),
                        now,
                    ),
                )
        except sqlite3.Error as exc:
            debug_file = self._emit(
                "cursor",
                "cursor_save_failed",
                level="error",
                fields={"sqlite_error": type(exc).__name__},
            )
            raise MessageStoreError(
                "Could not save the history cursor.",
                safe_context={"sqlite_error": type(exc).__name__},
                debug_file=debug_file,
            ) from exc
        self._emit("cursor", "cursor_saved", fields=cursor.safe_summary())

    def delete_cursor(self, peer: Peer, key: str) -> bool:
        with self._require_connection():
            result = self._require_connection().execute(
                """DELETE FROM history_cursors
                   WHERE peer_type=? AND peer_id=? AND cursor_key=?""",
                (peer.type.value, peer.id, key),
            )
        deleted = result.rowcount > 0
        self._emit(
            "cursor",
            "cursor_deleted",
            fields={"peer": peer.safe_summary(), "key": key, "deleted": deleted},
        )
        return deleted

    # ------------------------------------------------------------------
    # PublicationRepository
    # ------------------------------------------------------------------
    def get_publication(
        self,
        peer: Peer,
        message_id: int,
        target_type: str,
        target_key: str,
    ) -> PublicationRecord | None:
        row = self._require_connection().execute(
            """SELECT mp.*, m.content_hash AS current_content_hash,
                      p.access_hash, p.username, p.title
               FROM message_publications mp
               JOIN messages m USING(peer_type,peer_id,message_id)
               JOIN peers p USING(peer_type,peer_id)
               WHERE mp.peer_type=? AND mp.peer_id=? AND mp.message_id=?
                 AND mp.target_type=? AND mp.target_key=?""",
            (peer.type.value, peer.id, message_id, target_type, target_key),
        ).fetchone()
        return _row_to_publication(row) if row else None

    def save_publication(self, record: PublicationRecord) -> PublicationRecord:
        try:
            record.validate()
        except ValueError as exc:
            raise MessageStoreError(
                str(exc), safe_context={"operation": "save_publication"}
            ) from exc
        connection = self._require_connection()
        current_hash = self.content_hash(record.peer, record.message_id)
        if current_hash is None:
            raise MessageStoreError(
                "Cannot create publication state for a message not stored locally.",
                safe_context={
                    "peer": record.peer.safe_summary(),
                    "message_id": record.message_id,
                },
            )
        now = (record.updated_at or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat()
        created_at = (record.created_at or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat()
        try:
            with connection:
                connection.execute(
                    """INSERT INTO message_publications(
                        peer_type,peer_id,message_id,target_type,target_key,status,
                        external_post_id,external_url,published_content_hash,
                        attempts,last_attempt_at,published_at,error_code,
                        created_at,updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(peer_type,peer_id,message_id,target_type,target_key)
                    DO UPDATE SET
                        status=excluded.status,
                        external_post_id=excluded.external_post_id,
                        external_url=excluded.external_url,
                        published_content_hash=excluded.published_content_hash,
                        attempts=excluded.attempts,
                        last_attempt_at=excluded.last_attempt_at,
                        published_at=excluded.published_at,
                        error_code=excluded.error_code,
                        updated_at=excluded.updated_at""",
                    (
                        record.peer.type.value,
                        record.peer.id,
                        record.message_id,
                        record.target_type,
                        record.target_key,
                        record.status.value,
                        record.external_post_id,
                        record.external_url,
                        record.published_content_hash,
                        record.attempts,
                        _dt_to_text(record.last_attempt_at),
                        _dt_to_text(record.published_at),
                        record.error_code,
                        created_at,
                        now,
                    ),
                )
        except sqlite3.Error as exc:
            debug_file = self._emit(
                "publications",
                "publication_save_failed",
                level="error",
                fields={"sqlite_error": type(exc).__name__},
            )
            raise MessageStoreError(
                "Could not save publication state.",
                safe_context={"sqlite_error": type(exc).__name__},
                debug_file=debug_file,
            ) from exc
        saved = self.get_publication(
            record.peer,
            record.message_id,
            record.target_type,
            record.target_key,
        )
        assert saved is not None
        self._emit("publications", "publication_saved", fields=saved.safe_summary())
        return saved

    def list_publications(
        self,
        *,
        peer: Peer | None = None,
        target_type: str | None = None,
        target_key: str | None = None,
        status: PublicationStatus | None = None,
        limit: int = 100,
    ) -> tuple[PublicationRecord, ...]:
        if not 1 <= limit <= 10_000:
            raise MessageStoreError("Publication list limit must be between 1 and 10000.")
        sql = """SELECT mp.*, m.content_hash AS current_content_hash,
                        p.access_hash, p.username, p.title
                 FROM message_publications mp
                 JOIN messages m USING(peer_type,peer_id,message_id)
                 JOIN peers p USING(peer_type,peer_id)
                 WHERE 1=1"""
        params: list[object] = []
        if peer:
            sql += " AND mp.peer_type=? AND mp.peer_id=?"
            params.extend((peer.type.value, peer.id))
        if target_type:
            sql += " AND mp.target_type=?"
            params.append(target_type)
        if target_key:
            sql += " AND mp.target_key=?"
            params.append(target_key)
        if status:
            sql += " AND mp.status=?"
            params.append(status.value)
        sql += " ORDER BY mp.updated_at DESC, mp.message_id DESC LIMIT ?"
        params.append(limit)
        rows = self._require_connection().execute(sql, params).fetchall()
        records = tuple(_row_to_publication(row) for row in rows)
        self._emit(
            "publications",
            "publications_listed",
            fields={"count": len(records), "status_filter": status.value if status else None},
        )
        return records

    # ------------------------------------------------------------------
    # Lifetime helpers
    # ------------------------------------------------------------------
    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None
            self._emit("database", "database_closed", fields={"path": str(self.path)})

    def _require_connection(self) -> sqlite3.Connection:
        if self._connection is None:
            self.initialize()
        assert self._connection is not None
        return self._connection

    def _emit(
        self,
        component: str,
        event: str,
        *,
        level: str = "info",
        fields: dict[str, object] | None = None,
    ) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit(component, event, level=level, fields=fields)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _dt_to_text(value: datetime | None) -> str | None:
    return value.astimezone(timezone.utc).isoformat() if value else None


def _text_to_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    result = datetime.fromisoformat(value)
    return result if result.tzinfo else result.replace(tzinfo=timezone.utc)


def _escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _media_to_json(media: MediaReference | None) -> str | None:
    if media is None:
        return None
    data = {
        "type": media.type.value,
        "remote_id": media.remote_id,
        "access_hash": media.access_hash,
        "file_reference_hex": media.file_reference.hex() if media.file_reference else None,
        "mime_type": media.mime_type,
        "file_name": media.file_name,
        "size": media.size,
        "dc_id": media.dc_id,
        "date": media.date,
        "thumb_types": list(media.thumb_types),
        "photo_sizes": [
            {
                "type": item.type,
                "width": item.width,
                "height": item.height,
                "size": item.size,
                "cached_bytes_hex": item.cached_bytes.hex() if item.cached_bytes else None,
                "location_constructor": item.location_constructor,
                "location_dc_id": item.location_dc_id,
                "volume_id": item.volume_id,
                "local_id": item.local_id,
                "secret": item.secret,
            }
            for item in media.photo_sizes
        ],
        "attributes": list(media.attributes),
        "constructor": media.constructor,
    }
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _json_to_media(value: str | None) -> MediaReference | None:
    if not value:
        return None
    data = json.loads(value)
    return MediaReference(
        type=MediaType(data["type"]),
        remote_id=data.get("remote_id"),
        access_hash=data.get("access_hash"),
        file_reference=(
            bytes.fromhex(data["file_reference_hex"])
            if data.get("file_reference_hex")
            else None
        ),
        mime_type=data.get("mime_type"),
        file_name=data.get("file_name"),
        size=data.get("size"),
        dc_id=data.get("dc_id"),
        date=data.get("date"),
        thumb_types=tuple(data.get("thumb_types") or ()),
        photo_sizes=tuple(
            PhotoSizeReference(
                type=item.get("type"),
                width=item.get("width"),
                height=item.get("height"),
                size=item.get("size"),
                cached_bytes=(
                    bytes.fromhex(item["cached_bytes_hex"])
                    if item.get("cached_bytes_hex")
                    else None
                ),
                location_constructor=item.get("location_constructor"),
                location_dc_id=item.get("location_dc_id"),
                volume_id=item.get("volume_id"),
                local_id=item.get("local_id"),
                secret=item.get("secret"),
            )
            for item in data.get("photo_sizes") or ()
        ),
        attributes=tuple(data.get("attributes") or ()),
        constructor=data.get("constructor"),
    )


def _message_hash(message: Message, media_json: str | None) -> str:
    data = {
        "date": message.date.astimezone(timezone.utc).isoformat(),
        "text": message.text,
        "outgoing": message.outgoing,
        "from_peer": (
            [message.from_peer.type.value, message.from_peer.id]
            if message.from_peer
            else None
        ),
        "reply_to_message_id": message.reply_to_message_id,
        "flags": message.flags,
        "parse_warning": message.parse_warning,
        "media_json": media_json,
    }
    raw = json.dumps(
        data, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _row_to_message(row: sqlite3.Row) -> Message:
    peer = Peer(
        id=int(row["peer_id"]),
        type=PeerType(row["peer_type"]),
        access_hash=row["access_hash"],
        username=row["username"],
        title=row["title"],
    )
    from_peer = None
    if row["from_peer_type"] is not None and row["from_peer_id"] is not None:
        from_peer = Peer(
            id=int(row["from_peer_id"]), type=PeerType(row["from_peer_type"])
        )
    date = datetime.fromisoformat(row["date_utc"])
    if date.tzinfo is None:
        date = date.replace(tzinfo=timezone.utc)
    return Message(
        id=int(row["message_id"]),
        peer=peer,
        date=date,
        text=row["text"],
        media=_json_to_media(row["media_json"]),
        outgoing=bool(row["outgoing"]),
        from_peer=from_peer,
        reply_to_message_id=row["reply_to_message_id"],
        grouped_id=row["grouped_id"],
        flags=int(row["flags"]),
        parse_warning=row["parse_warning"],
    )


def _row_to_cursor(row: sqlite3.Row) -> HistoryCursor:
    updated_at = _text_to_dt(row["updated_at"])
    assert updated_at is not None
    return HistoryCursor(
        peer=Peer(
            id=int(row["peer_id"]),
            type=PeerType(row["peer_type"]),
            access_hash=row["access_hash"],
            username=row["username"],
            title=row["title"],
        ),
        key=str(row["cursor_key"]),
        next_offset_id=int(row["next_offset_id"]),
        page_size=int(row["page_size"]),
        pages_fetched=int(row["pages_fetched"]),
        messages_fetched=int(row["messages_fetched"]),
        completed=bool(row["completed"]),
        updated_at=updated_at,
    )


def _row_to_publication(row: sqlite3.Row) -> PublicationRecord:
    return PublicationRecord(
        peer=Peer(
            id=int(row["peer_id"]),
            type=PeerType(row["peer_type"]),
            access_hash=row["access_hash"],
            username=row["username"],
            title=row["title"],
        ),
        message_id=int(row["message_id"]),
        target_type=str(row["target_type"]),
        target_key=str(row["target_key"]),
        status=PublicationStatus(row["status"]),
        external_post_id=row["external_post_id"],
        external_url=row["external_url"],
        published_content_hash=row["published_content_hash"],
        attempts=int(row["attempts"]),
        last_attempt_at=_text_to_dt(row["last_attempt_at"]),
        published_at=_text_to_dt(row["published_at"]),
        error_code=row["error_code"],
        created_at=_text_to_dt(row["created_at"]),
        updated_at=_text_to_dt(row["updated_at"]),
        current_content_hash=row["current_content_hash"],
    )

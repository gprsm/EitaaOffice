"""Local persistence adapters."""

from .sqlite_messages import SCHEMA_VERSION, SQLiteMessageRepository
from .sqlite_community import SQLiteCommunityRepository
from .sqlite_membership import SQLiteMembershipRepository
from .sqlite_dialogs import SQLiteDialogRepository

__all__ = [
    "SCHEMA_VERSION",
    "SQLiteMessageRepository",
    "SQLiteCommunityRepository",
    "SQLiteMembershipRepository",
    "SQLiteDialogRepository",
]

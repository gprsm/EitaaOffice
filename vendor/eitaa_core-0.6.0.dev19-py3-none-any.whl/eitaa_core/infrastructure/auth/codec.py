"""Pure TL serializers, parsers, and SRP helpers for native login."""

from __future__ import annotations

import hashlib
import secrets
from dataclasses import dataclass

from ...domain.auth import CodeDeliveryType, LoginCodeChallenge
from ...domain.phone import PhoneNumber
from ...errors import AuthenticationError, PasswordAlgorithmError, TLDecodeError, UnexpectedConstructorError
from ..codec.tl import TLReader, TLWriter, hex_constructor
from . import constructors as c

# Telegram/Eitaa 2048-bit safe prime used by the observed SRP flow.
GOOD_PRIME = bytes((
    0xC7,0x1C,0xAE,0xB9,0xC6,0xB1,0xC9,0x04,0x8E,0x6C,0x52,0x2F,0x70,0xF1,0x3F,0x73,
    0x98,0x0D,0x40,0x23,0x8E,0x3E,0x21,0xC1,0x49,0x34,0xD0,0x37,0x56,0x3D,0x93,0x0F,
    0x48,0x19,0x8A,0x0A,0xA7,0xC1,0x40,0x58,0x22,0x94,0x93,0xD2,0x25,0x30,0xF4,0xDB,
    0xFA,0x33,0x6F,0x6E,0x0A,0xC9,0x25,0x13,0x95,0x43,0xAE,0xD4,0x4C,0xCE,0x7C,0x37,
    0x20,0xFD,0x51,0xF6,0x94,0x58,0x70,0x5A,0xC6,0x8C,0xD4,0xFE,0x6B,0x6B,0x13,0xAB,
    0xDC,0x97,0x46,0x51,0x29,0x69,0x32,0x84,0x54,0xF1,0x8F,0xAF,0x8C,0x59,0x5F,0x64,
    0x24,0x77,0xFE,0x96,0xBB,0x2A,0x94,0x1D,0x5B,0xCD,0x1D,0x4A,0xC8,0xCC,0x49,0x88,
    0x07,0x08,0xFA,0x9B,0x37,0x8E,0x3C,0x4F,0x3A,0x90,0x60,0xBE,0xE6,0x7C,0xF9,0xA4,
    0xA4,0xA6,0x95,0x81,0x10,0x51,0x90,0x7E,0x16,0x27,0x53,0xB5,0x6B,0x0F,0x6B,0x41,
    0x0D,0xBA,0x74,0xD8,0xA8,0x4B,0x2A,0x14,0xB3,0x14,0x4E,0x0E,0xF1,0x28,0x47,0x54,
    0xFD,0x17,0xED,0x95,0x0D,0x59,0x65,0xB4,0xB9,0xDD,0x46,0x58,0x2D,0xB1,0x17,0x8D,
    0x16,0x9C,0x6B,0xC4,0x65,0xB0,0xD6,0xFF,0x9C,0xA3,0x92,0x8F,0xEF,0x5B,0x9A,0xE4,
    0xE4,0x18,0xFC,0x15,0xE8,0x3E,0xBE,0xA0,0xF8,0x7F,0xA9,0xFF,0x5E,0xED,0x70,0x05,
    0x0D,0xED,0x28,0x49,0xF4,0x7B,0xF9,0x59,0xD9,0x56,0x85,0x0C,0xE9,0x29,0x85,0x1F,
    0x0D,0x81,0x15,0xF6,0x35,0xB1,0x05,0xEE,0x2E,0x4E,0x15,0xD0,0x4B,0x24,0x54,0xBF,
    0x6F,0x4F,0xAD,0xF0,0x34,0xB1,0x04,0x03,0x11,0x9C,0xD8,0xE3,0xB9,0x2F,0xCC,0x5B,
))


@dataclass(slots=True, frozen=True)
class SrpPasswordInfo:
    salt1: bytes
    salt2: bytes
    g: int
    p: bytes
    srp_b: bytes
    srp_id: int
    hint: str | None


@dataclass(slots=True, frozen=True)
class LegacyPasswordInfo:
    current_salt: bytes
    hint: str | None


class AuthCodec:
    """Pure request and response codec for the supported auth flow."""

    @staticmethod
    def build_send_code(phone: PhoneNumber, *, api_id: int, api_hash: str) -> bytes:
        settings = TLWriter().write_i32(c.CODE_SETTINGS).write_i32(0).to_bytes()
        return (
            TLWriter()
            .write_i32(c.AUTH_SEND_CODE)
            .write_string(phone.canonical_digits)
            .write_i32(api_id)
            .write_string(api_hash)
            .write_raw(settings)
            .to_bytes()
        )

    @staticmethod
    def build_sign_in(challenge: LoginCodeChallenge, code: str) -> bytes:
        return (
            TLWriter()
            .write_i32(c.AUTH_SIGN_IN)
            .write_string(challenge.phone.canonical_digits)
            .write_string(challenge.phone_code_hash)
            .write_string(code)
            .to_bytes()
        )

    @staticmethod
    def build_get_password() -> bytes:
        return TLWriter().write_i32(c.ACCOUNT_GET_PASSWORD).to_bytes()

    @staticmethod
    def build_check_password_srp(srp_id: int, a_value: bytes, m1: bytes) -> bytes:
        return (
            TLWriter()
            .write_i32(c.AUTH_CHECK_PASSWORD)
            .write_i32(c.INPUT_CHECK_PASSWORD_SRP)
            .write_i64(srp_id)
            .write_bytes(a_value)
            .write_bytes(m1)
            .to_bytes()
        )

    @staticmethod
    def build_check_password_legacy(password_hash: bytes) -> bytes:
        return (
            TLWriter()
            .write_i32(c.AUTH_CHECK_PASSWORD2)
            .write_bytes(password_hash)
            .write_i32(0)
            .to_bytes()
        )

    @staticmethod
    def parse_sent_code(data: bytes, phone: PhoneNumber) -> LoginCodeChallenge:
        reader = TLReader(data)
        top = reader.read_u32()
        if top != c.AUTH_SENT_CODE:
            raise UnexpectedConstructorError(
                "Expected auth.sentCode.",
                safe_context={"actual_constructor": hex_constructor(top)},
            )
        flags = reader.read_u32()
        sent_type = reader.read_u32()
        delivery = CodeDeliveryType.UNKNOWN
        code_length = None
        if sent_type == c.SENT_CODE_TYPE_APP:
            delivery = CodeDeliveryType.APP
            code_length = reader.read_i32()
        elif sent_type == c.SENT_CODE_TYPE_SMS:
            delivery = CodeDeliveryType.SMS
            code_length = reader.read_i32()
        elif sent_type == c.SENT_CODE_TYPE_CALL:
            delivery = CodeDeliveryType.CALL
            code_length = reader.read_i32()
        elif sent_type == c.SENT_CODE_TYPE_FLASH:
            delivery = CodeDeliveryType.FLASH_CALL
            reader.read_string()  # pattern intentionally discarded
        else:
            raise UnexpectedConstructorError(
                "Unsupported auth.SentCodeType constructor.",
                safe_context={"actual_constructor": hex_constructor(sent_type)},
            )
        phone_code_hash = reader.read_string()
        next_type = None
        if flags & (1 << 1):
            next_constructor = reader.read_u32()
            next_type = {
                c.CODE_TYPE_SMS: CodeDeliveryType.SMS,
                c.CODE_TYPE_CALL: CodeDeliveryType.CALL,
                c.CODE_TYPE_FLASH: CodeDeliveryType.FLASH_CALL,
            }.get(next_constructor, CodeDeliveryType.UNKNOWN)
        timeout = reader.read_i32() if flags & (1 << 2) else None
        if flags & (1 << 8) and reader.remaining() > 0:
            reader.read_string()  # server message; never persisted
        if not phone_code_hash:
            raise TLDecodeError("auth.sentCode contained an empty phone_code_hash.")
        return LoginCodeChallenge(
            phone=phone,
            phone_code_hash=phone_code_hash,
            delivery_type=delivery,
            code_length=code_length,
            next_type=next_type,
            timeout_seconds=timeout,
        )

    @staticmethod
    def parse_authorization_token(data: bytes) -> str:
        reader = TLReader(data)
        top = reader.read_u32()
        if top == c.AUTH_SIGNUP_REQUIRED:
            raise AuthenticationError(
                "This phone number requires account registration; Core 6 login supports existing accounts only."
            )
        if top != c.AUTH_AUTHORIZATION:
            raise UnexpectedConstructorError(
                "Expected auth.authorization.",
                safe_context={"actual_constructor": hex_constructor(top)},
            )
        flags = reader.read_u32()
        token = reader.read_string()
        if flags & 1 and reader.remaining() >= 4:
            reader.read_i32()  # tmp_sessions in some schemas
        if not token or len(token) < 8:
            raise TLDecodeError("auth.authorization contained an invalid token.")
        return token

    @staticmethod
    def parse_password_info(data: bytes) -> SrpPasswordInfo | LegacyPasswordInfo:
        reader = TLReader(data)
        top = reader.read_u32()
        if top == c.ACCOUNT_PASSWORD:
            flags = reader.read_u32()
            if not flags & (1 << 2):
                raise AuthenticationError("The account did not report an active second-factor password.")
            algo = reader.read_u32()
            if algo == c.PASSWORD_KDF_UNKNOWN:
                raise PasswordAlgorithmError("Eitaa reported an unknown password KDF.")
            if algo != c.PASSWORD_KDF_SRP:
                raise PasswordAlgorithmError(
                    "Unsupported second-factor SRP algorithm.",
                    safe_context={"algorithm_constructor": hex_constructor(algo)},
                )
            salt1 = reader.read_bytes()
            salt2 = reader.read_bytes()
            g = reader.read_i32()
            p = reader.read_bytes()
            srp_b = reader.read_bytes()
            srp_id = reader.read_i64()
            hint = reader.read_string() if flags & (1 << 3) else None
            return SrpPasswordInfo(salt1, salt2, g, p, srp_b, srp_id, hint)
        if top == c.ACCOUNT_PASSWORD2:
            reader.read_u32()  # flags
            current_salt = reader.read_bytes()
            reader.read_bytes()  # new_salt
            reader.read_bytes()  # new_secure_salt
            reader.read_bytes()  # secure_random
            hint = reader.read_string() if reader.remaining() else None
            return LegacyPasswordInfo(current_salt, hint)
        if top == c.ACCOUNT_NO_PASSWORD:
            raise AuthenticationError("Eitaa returned account.noPassword after requesting a second factor.")
        raise UnexpectedConstructorError(
            "Unsupported account.getPassword response.",
            safe_context={"actual_constructor": hex_constructor(top)},
        )

    @staticmethod
    def compute_srp_check(info: SrpPasswordInfo, password: str) -> tuple[int, bytes, bytes]:
        if info.p != GOOD_PRIME or info.g not in (3, 4, 5, 7):
            raise PasswordAlgorithmError("Unsafe or unsupported SRP prime/generator parameters.")
        p_int = int.from_bytes(info.p, "big")
        b_int = int.from_bytes(info.srp_b, "big")
        if not 0 < b_int < p_int:
            raise PasswordAlgorithmError("Invalid SRP server value B.")
        password_bytes = password.encode("utf-8")
        hash1 = _sha256(info.salt1, password_bytes, info.salt1)
        hash2 = _sha256(info.salt2, hash1, info.salt2)
        hash3 = hashlib.pbkdf2_hmac("sha512", hash2, info.salt1, 100000)
        pw_hash = _sha256(info.salt2, hash3, info.salt2)
        x = int.from_bytes(pw_hash, "big")
        p_padded = _pad256(info.p)
        g_padded = _int256(info.g)
        b_padded = _pad256(info.srp_b)
        g_x = pow(info.g, x, p_int)
        k = int.from_bytes(_sha256(p_padded, g_padded), "big")
        kg_x = (k * g_x) % p_int
        for _ in range(64):
            a = int.from_bytes(secrets.token_bytes(256), "big")
            a_public = pow(info.g, a, p_int)
            if not _is_good_mod_exp(a_public, p_int):
                continue
            a_bytes = _int256(a_public)
            u = int.from_bytes(_sha256(a_bytes, b_padded), "big")
            if not u:
                continue
            g_b = (b_int - kg_x) % p_int
            if not _is_good_mod_exp(g_b, p_int):
                raise PasswordAlgorithmError("Invalid derived SRP value g_b.")
            shared = pow(g_b, a + u * x, p_int)
            key = _sha256(_int256(shared))
            m1 = _sha256(
                _xor(_sha256(p_padded), _sha256(g_padded)),
                _sha256(info.salt1),
                _sha256(info.salt2),
                a_bytes,
                b_padded,
                key,
            )
            return info.srp_id, a_bytes, m1
        raise PasswordAlgorithmError("Could not generate a safe SRP client value A.")

    @staticmethod
    def compute_legacy_hash(info: LegacyPasswordInfo, password: str) -> bytes:
        return _sha256(info.current_salt, password.encode("utf-8"), info.current_salt)


def _sha256(*parts: bytes) -> bytes:
    digest = hashlib.sha256()
    for part in parts:
        digest.update(part)
    return digest.digest()


def _xor(left: bytes, right: bytes) -> bytes:
    return bytes(a ^ b for a, b in zip(left, right))


def _pad256(value: bytes) -> bytes:
    if len(value) > 256:
        raise PasswordAlgorithmError("SRP integer exceeds 256 bytes.")
    return b"\x00" * (256 - len(value)) + value


def _int256(value: int) -> bytes:
    return value.to_bytes(256, "big")


def _is_good_mod_exp(value: int, prime: int) -> bool:
    if value <= 0 or value >= prime:
        return False
    minimum_bits = 2048 - 64
    return value.bit_length() >= minimum_bits and (prime - value).bit_length() >= minimum_bits

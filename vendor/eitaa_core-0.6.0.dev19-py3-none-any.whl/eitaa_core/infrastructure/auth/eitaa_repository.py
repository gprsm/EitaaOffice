"""Native unauthenticated Eitaa authentication repository."""

from __future__ import annotations

from ...config import EitaaCoreConfig
from ...domain.auth import LoginCodeChallenge
from ...domain.phone import PhoneNumber
from ...infrastructure.codec import normalize_response
from ...infrastructure.codec.constructors import EITAA_OBJECT
from ...infrastructure.codec.tl import TLWriter, hex_constructor
from ...infrastructure.diagnostics import DiagnosticManager
from ...ports.auth_repository import AuthRepository
from ...ports.transport import BinaryTransport, TransportRequest
from .codec import AuthCodec


class EitaaAuthRepository(AuthRepository):
    """Execute auth methods through an empty-token web wrapper."""

    def __init__(
        self,
        *,
        config: EitaaCoreConfig,
        imei: str,
        transport: BinaryTransport,
        diagnostics: DiagnosticManager | None = None,
    ) -> None:
        self.config = config
        self.imei = imei
        self.transport = transport
        self.diagnostics = diagnostics

    def request_code(self, phone: PhoneNumber) -> LoginCodeChallenge:
        body = AuthCodec.build_send_code(
            phone, api_id=self.config.login_api_id, api_hash=self.config.login_api_hash
        )
        result = self._invoke(body, "auth.sendCode")
        return AuthCodec.parse_sent_code(result, phone)

    def sign_in(self, challenge: LoginCodeChallenge, code: str) -> bytes:
        return self._invoke(AuthCodec.build_sign_in(challenge, code), "auth.signIn")

    def get_password(self) -> bytes:
        return self._invoke(AuthCodec.build_get_password(), "account.getPassword")

    def check_password_srp(self, srp_id: int, a_value: bytes, m1: bytes) -> bytes:
        return self._invoke(
            AuthCodec.build_check_password_srp(srp_id, a_value, m1),
            "auth.checkPassword",
        )

    def check_password_legacy(self, password_hash: bytes) -> bytes:
        return self._invoke(
            AuthCodec.build_check_password_legacy(password_hash),
            "auth.checkPassword2",
        )

    def _invoke(self, packed_method: bytes, operation: str) -> bytes:
        wrapped = (
            TLWriter()
            .write_i32(EITAA_OBJECT)
            .write_string("")
            .write_string(self.imei)
            .write_bytes(packed_method)
            .write_i32(self.config.layer)
            .write_i32(self.config.wrapper_flags)
            .to_bytes()
        )
        self._emit(
            "auth_rpc_started",
            fields={
                "operation": operation,
                "method_constructor": hex_constructor(
                    int.from_bytes(packed_method[:4], "little", signed=False)
                ),
                "packed_length": len(packed_method),
                "wrapped_length": len(wrapped),
                "imei_present": bool(self.imei),
            },
        )
        response = self.transport.send(
            TransportRequest(
                endpoint=self.config.api_endpoint,
                body=wrapped,
                operation=operation,
                headers={
                    "Origin": "https://web.eitaa.com",
                    "Referer": "https://web.eitaa.com/",
                },
            )
        )
        envelope = normalize_response(response.body)
        self._emit(
            "auth_rpc_completed",
            fields={
                "operation": operation,
                "response_constructor": (
                    hex_constructor(envelope.constructor)
                    if envelope.constructor is not None
                    else None
                ),
                "response_length": len(envelope.body),
                "was_gzip_packed": envelope.was_gzip_packed,
            },
        )
        return envelope.body

    def _emit(self, event: str, *, level: str = "info", fields=None) -> str | None:
        if not self.diagnostics:
            return None
        return self.diagnostics.emit("auth", event, level=level, fields=fields)

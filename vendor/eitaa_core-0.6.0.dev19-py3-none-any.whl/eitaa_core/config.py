"""Configuration objects used to assemble the core runtime."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

from .domain.session import EitaaAppInfo
from .errors import ConfigurationError


DEFAULT_API_ENDPOINT = "https://hosna.eitaa.com/eitaa/"
DEFAULT_LOGIN_API_ID = 2496
DEFAULT_LOGIN_API_HASH = "8da85b0d5bfe62527e5b244c209159c3"
DEFAULT_MEDIA_ENDPOINT = "https://ali.eitaa.com/eitaa/"
DEFAULT_REFRESH_APP_INFO = EitaaAppInfo(
    build_version=2496,
    device_model="Mozilla/5.0 (Windows NT 10.0; Win64; x64) EitaaCore",
    system_version="Win32",
    app_version="4.6.12 K",
    lang_code="fa",
    sign="",
)


DEFAULT_DOWNLOAD_ENDPOINTS = (
    "https://hadi.eitaa.com/eitaa/",
    "https://mohsen.eitaa.com/eitaa/",
    "https://ghasem.eitaa.com/eitaa/",
    "https://hossein.eitaa.com/eitaa/",
    "https://vahid.eitaa.com/eitaa/",
)


@dataclass(slots=True, frozen=True)
class EitaaCoreConfig:
    """Immutable runtime configuration for :class:`eitaa_core.EitaaCore`.

    Args:
        session_file: Path to the compatible JSON session file.
        api_endpoint: Default endpoint for ordinary API methods.
        media_endpoint: Endpoint used for media upload and media send methods.
        download_endpoints: Ordered fallback endpoints for media downloads.
        timeout_seconds: HTTP request timeout in seconds.
        layer: Eitaa web client API layer placed in the outer wrapper.
        wrapper_flags: Flags placed in the outer ``eitaaObject`` wrapper.
        database_file: SQLite database used by local message repositories.
        media_directory: Default directory for downloaded media frontends.
        diagnostics_root: Directory where component-specific safe diagnostics
            are written. Raw request or response bodies are never written.
        diagnostics_enabled: Enables structured safe diagnostic files.
        auto_refresh_token: Automatically refresh an expired token and replay
            the interrupted RPC once.
        token_refresh_max_attempts: Bounded attempts for refresh responses that
            temporarily report ``eitaa_token_updating``.
        token_refresh_retry_delay_seconds: Delay between bounded refresh attempts.
        refresh_app_info: Web-compatible application identity for
            ``eitaaRefreshToken``.
        user_agent: HTTP User-Agent header for the native client.
    """

    session_file: Path = Path(".eitaa_session.json")
    api_endpoint: str = DEFAULT_API_ENDPOINT
    media_endpoint: str = DEFAULT_MEDIA_ENDPOINT
    download_endpoints: tuple[str, ...] = field(
        default_factory=lambda: DEFAULT_DOWNLOAD_ENDPOINTS
    )
    timeout_seconds: float = 30.0
    layer: int = 135
    wrapper_flags: int = 32
    diagnostics_root: Path = Path("diagnostics")
    database_file: Path = Path("data/eitaa_messages.sqlite3")
    media_directory: Path = Path("data/media")
    diagnostics_enabled: bool = True
    auto_refresh_token: bool = True
    token_refresh_max_attempts: int = 3
    token_refresh_retry_delay_seconds: float = 1.0
    refresh_app_info: EitaaAppInfo = field(
        default_factory=lambda: DEFAULT_REFRESH_APP_INFO
    )
    send_max_text_length: int = 4096
    send_max_caption_length: int = 1024
    upload_big_file_threshold: int = 10 * 1024 * 1024
    login_api_id: int = DEFAULT_LOGIN_API_ID
    login_api_hash: str = DEFAULT_LOGIN_API_HASH
    user_agent: str = "EitaaCore/0.6-core7"

    def validate(self) -> None:
        """Validate configuration and raise a typed error when invalid."""
        if self.timeout_seconds <= 0:
            raise ConfigurationError(
                "timeout_seconds must be greater than zero.",
                safe_context={"timeout_seconds": self.timeout_seconds},
            )
        if not -(2**31) <= self.layer <= 2**31 - 1:
            raise ConfigurationError("layer must fit in a signed int32.")
        if not -(2**31) <= self.wrapper_flags <= 2**31 - 1:
            raise ConfigurationError("wrapper_flags must fit in a signed int32.")

        if not isinstance(self.auto_refresh_token, bool):
            raise ConfigurationError("auto_refresh_token must be boolean.")
        if self.token_refresh_max_attempts < 1:
            raise ConfigurationError(
                "token_refresh_max_attempts must be at least one."
            )
        if self.token_refresh_retry_delay_seconds < 0:
            raise ConfigurationError(
                "token_refresh_retry_delay_seconds cannot be negative."
            )
        self.refresh_app_info.validate()
        if self.send_max_text_length < 1:
            raise ConfigurationError("send_max_text_length must be positive.")
        if self.send_max_caption_length < 0:
            raise ConfigurationError("send_max_caption_length cannot be negative.")
        if self.upload_big_file_threshold < 1:
            raise ConfigurationError("upload_big_file_threshold must be positive.")
        if self.login_api_id <= 0:
            raise ConfigurationError("login_api_id must be positive.")
        if len(self.login_api_hash) != 32 or any(
            character not in "0123456789abcdefABCDEF"
            for character in self.login_api_hash
        ):
            raise ConfigurationError(
                "login_api_hash must be a 32-character hexadecimal string."
            )

        urls = [self.api_endpoint, self.media_endpoint, *self.download_endpoints]
        for value in urls:
            parsed = urlparse(value)
            if parsed.scheme != "https" or not parsed.netloc:
                raise ConfigurationError(
                    "Every endpoint must be an absolute HTTPS URL.",
                    safe_context={"endpoint": value},
                )

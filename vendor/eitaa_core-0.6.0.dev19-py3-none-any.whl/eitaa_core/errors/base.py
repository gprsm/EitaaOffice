"""Typed exception hierarchy for the Eitaa core.

Every public exception may carry a safe diagnostic context and the exact path of
the component log that should be shared for troubleshooting. Secret values must
never be placed in ``safe_context``.
"""

from __future__ import annotations

from typing import Any


class EitaaCoreError(Exception):
    """Base class for all expected core failures."""

    component = "core"

    def __init__(
        self,
        message: str,
        *,
        safe_context: dict[str, Any] | None = None,
        debug_file: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.safe_context = dict(safe_context or {})
        self.debug_file = debug_file

    def __str__(self) -> str:
        suffix = f" [debug file: {self.debug_file}]" if self.debug_file else ""
        return f"{self.message}{suffix}"


class ConfigurationError(EitaaCoreError):
    """Invalid runtime configuration."""

    component = "configuration"


class DomainValidationError(EitaaCoreError):
    """A domain entity violates a required invariant."""

    component = "domain"


class SessionError(EitaaCoreError):
    """Base class for session persistence failures."""

    component = "session"


class SessionNotFoundError(SessionError):
    """The configured session file does not exist."""


class SessionDecodeError(SessionError):
    """The session file is not valid or cannot be interpreted."""


class SessionValidationError(SessionError):
    """The session object is missing required values."""


class TokenRefreshError(EitaaCoreError):
    """Automatic or explicit token refresh could not complete safely."""

    component = "session_refresh"


class TokenRefreshDisabledError(TokenRefreshError):
    """The server requested refresh while the feature is disabled."""


class TransportError(EitaaCoreError):
    """Base class for HTTP transport failures."""

    component = "transport"


class HttpStatusError(TransportError):
    """The server returned a non-successful HTTP status."""


class NetworkError(TransportError):
    """The request could not reach the endpoint."""


class EndpointRoutingError(TransportError):
    """No endpoint is configured for a requested logical role."""


class TLCodecError(EitaaCoreError):
    """Base class for TL serialization and parsing failures."""

    component = "tl_codec"


class TLDecodeError(TLCodecError):
    """A TL payload is malformed or truncated."""


class TLEncodeError(TLCodecError):
    """A Python value cannot be represented by the requested TL type."""


class UnexpectedConstructorError(TLCodecError):
    """A response constructor differs from the expected constructor."""


class RpcError(EitaaCoreError):
    """RPC-level error returned inside a successful HTTP response."""

    component = "rpc"

    def __init__(
        self,
        code: int,
        text: str,
        *,
        safe_context: dict[str, Any] | None = None,
        debug_file: str | None = None,
    ) -> None:
        self.code = code
        self.text = text
        super().__init__(
            f"RPC {code}: {text}",
            safe_context=safe_context,
            debug_file=debug_file,
        )


class AuthenticationError(EitaaCoreError):
    """Native login or account authentication failed."""

    component = "auth"


class AuthenticationStateError(AuthenticationError):
    """A staged login method was called in the wrong order."""


class PasswordAlgorithmError(AuthenticationError):
    """Second-factor password parameters are unsupported or unsafe."""


class DiscoveryError(EitaaCoreError):
    """Dialog or username discovery failed."""

    component = "discovery"


class UsernameResolveError(DiscoveryError):
    """A public username could not be resolved to a usable peer."""


class ContactError(EitaaCoreError):
    """Base class for contact and phone-resolution failures."""

    component = "contacts"


class PhoneNumberError(ContactError):
    """A phone number cannot be normalized safely."""


class ContactNotFoundError(ContactError):
    """A requested phone number is not present in the contact book."""


class ContactResolveError(ContactError):
    """Eitaa did not return a sendable user for a phone number."""


class ContactImportRetryError(ContactResolveError):
    """Eitaa requested a later retry for an imported contact."""


class HistoryError(EitaaCoreError):
    """Base class for remote history operations."""

    component = "history"


class HistoryParseError(HistoryError):
    """A messages.getHistory response cannot be parsed conservatively."""


class MessageStoreError(EitaaCoreError):
    """SQLite message repository or migration failure."""

    component = "database"


class MediaDownloadError(EitaaCoreError):
    """Base class for native remote media download failures."""

    component = "media"


class MediaValidationError(MediaDownloadError):
    """A media reference or download option is not usable."""


class MediaTooLargeError(MediaDownloadError):
    """A configured download size limit was exceeded."""


class MediaIncompleteError(MediaDownloadError):
    """The server ended a download before its declared size."""


class MediaCdnRedirectError(MediaDownloadError):
    """The server requested a CDN flow not implemented by Core 4.2."""


class MediaStorageError(EitaaCoreError):
    """Local media file creation, append, or finalize failure."""

    component = "media_storage"


class RetrievalCursorError(EitaaCoreError):
    """A persisted history cursor cannot be created or advanced safely."""

    component = "cursor"


class PublicationError(EitaaCoreError):
    """External publication workflow state is invalid or unavailable."""

    component = "publications"


class ExportError(EitaaCoreError):
    """Local message export failed."""

    component = "export"


class SendError(EitaaCoreError):
    """Base class for outbound text and media failures."""

    component = "send"


class SendValidationError(SendError):
    """Outbound content or recipient is invalid before an RPC is attempted."""


class SendResponseError(SendError):
    """The server response cannot be safely classified as a successful send."""


class UploadError(EitaaCoreError):
    """Base class for local-file upload failures."""

    component = "upload"


class UploadPartError(UploadError):
    """One upload part failed after bounded retry attempts."""


class UploadFileError(UploadError):
    """A local file cannot be read or represented for upload."""


class CommunityError(EitaaCoreError):
    """Community membership fetch, parse, or local-index failure."""

    component = "members"


class BulkSendError(EitaaCoreError):
    """Persistent bulk-send job failure."""

    component = "bulk_send"


class BulkConfirmationError(BulkSendError):
    """A draft job was started without explicit confirmation."""


class PhoneListError(EitaaCoreError):
    """Phone-list parsing, persistence, or resolution failure."""

    component = "phone_lists"


class MembershipError(EitaaCoreError):
    """Bulk membership invitation, persistence, or rollback failure."""

    component = "membership"


class MembershipConfirmationError(MembershipError):
    """A membership mutation was requested without explicit confirmation."""

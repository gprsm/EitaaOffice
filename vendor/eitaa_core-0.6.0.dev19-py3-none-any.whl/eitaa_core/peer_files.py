"""Read and write portable peer JSON files used by thin frontends."""

from __future__ import annotations

import json
from pathlib import Path

from .domain.enums import PeerType
from .domain.peer import Peer
from .errors import DomainValidationError


def load_peer_file(path: Path | str) -> Peer:
    """Load common peer-file formats produced by earlier project versions.

    Supported identifier names include ``peer_id``, ``id``, ``channel_id``,
    ``user_id`` and ``chat_id``. A nested ``peer`` object is also accepted.
    """
    source = Path(path)
    try:
        data = json.loads(source.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise DomainValidationError(
            "Peer file cannot be read as JSON.",
            safe_context={"path": str(source), "error_type": type(exc).__name__},
        ) from exc
    if isinstance(data.get("peer"), dict):
        merged = dict(data)
        merged.update(data["peer"])
        data = merged
    raw_type = data.get("peer_type") or data.get("type")
    if raw_type is None:
        if "channel_id" in data: raw_type = "channel"
        elif "user_id" in data: raw_type = "user"
        elif "chat_id" in data: raw_type = "chat"
    try:
        peer_type = PeerType(str(raw_type).lower())
    except (ValueError, AttributeError) as exc:
        raise DomainValidationError(
            "Peer file has an unsupported peer type.",
            safe_context={"path": str(source), "peer_type": str(raw_type)},
        ) from exc
    identifier = next(
        (data.get(key) for key in ("peer_id", "id", "channel_id", "user_id", "chat_id") if data.get(key) is not None),
        None,
    )
    if identifier is None:
        raise DomainValidationError(
            "Peer file does not contain an identifier.",
            safe_context={"path": str(source)},
        )
    access_hash = data.get("access_hash")
    peer = Peer(
        id=int(identifier),
        type=peer_type,
        access_hash=int(access_hash) if access_hash is not None else None,
        username=data.get("username"),
        title=data.get("title") or data.get("name"),
    )
    peer.validate()
    return peer


def save_peer_file(path: Path | str, peer: Peer) -> None:
    """Atomically store a peer file. The result contains an access hash and is private."""
    peer.validate()
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(
        json.dumps(
            {
                "peer_type": peer.type.value,
                "peer_id": peer.id,
                "access_hash": peer.access_hash,
                "username": peer.username,
                "title": peer.title,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    temporary.replace(target)

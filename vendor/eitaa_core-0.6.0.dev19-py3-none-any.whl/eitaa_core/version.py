"""Package version."""

__version__ = "0.6.0-core7.4.5-gmi1"

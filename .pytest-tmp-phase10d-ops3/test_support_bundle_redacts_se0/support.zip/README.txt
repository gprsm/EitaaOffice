This bundle intentionally excludes .env, Session contents, SQLite contents, media, and WordPress credentials.
It includes redacted runtime logs, safe diagnostics, and safe coordinator metadata only.
File hashes are support fingerprints and are not authentication secrets.
